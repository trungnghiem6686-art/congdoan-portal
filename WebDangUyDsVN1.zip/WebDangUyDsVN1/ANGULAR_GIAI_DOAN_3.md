# Giai đoạn 3 - Angular Admin

Đã thêm:
- AuthGuard
- AdminGuard
- AuthInterceptor
- ApiService
- Admin Dashboard
- Quản lý Users
- Quản lý Departments
- Quản lý PartyCells

## Đăng ký HttpClient + interceptor

Trong `app.config.ts`, thêm:

```ts
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { authInterceptor } from './core/interceptors/auth.interceptor';

providers: [
  provideHttpClient(withInterceptors([authInterceptor]))
]
```

## Thêm route admin

Trong `app.routes.ts`:

```ts
{
  path: 'admin',
  loadChildren: () => import('./admin/admin.routes').then(m => m.ADMIN_ROUTES)
}
```

## Quan trọng

API URL hiện để trong:
`src/app/core/services/api.config.ts`

Nếu ASP.NET chạy port khác, sửa:
`API_BASE_URL`.

## Login

Login component hiện tại của project cần gọi:

```ts
this.authService.login({
  username: this.username,
  password: this.password
}).subscribe({
  next: () => this.router.navigate(['/admin']),
  error: err => ...
});
```

Tài khoản ADMIN cần được bootstrap ở backend/database trước khi đăng nhập.
