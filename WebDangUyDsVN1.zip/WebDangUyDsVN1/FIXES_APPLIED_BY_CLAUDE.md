# Các lỗi đã sửa trong bản này

## 1. Backend không chạy đúng cổng https://localhost:7001
`Properties/launchSettings.json` bị thiếu hoàn toàn trong file zip gốc. Không có
file này, `dotnet run` sẽ chỉ bind vào cổng mặc định (http://localhost:5000) chứ
KHÔNG bind vào `https://localhost:7001` như `src/app/core/services/api.config.ts`
đang trỏ tới -> Angular sẽ gọi API thất bại (ERR_CONNECTION_REFUSED) dù backend
đang chạy bình thường.

Đã thêm: `backend/WebDangUyDs.Api/Properties/launchSettings.json` với profile
`https` (mặc định) bind `https://localhost:7001;http://localhost:5000`.

## 2. Dọn 15 thư mục component rác (scaffold thừa)
Các thư mục `WebDangUyDs`, `WebDangUyDs2`...`WebDangUyDs16`, `WedDangUyDs4` là
bản nháp/scaffold cũ (không route nào trỏ tới, chỉ tốn dung lượng và gây nhiễu
khi đọc code). Đã xoá toàn bộ, không ảnh hưởng gì vì không có file nào import
tới chúng (đã kiểm tra bằng grep trước khi xoá).

## 3. Gói zip không sạch (93MB thay vì ~5MB)
`node_modules` trong zip gốc được cài trên Windows (chỉ có binary
`@esbuild/win32-x64`, `lightningcss-win32-x64-msvc`). Nếu bạn không chạy trên
Windows, các binary này sẽ gây lỗi build. Bản zip mới đã bỏ hẳn
`node_modules`/`dist`/`.angular` (đúng theo `.gitignore` sẵn có) — bạn tự chạy
`npm install` để npm cài đúng binary theo hệ điều hành của bạn.

## Đã kiểm tra, không có lỗi
- `tsc --noEmit` toàn bộ `src/**/*.ts`: không lỗi.
- Đối chiếu route `app.routes.ts` / `admin.routes.ts` với các file component
  thực tế trên đĩa: đủ cả 12 module (`dashboard, users, departments,
  party-cells, articles, article-approval, documents, calendar, policy,
  newsletter, banners, media, analytics`).
- Đối chiếu lệnh gọi API phía Angular (`ApiService.get/post/...`) với route
  backend (`[Route]`, `[HttpGet]`...) trong từng Controller: khớp nhau.
- Đối chiếu `AppDbContext` (25 `DbSet`) với các bảng tạo trong
  `database/01...10_*.sql`: đủ, không thiếu bảng nào.
- `provideHttpClient(withInterceptors([authInterceptor]))` đã có trong
  `app.config.ts` (lỗi này có ở bản trước, bản này đã tự sửa sẵn).

## Bạn cần tự làm (không sửa được từ phía tôi)
1. Chạy SQL Server, thực thi lần lượt `database/01_...sql` -> `10_...sql`.
2. `cd backend/WebDangUyDs.Api && dotnet dev-certs https --trust` (một lần duy
   nhất trên máy bạn) để trình duyệt/Angular tin tưởng chứng chỉ HTTPS tự ký
   của `https://localhost:7001`. Nếu bỏ qua bước này, Angular gọi API HTTPS có
   thể bị lỗi SSL.
3. `cd backend/WebDangUyDs.Api && dotnet restore && dotnet run` — lần chạy đầu
   `DevelopmentSeed` sẽ tự tạo 5 tài khoản demo (xem `HUONG_DAN_CHAY_1_PROJECT.md`).
4. Ở thư mục gốc: `npm install && npm start`, mở `http://localhost:4200`.
5. Đăng nhập `admin / Admin@123` -> vào `/admin` để dùng đủ 12 chức năng.
