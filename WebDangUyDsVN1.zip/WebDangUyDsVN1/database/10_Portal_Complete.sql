USE WebDangUyDs;
GO

IF SCHEMA_ID('Newsletter') IS NULL EXEC('CREATE SCHEMA Newsletter');
IF SCHEMA_ID('Campaign') IS NULL EXEC('CREATE SCHEMA Campaign');
IF SCHEMA_ID('Media') IS NULL EXEC('CREATE SCHEMA Media');
IF SCHEMA_ID('Analytics') IS NULL EXEC('CREATE SCHEMA Analytics');
GO

IF OBJECT_ID('Newsletter.NewsletterSubscriber','U') IS NULL
BEGIN
CREATE TABLE Newsletter.NewsletterSubscriber(
 NewsletterSubscriberId BIGINT IDENTITY PRIMARY KEY,
 Email VARCHAR(320) NOT NULL UNIQUE,
 FullName NVARCHAR(250) NULL,
 IsConfirmed BIT NOT NULL DEFAULT 0,
 IsActive BIT NOT NULL DEFAULT 1,
 UnsubscribeToken VARCHAR(64) NOT NULL UNIQUE,
 CreatedAt DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
 ConfirmedAt DATETIME2 NULL,
 UnsubscribedAt DATETIME2 NULL
);
END
GO

IF OBJECT_ID('Campaign.CampaignBanner','U') IS NULL
BEGIN
CREATE TABLE Campaign.CampaignBanner(
 CampaignBannerId BIGINT IDENTITY PRIMARY KEY,
 CampaignName NVARCHAR(250) NOT NULL,
 Title NVARCHAR(500) NOT NULL,
 Subtitle NVARCHAR(1000) NULL,
 ImageUrl NVARCHAR(1000) NOT NULL,
 LinkUrl NVARCHAR(1000) NULL,
 StartAt DATETIME2 NOT NULL,
 EndAt DATETIME2 NOT NULL,
 Priority INT NOT NULL DEFAULT 0,
 IsActive BIT NOT NULL DEFAULT 1,
 CreatedAt DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
 CONSTRAINT CK_CampaignBanner_Time CHECK(EndAt > StartAt)
);
END
GO

IF OBJECT_ID('Media.MediaContent','U') IS NULL
BEGIN
CREATE TABLE Media.MediaContent(
 MediaContentId BIGINT IDENTITY PRIMARY KEY,
 MediaType VARCHAR(30) NOT NULL,
 Title NVARCHAR(500) NOT NULL,
 Description NVARCHAR(MAX) NULL,
 MediaUrl NVARCHAR(1000) NOT NULL,
 ThumbnailUrl NVARCHAR(1000) NULL,
 EmbedUrl NVARCHAR(1000) NULL,
 IsPublished BIT NOT NULL DEFAULT 0,
 SortOrder INT NOT NULL DEFAULT 0,
 ViewCount BIGINT NOT NULL DEFAULT 0,
 CreatedAt DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
 CONSTRAINT CK_Media_Type CHECK(MediaType IN ('VIDEO','INFOGRAPHIC'))
);
END
GO

IF OBJECT_ID('Analytics.ContentViewStat','U') IS NULL
BEGIN
CREATE TABLE Analytics.ContentViewStat(
 ContentViewStatId BIGINT IDENTITY PRIMARY KEY,
 ContentType VARCHAR(50) NOT NULL,
 ContentId BIGINT NOT NULL,
 ViewedAt DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
 IpHash VARCHAR(128) NULL
);
END
GO

IF OBJECT_ID('Analytics.SearchLog','U') IS NULL
BEGIN
CREATE TABLE Analytics.SearchLog(
 SearchLogId BIGINT IDENTITY PRIMARY KEY,
 Keyword NVARCHAR(500) NOT NULL,
 SearchType VARCHAR(50) NULL,
 ResultCount INT NOT NULL DEFAULT 0,
 CreatedAt DATETIME2 NOT NULL DEFAULT SYSDATETIME()
);
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name='IX_Banner_Active_Date' AND object_id=OBJECT_ID('Campaign.CampaignBanner'))
 CREATE INDEX IX_Banner_Active_Date ON Campaign.CampaignBanner(IsActive, StartAt, EndAt, Priority DESC);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name='IX_Media_Public' AND object_id=OBJECT_ID('Media.MediaContent'))
 CREATE INDEX IX_Media_Public ON Media.MediaContent(IsPublished, MediaType, SortOrder);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name='IX_ViewStat_Date_Type' AND object_id=OBJECT_ID('Analytics.ContentViewStat'))
 CREATE INDEX IX_ViewStat_Date_Type ON Analytics.ContentViewStat(ViewedAt, ContentType, ContentId);
GO
