USE WebDangUyDs;
GO

IF OBJECT_ID(N'System.AuditLog','U') IS NULL
BEGIN
    CREATE TABLE System.AuditLog
    (
        AuditLogId      BIGINT IDENTITY(1,1) PRIMARY KEY,
        UserId          INT NULL,
        ActionCode      VARCHAR(100) NOT NULL,
        EntityName      VARCHAR(100) NULL,
        EntityId        NVARCHAR(100) NULL,
        IpAddress       VARCHAR(50) NULL,
        UserAgent       NVARCHAR(1000) NULL,
        DetailsJson     NVARCHAR(MAX) NULL,
        CreatedAt       DATETIME2(0) NOT NULL CONSTRAINT DF_AuditLog_CreatedAt DEFAULT SYSDATETIME(),
        CONSTRAINT FK_AuditLog_User FOREIGN KEY (UserId) REFERENCES Auth.UserAccount(UserId)
    );
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name='IX_Article_Category_Status' AND object_id=OBJECT_ID('Content.Article'))
    CREATE INDEX IX_Article_Category_Status ON Content.Article(CategoryId, StatusCode, CreatedAt DESC);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name='IX_Article_Department_PartyCell' AND object_id=OBJECT_ID('Content.Article'))
    CREATE INDEX IX_Article_Department_PartyCell ON Content.Article(DepartmentId, PartyCellId, StatusCode);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name='IX_Document_Number' AND object_id=OBJECT_ID('Content.Document'))
    CREATE INDEX IX_Document_Number ON Content.Document(DocumentNumber);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name='IX_Approval_Article_Level' AND object_id=OBJECT_ID('Workflow.ArticleApproval'))
    CREATE INDEX IX_Approval_Article_Level ON Workflow.ArticleApproval(ArticleId, ApprovalLevelId, StatusCode);
GO

SELECT
    s.name AS SchemaName,
    t.name AS TableName
FROM sys.tables t
JOIN sys.schemas s ON s.schema_id=t.schema_id
ORDER BY s.name, t.name;
