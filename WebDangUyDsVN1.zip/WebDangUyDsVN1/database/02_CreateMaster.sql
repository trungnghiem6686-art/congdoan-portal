USE WebDangUyDs;
GO

IF OBJECT_ID(N'Master.Department','U') IS NULL
BEGIN
    CREATE TABLE Master.Department
    (
        DepartmentId       INT IDENTITY(1,1) PRIMARY KEY,
        DepartmentCode     VARCHAR(50) NOT NULL UNIQUE,
        DepartmentName     NVARCHAR(255) NOT NULL,
        ParentDepartmentId INT NULL,
        IsActive            BIT NOT NULL CONSTRAINT DF_Department_IsActive DEFAULT 1,
        CreatedAt           DATETIME2(0) NOT NULL CONSTRAINT DF_Department_CreatedAt DEFAULT SYSDATETIME(),
        CONSTRAINT FK_Department_Parent
            FOREIGN KEY (ParentDepartmentId) REFERENCES Master.Department(DepartmentId)
    );
END
GO

IF OBJECT_ID(N'Master.PartyCell','U') IS NULL
BEGIN
    CREATE TABLE Master.PartyCell
    (
        PartyCellId     INT IDENTITY(1,1) PRIMARY KEY,
        DepartmentId    INT NOT NULL,
        PartyCellCode   VARCHAR(50) NOT NULL,
        PartyCellName   NVARCHAR(255) NOT NULL,
        IsActive        BIT NOT NULL CONSTRAINT DF_PartyCell_IsActive DEFAULT 1,
        CreatedAt       DATETIME2(0) NOT NULL CONSTRAINT DF_PartyCell_CreatedAt DEFAULT SYSDATETIME(),
        CONSTRAINT UQ_PartyCell_Department_Code UNIQUE (DepartmentId, PartyCellCode),
        CONSTRAINT FK_PartyCell_Department
            FOREIGN KEY (DepartmentId) REFERENCES Master.Department(DepartmentId)
    );
END
GO

IF OBJECT_ID(N'Master.NewsCategory','U') IS NULL
BEGIN
    CREATE TABLE Master.NewsCategory
    (
        NewsCategoryId INT IDENTITY(1,1) PRIMARY KEY,
        CategoryCode   VARCHAR(50) NOT NULL UNIQUE,
        CategoryName   NVARCHAR(255) NOT NULL,
        SortOrder      INT NOT NULL CONSTRAINT DF_NewsCategory_SortOrder DEFAULT 0,
        IsActive       BIT NOT NULL CONSTRAINT DF_NewsCategory_IsActive DEFAULT 1,
        CreatedAt      DATETIME2(0) NOT NULL CONSTRAINT DF_NewsCategory_CreatedAt DEFAULT SYSDATETIME()
    );
END
GO

IF OBJECT_ID(N'Master.DocumentCategory','U') IS NULL
BEGIN
    CREATE TABLE Master.DocumentCategory
    (
        DocumentCategoryId INT IDENTITY(1,1) PRIMARY KEY,
        CategoryCode       VARCHAR(50) NOT NULL UNIQUE,
        CategoryName       NVARCHAR(255) NOT NULL,
        SortOrder          INT NOT NULL CONSTRAINT DF_DocumentCategory_SortOrder DEFAULT 0,
        IsActive            BIT NOT NULL CONSTRAINT DF_DocumentCategory_IsActive DEFAULT 1
    );
END
GO
