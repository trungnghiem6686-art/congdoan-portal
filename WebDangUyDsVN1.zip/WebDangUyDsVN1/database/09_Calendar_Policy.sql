USE WebDangUyDs;
GO

IF SCHEMA_ID('Calendar') IS NULL EXEC('CREATE SCHEMA Calendar');
IF SCHEMA_ID('Policy') IS NULL EXEC('CREATE SCHEMA Policy');
GO

IF OBJECT_ID('Calendar.WorkCalendarEvent','U') IS NULL
BEGIN
    CREATE TABLE Calendar.WorkCalendarEvent(
        WorkCalendarEventId BIGINT IDENTITY(1,1) PRIMARY KEY,
        Title NVARCHAR(500) NOT NULL,
        Description NVARCHAR(MAX) NULL,
        StartAt DATETIME2 NOT NULL,
        EndAt DATETIME2 NOT NULL,
        Location NVARCHAR(500) NULL,
        Organizer NVARCHAR(250) NULL,
        StatusCode VARCHAR(30) NOT NULL DEFAULT 'PUBLISHED',
        DepartmentId INT NULL,
        PartyCellId INT NULL,
        CreatedByUserId INT NOT NULL,
        CreatedAt DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
        UpdatedAt DATETIME2 NULL,
        CONSTRAINT CK_Calendar_Time CHECK(EndAt > StartAt)
    );
END
GO

IF OBJECT_ID('Policy.PolicyQuestion','U') IS NULL
BEGIN
    CREATE TABLE Policy.PolicyQuestion(
        PolicyQuestionId BIGINT IDENTITY(1,1) PRIMARY KEY,
        Question NVARCHAR(MAX) NOT NULL,
        QuestionerName NVARCHAR(250) NULL,
        QuestionerEmail VARCHAR(250) NULL,
        CategoryCode VARCHAR(100) NULL,
        StatusCode VARCHAR(30) NOT NULL DEFAULT 'PENDING',
        CreatedAt DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
        UpdatedAt DATETIME2 NULL
    );
END
GO

IF OBJECT_ID('Policy.PolicyAnswer','U') IS NULL
BEGIN
    CREATE TABLE Policy.PolicyAnswer(
        PolicyAnswerId BIGINT IDENTITY(1,1) PRIMARY KEY,
        PolicyQuestionId BIGINT NOT NULL,
        AnsweredByUserId INT NOT NULL,
        Answer NVARCHAR(MAX) NOT NULL,
        IsPublished BIT NOT NULL DEFAULT 0,
        CreatedAt DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
        PublishedAt DATETIME2 NULL,
        CONSTRAINT FK_PolicyAnswer_Question FOREIGN KEY(PolicyQuestionId)
            REFERENCES Policy.PolicyQuestion(PolicyQuestionId)
    );
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name='IX_Calendar_Start_End' AND object_id=OBJECT_ID('Calendar.WorkCalendarEvent'))
    CREATE INDEX IX_Calendar_Start_End ON Calendar.WorkCalendarEvent(StatusCode, StartAt, EndAt);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name='IX_PolicyQuestion_Status_Created' AND object_id=OBJECT_ID('Policy.PolicyQuestion'))
    CREATE INDEX IX_PolicyQuestion_Status_Created ON Policy.PolicyQuestion(StatusCode, CreatedAt DESC);
GO
