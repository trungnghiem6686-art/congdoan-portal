USE WebDangUyDs;
GO

/*
    DEVELOPMENT ONLY.
    Thay <BCRYPT_HASH> bằng hash BCrypt được tạo bởi backend.
    Không lưu mật khẩu plaintext trong database.
*/
DECLARE @Username VARCHAR(100) = 'admin';
DECLARE @PasswordHash NVARCHAR(500) = N'<BCRYPT_HASH>';

IF @PasswordHash = N'<BCRYPT_HASH>'
BEGIN
    THROW 51000, 'Hãy thay <BCRYPT_HASH> bằng BCrypt hash trước khi chạy.', 1;
END

IF NOT EXISTS (SELECT 1 FROM Auth.UserAccount WHERE Username=@Username)
BEGIN
    INSERT INTO Auth.UserAccount(Username, PasswordHash, FullName, IsActive, CreatedAt)
    VALUES(@Username, @PasswordHash, N'Quản trị hệ thống', 1, SYSDATETIME());
END

DECLARE @UserId INT = (SELECT UserId FROM Auth.UserAccount WHERE Username=@Username);
DECLARE @RoleId INT = (SELECT RoleId FROM Auth.Role WHERE RoleCode='ADMIN');

IF NOT EXISTS (SELECT 1 FROM Auth.UserRole WHERE UserId=@UserId AND RoleId=@RoleId)
BEGIN
    INSERT INTO Auth.UserRole(UserId, RoleId) VALUES(@UserId, @RoleId);
END
GO
