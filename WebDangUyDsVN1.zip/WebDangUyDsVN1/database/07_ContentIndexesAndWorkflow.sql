USE WebDangUyDs;
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = 'IX_Article_Status_Category_CreatedAt'
      AND object_id = OBJECT_ID('Content.Article')
)
BEGIN
    CREATE INDEX IX_Article_Status_Category_CreatedAt
    ON Content.Article(StatusCode, CategoryId, CreatedAt DESC);
END
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = 'IX_Article_Title'
      AND object_id = OBJECT_ID('Content.Article')
)
BEGIN
    CREATE INDEX IX_Article_Title
    ON Content.Article(Title);
END
GO

IF NOT EXISTS (
    SELECT 1 FROM sys.indexes
    WHERE name = 'IX_ArticleApproval_Status_Level'
      AND object_id = OBJECT_ID('Workflow.ArticleApproval')
)
BEGIN
    CREATE INDEX IX_ArticleApproval_Status_Level
    ON Workflow.ArticleApproval(StatusCode, ApprovalLevelId, CreatedAt);
END
GO

-- Trạng thái chuẩn:
-- DRAFT      : bản nháp
-- PENDING_L1 : chờ duyệt cấp 1
-- PENDING_L2 : chờ duyệt cấp 2
-- PUBLISHED  : đã xuất bản
-- REJECTED   : bị từ chối
GO
