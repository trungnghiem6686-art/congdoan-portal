/*
 WebDangUyDs - Giai đoạn 1
 SQL Server 2022
 Chạy file này trước các file còn lại.
*/
IF DB_ID(N'WebDangUyDs') IS NULL
BEGIN
    CREATE DATABASE WebDangUyDs;
END
GO

USE WebDangUyDs;
GO

IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'Auth')
    EXEC(N'CREATE SCHEMA Auth');
GO
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'Master')
    EXEC(N'CREATE SCHEMA Master');
GO
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'Content')
    EXEC(N'CREATE SCHEMA Content');
GO
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'Workflow')
    EXEC(N'CREATE SCHEMA Workflow');
GO
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = N'System')
    EXEC(N'CREATE SCHEMA System');
GO
