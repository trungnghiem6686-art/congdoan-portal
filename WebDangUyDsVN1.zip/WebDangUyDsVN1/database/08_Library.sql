USE WebDangUyDs;
GO

IF SCHEMA_ID('Library') IS NULL
    EXEC('CREATE SCHEMA Library');
GO

IF OBJECT_ID('Library.DocumentCategory','U') IS NULL
BEGIN
    CREATE TABLE Library.DocumentCategory(
        DocumentCategoryId INT IDENTITY(1,1) PRIMARY KEY,
        CategoryCode VARCHAR(50) NOT NULL UNIQUE,
        CategoryName NVARCHAR(250) NOT NULL,
        SortOrder INT NOT NULL DEFAULT 0,
        IsActive BIT NOT NULL DEFAULT 1
    );
END
GO

IF OBJECT_ID('Library.Document','U') IS NULL
BEGIN
    CREATE TABLE Library.Document(
        DocumentId BIGINT IDENTITY(1,1) PRIMARY KEY,
        CategoryId INT NOT NULL,
        DocumentNumber NVARCHAR(100) NOT NULL,
        Title NVARCHAR(500) NOT NULL,
        Summary NVARCHAR(MAX) NULL,
        Signer NVARCHAR(250) NULL,
        IssueDate DATE NULL,
        IssuingUnit NVARCHAR(250) NULL,
        StatusCode VARCHAR(30) NOT NULL DEFAULT 'PUBLISHED',
        ViewCount BIGINT NOT NULL DEFAULT 0,
        CreatedAt DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
        UpdatedAt DATETIME2 NULL,
        CONSTRAINT UQ_Document_Number UNIQUE(DocumentNumber),
        CONSTRAINT FK_Document_Category FOREIGN KEY(CategoryId)
            REFERENCES Library.DocumentCategory(DocumentCategoryId)
    );
END
GO

IF OBJECT_ID('Library.DocumentFile','U') IS NULL
BEGIN
    CREATE TABLE Library.DocumentFile(
        DocumentFileId BIGINT IDENTITY(1,1) PRIMARY KEY,
        DocumentId BIGINT NOT NULL,
        FileName NVARCHAR(500) NOT NULL,
        StoredFileName NVARCHAR(500) NOT NULL,
        FilePath NVARCHAR(1000) NOT NULL,
        ContentType NVARCHAR(200) NOT NULL,
        FileSize BIGINT NOT NULL,
        UploadedAt DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
        CONSTRAINT FK_DocumentFile_Document FOREIGN KEY(DocumentId)
            REFERENCES Library.Document(DocumentId)
    );
END
GO

IF NOT EXISTS (SELECT 1 FROM Library.DocumentCategory)
BEGIN
    INSERT INTO Library.DocumentCategory(CategoryCode, CategoryName, SortOrder)
    VALUES
    ('NGHI_QUYET', N'Nghị quyết', 1),
    ('CHI_THI', N'Chỉ thị', 2),
    ('QUYET_DINH', N'Quyết định', 3),
    ('KE_HOACH', N'Kế hoạch', 4),
    ('HUONG_DAN', N'Hướng dẫn', 5),
    ('THONG_BAO', N'Thông báo', 6),
    ('CONG_VAN', N'Công văn', 7),
    ('BAO_CAO', N'Báo cáo', 8),
    ('TAI_LIEU', N'Tài liệu', 9);
END
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name='IX_Document_Search' AND object_id=OBJECT_ID('Library.Document'))
    CREATE INDEX IX_Document_Search ON Library.Document(CategoryId, IssueDate DESC, CreatedAt DESC);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name='IX_Document_Number' AND object_id=OBJECT_ID('Library.Document'))
    CREATE INDEX IX_Document_Number ON Library.Document(DocumentNumber);
GO
