USE WebDangUyDs;
GO

IF OBJECT_ID(N'Auth.Role','U') IS NULL
BEGIN
    CREATE TABLE Auth.Role
    (
        RoleId          INT IDENTITY(1,1) PRIMARY KEY,
        RoleCode        VARCHAR(50) NOT NULL UNIQUE,
        RoleName        NVARCHAR(150) NOT NULL,
        Description     NVARCHAR(500) NULL,
        IsActive        BIT NOT NULL CONSTRAINT DF_Role_IsActive DEFAULT 1,
        CreatedAt       DATETIME2(0) NOT NULL CONSTRAINT DF_Role_CreatedAt DEFAULT SYSDATETIME()
    );
END
GO

IF OBJECT_ID(N'Auth.Permission','U') IS NULL
BEGIN
    CREATE TABLE Auth.Permission
    (
        PermissionId    INT IDENTITY(1,1) PRIMARY KEY,
        PermissionCode  VARCHAR(100) NOT NULL UNIQUE,
        PermissionName  NVARCHAR(200) NOT NULL,
        Description     NVARCHAR(500) NULL,
        IsActive        BIT NOT NULL CONSTRAINT DF_Permission_IsActive DEFAULT 1
    );
END
GO

IF OBJECT_ID(N'Auth.UserAccount','U') IS NULL
BEGIN
    CREATE TABLE Auth.UserAccount
    (
        UserId              INT IDENTITY(1,1) PRIMARY KEY,
        Username            VARCHAR(100) NOT NULL UNIQUE,
        PasswordHash        NVARCHAR(500) NOT NULL,
        FullName            NVARCHAR(255) NOT NULL,
        Email               VARCHAR(255) NULL,
        Phone               VARCHAR(30) NULL,
        DepartmentId        INT NULL,
        PartyCellId         INT NULL,
        IsActive             BIT NOT NULL CONSTRAINT DF_UserAccount_IsActive DEFAULT 1,
        LastLoginAt          DATETIME2(0) NULL,
        CreatedAt            DATETIME2(0) NOT NULL CONSTRAINT DF_UserAccount_CreatedAt DEFAULT SYSDATETIME(),
        UpdatedAt            DATETIME2(0) NULL,
        CONSTRAINT FK_UserAccount_Department
            FOREIGN KEY (DepartmentId) REFERENCES Master.Department(DepartmentId),
        CONSTRAINT FK_UserAccount_PartyCell
            FOREIGN KEY (PartyCellId) REFERENCES Master.PartyCell(PartyCellId)
    );
END
GO

IF OBJECT_ID(N'Auth.UserRole','U') IS NULL
BEGIN
    CREATE TABLE Auth.UserRole
    (
        UserId INT NOT NULL,
        RoleId INT NOT NULL,
        AssignedAt DATETIME2(0) NOT NULL CONSTRAINT DF_UserRole_AssignedAt DEFAULT SYSDATETIME(),
        CONSTRAINT PK_UserRole PRIMARY KEY (UserId, RoleId),
        CONSTRAINT FK_UserRole_User FOREIGN KEY (UserId) REFERENCES Auth.UserAccount(UserId),
        CONSTRAINT FK_UserRole_Role FOREIGN KEY (RoleId) REFERENCES Auth.Role(RoleId)
    );
END
GO

IF OBJECT_ID(N'Auth.RolePermission','U') IS NULL
BEGIN
    CREATE TABLE Auth.RolePermission
    (
        RoleId       INT NOT NULL,
        PermissionId INT NOT NULL,
        CONSTRAINT PK_RolePermission PRIMARY KEY (RoleId, PermissionId),
        CONSTRAINT FK_RolePermission_Role FOREIGN KEY (RoleId) REFERENCES Auth.Role(RoleId),
        CONSTRAINT FK_RolePermission_Permission FOREIGN KEY (PermissionId) REFERENCES Auth.Permission(PermissionId)
    );
END
GO

IF OBJECT_ID(N'Auth.UserScope','U') IS NULL
BEGIN
    CREATE TABLE Auth.UserScope
    (
        UserScopeId     INT IDENTITY(1,1) PRIMARY KEY,
        UserId          INT NOT NULL,
        DepartmentId    INT NULL,
        PartyCellId     INT NULL,
        CanRead         BIT NOT NULL CONSTRAINT DF_UserScope_CanRead DEFAULT 1,
        CanCreate       BIT NOT NULL CONSTRAINT DF_UserScope_CanCreate DEFAULT 0,
        CanEdit         BIT NOT NULL CONSTRAINT DF_UserScope_CanEdit DEFAULT 0,
        CanApprove      BIT NOT NULL CONSTRAINT DF_UserScope_CanApprove DEFAULT 0,
        CanPublish      BIT NOT NULL CONSTRAINT DF_UserScope_CanPublish DEFAULT 0,
        CONSTRAINT FK_UserScope_User FOREIGN KEY (UserId) REFERENCES Auth.UserAccount(UserId),
        CONSTRAINT FK_UserScope_Department FOREIGN KEY (DepartmentId) REFERENCES Master.Department(DepartmentId),
        CONSTRAINT FK_UserScope_PartyCell FOREIGN KEY (PartyCellId) REFERENCES Master.PartyCell(PartyCellId)
    );
END
GO

INSERT INTO Auth.Role(RoleCode, RoleName, Description)
SELECT 'ADMIN', N'Quản trị hệ thống', N'Toàn quyền quản trị hệ thống'
WHERE NOT EXISTS (SELECT 1 FROM Auth.Role WHERE RoleCode='ADMIN');

INSERT INTO Auth.Role(RoleCode, RoleName, Description)
SELECT 'EDITOR', N'Biên tập viên', N'Tạo và biên tập tin bài'
WHERE NOT EXISTS (SELECT 1 FROM Auth.Role WHERE RoleCode='EDITOR');

INSERT INTO Auth.Role(RoleCode, RoleName, Description)
SELECT 'APPROVER_L1', N'Duyệt cấp 1', N'Duyệt bài ở cấp thứ nhất'
WHERE NOT EXISTS (SELECT 1 FROM Auth.Role WHERE RoleCode='APPROVER_L1');

INSERT INTO Auth.Role(RoleCode, RoleName, Description)
SELECT 'APPROVER_L2', N'Duyệt cấp 2', N'Duyệt bài ở cấp thứ hai'
WHERE NOT EXISTS (SELECT 1 FROM Auth.Role WHERE RoleCode='APPROVER_L2');

INSERT INTO Auth.Role(RoleCode, RoleName, Description)
SELECT 'PUBLISHER', N'Phát hành', N'Phát hành nội dung đã được duyệt'
WHERE NOT EXISTS (SELECT 1 FROM Auth.Role WHERE RoleCode='PUBLISHER');

INSERT INTO Auth.Role(RoleCode, RoleName, Description)
SELECT 'VIEWER', N'Người xem', N'Chỉ được xem nội dung'
WHERE NOT EXISTS (SELECT 1 FROM Auth.Role WHERE RoleCode='VIEWER');
GO

INSERT INTO Auth.Permission(PermissionCode, PermissionName)
SELECT 'NEWS_VIEW', N'Xem tin bài' WHERE NOT EXISTS (SELECT 1 FROM Auth.Permission WHERE PermissionCode='NEWS_VIEW');
INSERT INTO Auth.Permission(PermissionCode, PermissionName)
SELECT 'NEWS_CREATE', N'Tạo tin bài' WHERE NOT EXISTS (SELECT 1 FROM Auth.Permission WHERE PermissionCode='NEWS_CREATE');
INSERT INTO Auth.Permission(PermissionCode, PermissionName)
SELECT 'NEWS_EDIT', N'Sửa tin bài' WHERE NOT EXISTS (SELECT 1 FROM Auth.Permission WHERE PermissionCode='NEWS_EDIT');
INSERT INTO Auth.Permission(PermissionCode, PermissionName)
SELECT 'NEWS_DELETE', N'Xóa tin bài' WHERE NOT EXISTS (SELECT 1 FROM Auth.Permission WHERE PermissionCode='NEWS_DELETE');
INSERT INTO Auth.Permission(PermissionCode, PermissionName)
SELECT 'NEWS_APPROVE_L1', N'Duyệt tin cấp 1' WHERE NOT EXISTS (SELECT 1 FROM Auth.Permission WHERE PermissionCode='NEWS_APPROVE_L1');
INSERT INTO Auth.Permission(PermissionCode, PermissionName)
SELECT 'NEWS_APPROVE_L2', N'Duyệt tin cấp 2' WHERE NOT EXISTS (SELECT 1 FROM Auth.Permission WHERE PermissionCode='NEWS_APPROVE_L2');
INSERT INTO Auth.Permission(PermissionCode, PermissionName)
SELECT 'NEWS_PUBLISH', N'Phát hành tin' WHERE NOT EXISTS (SELECT 1 FROM Auth.Permission WHERE PermissionCode='NEWS_PUBLISH');
INSERT INTO Auth.Permission(PermissionCode, PermissionName)
SELECT 'DOCUMENT_MANAGE', N'Quản lý văn bản' WHERE NOT EXISTS (SELECT 1 FROM Auth.Permission WHERE PermissionCode='DOCUMENT_MANAGE');
INSERT INTO Auth.Permission(PermissionCode, PermissionName)
SELECT 'USER_MANAGE', N'Quản lý người dùng' WHERE NOT EXISTS (SELECT 1 FROM Auth.Permission WHERE PermissionCode='USER_MANAGE');
INSERT INTO Auth.Permission(PermissionCode, PermissionName)
SELECT 'ROLE_MANAGE', N'Quản lý vai trò và quyền' WHERE NOT EXISTS (SELECT 1 FROM Auth.Permission WHERE PermissionCode='ROLE_MANAGE');
GO

INSERT INTO Auth.RolePermission(RoleId, PermissionId)
SELECT r.RoleId, p.PermissionId
FROM Auth.Role r CROSS JOIN Auth.Permission p
WHERE r.RoleCode='ADMIN'
  AND NOT EXISTS (
      SELECT 1 FROM Auth.RolePermission rp
      WHERE rp.RoleId=r.RoleId AND rp.PermissionId=p.PermissionId
  );
GO
