USE WebDangUyDs;
GO

IF OBJECT_ID(N'Content.Article','U') IS NULL
BEGIN
    CREATE TABLE Content.Article
    (
        ArticleId       BIGINT IDENTITY(1,1) PRIMARY KEY,
        CategoryId      INT NOT NULL,
        Title           NVARCHAR(500) NOT NULL,
        Summary         NVARCHAR(2000) NULL,
        ContentHtml     NVARCHAR(MAX) NOT NULL,
        CoverImageUrl   NVARCHAR(1000) NULL,
        AuthorUserId    INT NOT NULL,
        DepartmentId    INT NULL,
        PartyCellId     INT NULL,
        StatusCode      VARCHAR(30) NOT NULL CONSTRAINT DF_Article_Status DEFAULT 'DRAFT',
        PublishedAt     DATETIME2(0) NULL,
        ViewCount       BIGINT NOT NULL CONSTRAINT DF_Article_ViewCount DEFAULT 0,
        CreatedAt       DATETIME2(0) NOT NULL CONSTRAINT DF_Article_CreatedAt DEFAULT SYSDATETIME(),
        UpdatedAt       DATETIME2(0) NULL,
        CONSTRAINT FK_Article_Category FOREIGN KEY (CategoryId) REFERENCES Master.NewsCategory(NewsCategoryId),
        CONSTRAINT FK_Article_Author FOREIGN KEY (AuthorUserId) REFERENCES Auth.UserAccount(UserId),
        CONSTRAINT FK_Article_Department FOREIGN KEY (DepartmentId) REFERENCES Master.Department(DepartmentId),
        CONSTRAINT FK_Article_PartyCell FOREIGN KEY (PartyCellId) REFERENCES Master.PartyCell(PartyCellId)
    );
END
GO

IF OBJECT_ID(N'Content.Document','U') IS NULL
BEGIN
    CREATE TABLE Content.Document
    (
        DocumentId          BIGINT IDENTITY(1,1) PRIMARY KEY,
        DocumentCategoryId  INT NOT NULL,
        DocumentNumber      NVARCHAR(100) NULL,
        Title               NVARCHAR(500) NOT NULL,
        Summary             NVARCHAR(2000) NULL,
        IssuedDate          DATE NULL,
        IssuingAgency       NVARCHAR(255) NULL,
        FileUrl             NVARCHAR(1000) NULL,
        FileName             NVARCHAR(500) NULL,
        DepartmentId        INT NULL,
        CreatedByUserId     INT NOT NULL,
        IsPublished         BIT NOT NULL CONSTRAINT DF_Document_IsPublished DEFAULT 0,
        ViewCount           BIGINT NOT NULL CONSTRAINT DF_Document_ViewCount DEFAULT 0,
        CreatedAt           DATETIME2(0) NOT NULL CONSTRAINT DF_Document_CreatedAt DEFAULT SYSDATETIME(),
        CONSTRAINT FK_Document_Category FOREIGN KEY (DocumentCategoryId) REFERENCES Master.DocumentCategory(DocumentCategoryId),
        CONSTRAINT FK_Document_Department FOREIGN KEY (DepartmentId) REFERENCES Master.Department(DepartmentId),
        CONSTRAINT FK_Document_Creator FOREIGN KEY (CreatedByUserId) REFERENCES Auth.UserAccount(UserId)
    );
END
GO

IF OBJECT_ID(N'Workflow.ApprovalLevel','U') IS NULL
BEGIN
    CREATE TABLE Workflow.ApprovalLevel
    (
        ApprovalLevelId INT IDENTITY(1,1) PRIMARY KEY,
        LevelNo         INT NOT NULL UNIQUE,
        LevelName       NVARCHAR(200) NOT NULL,
        RoleCode        VARCHAR(50) NOT NULL,
        IsActive        BIT NOT NULL CONSTRAINT DF_ApprovalLevel_IsActive DEFAULT 1
    );
END
GO

IF OBJECT_ID(N'Workflow.ArticleApproval','U') IS NULL
BEGIN
    CREATE TABLE Workflow.ArticleApproval
    (
        ArticleApprovalId BIGINT IDENTITY(1,1) PRIMARY KEY,
        ArticleId         BIGINT NOT NULL,
        ApprovalLevelId   INT NOT NULL,
        ApproverUserId    INT NULL,
        StatusCode        VARCHAR(30) NOT NULL CONSTRAINT DF_ArticleApproval_Status DEFAULT 'PENDING',
        Comment           NVARCHAR(2000) NULL,
        ApprovedAt        DATETIME2(0) NULL,
        CreatedAt         DATETIME2(0) NOT NULL CONSTRAINT DF_ArticleApproval_CreatedAt DEFAULT SYSDATETIME(),
        CONSTRAINT FK_ArticleApproval_Article FOREIGN KEY (ArticleId) REFERENCES Content.Article(ArticleId),
        CONSTRAINT FK_ArticleApproval_Level FOREIGN KEY (ApprovalLevelId) REFERENCES Workflow.ApprovalLevel(ApprovalLevelId),
        CONSTRAINT FK_ArticleApproval_User FOREIGN KEY (ApproverUserId) REFERENCES Auth.UserAccount(UserId)
    );
END
GO

IF OBJECT_ID(N'Workflow.ApprovalHistory','U') IS NULL
BEGIN
    CREATE TABLE Workflow.ApprovalHistory
    (
        ApprovalHistoryId BIGINT IDENTITY(1,1) PRIMARY KEY,
        ArticleId         BIGINT NOT NULL,
        ApprovalLevelId   INT NULL,
        UserId            INT NOT NULL,
        ActionCode        VARCHAR(30) NOT NULL,
        Comment           NVARCHAR(2000) NULL,
        CreatedAt         DATETIME2(0) NOT NULL CONSTRAINT DF_ApprovalHistory_CreatedAt DEFAULT SYSDATETIME(),
        CONSTRAINT FK_ApprovalHistory_Article FOREIGN KEY (ArticleId) REFERENCES Content.Article(ArticleId),
        CONSTRAINT FK_ApprovalHistory_Level FOREIGN KEY (ApprovalLevelId) REFERENCES Workflow.ApprovalLevel(ApprovalLevelId),
        CONSTRAINT FK_ApprovalHistory_User FOREIGN KEY (UserId) REFERENCES Auth.UserAccount(UserId)
    );
END
GO

INSERT INTO Workflow.ApprovalLevel(LevelNo, LevelName, RoleCode)
SELECT 1, N'Duyệt cấp 1', 'APPROVER_L1'
WHERE NOT EXISTS (SELECT 1 FROM Workflow.ApprovalLevel WHERE LevelNo=1);

INSERT INTO Workflow.ApprovalLevel(LevelNo, LevelName, RoleCode)
SELECT 2, N'Duyệt cấp 2', 'APPROVER_L2'
WHERE NOT EXISTS (SELECT 1 FROM Workflow.ApprovalLevel WHERE LevelNo=2);
GO

INSERT INTO Master.NewsCategory(CategoryCode, CategoryName, SortOrder)
SELECT 'TIN_DANG', N'Tin Đảng', 1
WHERE NOT EXISTS (SELECT 1 FROM Master.NewsCategory WHERE CategoryCode='TIN_DANG');

INSERT INTO Master.NewsCategory(CategoryCode, CategoryName, SortOrder)
SELECT 'HOAT_DONG', N'Hoạt động Đảng ủy', 2
WHERE NOT EXISTS (SELECT 1 FROM Master.NewsCategory WHERE CategoryCode='HOAT_DONG');

INSERT INTO Master.NewsCategory(CategoryCode, CategoryName, SortOrder)
SELECT 'TUYEN_TRUYEN', N'Tuyên truyền', 3
WHERE NOT EXISTS (SELECT 1 FROM Master.NewsCategory WHERE CategoryCode='TUYEN_TRUYEN');

INSERT INTO Master.NewsCategory(CategoryCode, CategoryName, SortOrder)
SELECT 'CHINH_SACH', N'Chính sách', 4
WHERE NOT EXISTS (SELECT 1 FROM Master.NewsCategory WHERE CategoryCode='CHINH_SACH');
GO

INSERT INTO Master.DocumentCategory(CategoryCode, CategoryName, SortOrder)
SELECT 'NGHI_QUYET', N'Nghị quyết', 1
WHERE NOT EXISTS (SELECT 1 FROM Master.DocumentCategory WHERE CategoryCode='NGHI_QUYET');

INSERT INTO Master.DocumentCategory(CategoryCode, CategoryName, SortOrder)
SELECT 'CHI_THI', N'Chỉ thị', 2
WHERE NOT EXISTS (SELECT 1 FROM Master.DocumentCategory WHERE CategoryCode='CHI_THI');

INSERT INTO Master.DocumentCategory(CategoryCode, CategoryName, SortOrder)
SELECT 'QUYET_DINH', N'Quyết định', 3
WHERE NOT EXISTS (SELECT 1 FROM Master.DocumentCategory WHERE CategoryCode='QUYET_DINH');

INSERT INTO Master.DocumentCategory(CategoryCode, CategoryName, SortOrder)
SELECT 'KE_HOACH', N'Kế hoạch', 4
WHERE NOT EXISTS (SELECT 1 FROM Master.DocumentCategory WHERE CategoryCode='KE_HOACH');
GO
