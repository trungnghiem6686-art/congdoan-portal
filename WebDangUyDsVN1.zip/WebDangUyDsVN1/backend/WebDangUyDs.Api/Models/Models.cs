namespace WebDangUyDs.Api.Models;

public class UserAccount
{
    public int UserId { get; set; }
    public string Username { get; set; } = "";
    public string PasswordHash { get; set; } = "";
    public string FullName { get; set; } = "";
    public string? Email { get; set; }
    public string? Phone { get; set; }
    public int? DepartmentId { get; set; }
    public int? PartyCellId { get; set; }
    public bool IsActive { get; set; }
    public DateTime? LastLoginAt { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public Department? Department { get; set; }
    public PartyCell? PartyCell { get; set; }
    public ICollection<UserRole> UserRoles { get; set; } = [];
}

public class Role
{
    public int RoleId { get; set; }
    public string RoleCode { get; set; } = "";
    public string RoleName { get; set; } = "";
    public string? Description { get; set; }
    public bool IsActive { get; set; }
    public ICollection<UserRole> UserRoles { get; set; } = [];
}

public class Permission
{
    public int PermissionId { get; set; }
    public string PermissionCode { get; set; } = "";
    public string PermissionName { get; set; } = "";
    public string? Description { get; set; }
    public bool IsActive { get; set; }
}

public class UserRole
{
    public int UserId { get; set; }
    public int RoleId { get; set; }
    public DateTime AssignedAt { get; set; }
    public UserAccount User { get; set; } = null!;
    public Role Role { get; set; } = null!;
}

public class Department
{
    public int DepartmentId { get; set; }
    public string DepartmentCode { get; set; } = "";
    public string DepartmentName { get; set; } = "";
    public int? ParentDepartmentId { get; set; }
    public bool IsActive { get; set; }
    public DateTime CreatedAt { get; set; }
}

public class PartyCell
{
    public int PartyCellId { get; set; }
    public int DepartmentId { get; set; }
    public string PartyCellCode { get; set; } = "";
    public string PartyCellName { get; set; } = "";
    public bool IsActive { get; set; }
    public DateTime CreatedAt { get; set; }
    public Department? Department { get; set; }
}

public class UserScope
{
    public int UserScopeId { get; set; }
    public int UserId { get; set; }
    public int? DepartmentId { get; set; }
    public int? PartyCellId { get; set; }
    public bool CanRead { get; set; }
    public bool CanCreate { get; set; }
    public bool CanEdit { get; set; }
    public bool CanApprove { get; set; }
    public bool CanPublish { get; set; }
    public UserAccount User { get; set; } = null!;
    public Department? Department { get; set; }
    public PartyCell? PartyCell { get; set; }
}


public class NewsCategory
{
    public int NewsCategoryId { get; set; }
    public string CategoryCode { get; set; } = "";
    public string CategoryName { get; set; } = "";
    public int SortOrder { get; set; }
    public bool IsActive { get; set; }
}

public class Article
{
    public long ArticleId { get; set; }
    public int CategoryId { get; set; }
    public string Title { get; set; } = "";
    public string? Summary { get; set; }
    public string ContentHtml { get; set; } = "";
    public string? CoverImageUrl { get; set; }
    public int AuthorUserId { get; set; }
    public int? DepartmentId { get; set; }
    public int? PartyCellId { get; set; }
    public string StatusCode { get; set; } = "DRAFT";
    public DateTime? PublishedAt { get; set; }
    public long ViewCount { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
}

public class ApprovalLevel
{
    public int ApprovalLevelId { get; set; }
    public int LevelNo { get; set; }
    public string LevelName { get; set; } = "";
    public string RoleCode { get; set; } = "";
    public bool IsActive { get; set; }
}

public class ArticleApproval
{
    public long ArticleApprovalId { get; set; }
    public long ArticleId { get; set; }
    public int ApprovalLevelId { get; set; }
    public int? ApproverUserId { get; set; }
    public string StatusCode { get; set; } = "PENDING";
    public string? Comment { get; set; }
    public DateTime? ApprovedAt { get; set; }
    public DateTime CreatedAt { get; set; }
}

public class ApprovalHistory
{
    public long ApprovalHistoryId { get; set; }
    public long ArticleId { get; set; }
    public int? ApprovalLevelId { get; set; }
    public int UserId { get; set; }
    public string ActionCode { get; set; } = "";
    public string? Comment { get; set; }
    public DateTime CreatedAt { get; set; }
}


public class DocumentCategory
{
    public int DocumentCategoryId { get; set; }
    public string CategoryCode { get; set; } = "";
    public string CategoryName { get; set; } = "";
    public int SortOrder { get; set; }
    public bool IsActive { get; set; }
}

public class Document
{
    public long DocumentId { get; set; }
    public int CategoryId { get; set; }
    public string DocumentNumber { get; set; } = "";
    public string Title { get; set; } = "";
    public string? Summary { get; set; }
    public string? Signer { get; set; }
    public DateTime? IssueDate { get; set; }
    public string? IssuingUnit { get; set; }
    public string StatusCode { get; set; } = "PUBLISHED";
    public long ViewCount { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
}

public class DocumentFile
{
    public long DocumentFileId { get; set; }
    public long DocumentId { get; set; }
    public string FileName { get; set; } = "";
    public string StoredFileName { get; set; } = "";
    public string FilePath { get; set; } = "";
    public string ContentType { get; set; } = "application/octet-stream";
    public long FileSize { get; set; }
    public DateTime UploadedAt { get; set; }
}


public class WorkCalendarEvent
{
    public long WorkCalendarEventId { get; set; }
    public string Title { get; set; } = "";
    public string? Description { get; set; }
    public DateTime StartAt { get; set; }
    public DateTime EndAt { get; set; }
    public string? Location { get; set; }
    public string? Organizer { get; set; }
    public string StatusCode { get; set; } = "PUBLISHED";
    public int? DepartmentId { get; set; }
    public int? PartyCellId { get; set; }
    public int CreatedByUserId { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
}

public class PolicyQuestion
{
    public long PolicyQuestionId { get; set; }
    public string Question { get; set; } = "";
    public string? QuestionerName { get; set; }
    public string? QuestionerEmail { get; set; }
    public string? CategoryCode { get; set; }
    public string StatusCode { get; set; } = "PENDING";
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
}

public class PolicyAnswer
{
    public long PolicyAnswerId { get; set; }
    public long PolicyQuestionId { get; set; }
    public int AnsweredByUserId { get; set; }
    public string Answer { get; set; } = "";
    public bool IsPublished { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? PublishedAt { get; set; }
}


public class NewsletterSubscriber
{
    public long NewsletterSubscriberId { get; set; }
    public string Email { get; set; } = "";
    public string? FullName { get; set; }
    public bool IsConfirmed { get; set; }
    public bool IsActive { get; set; } = true;
    public string UnsubscribeToken { get; set; } = "";
    public DateTime CreatedAt { get; set; }
    public DateTime? ConfirmedAt { get; set; }
    public DateTime? UnsubscribedAt { get; set; }
}

public class CampaignBanner
{
    public long CampaignBannerId { get; set; }
    public string CampaignName { get; set; } = "";
    public string Title { get; set; } = "";
    public string? Subtitle { get; set; }
    public string ImageUrl { get; set; } = "";
    public string? LinkUrl { get; set; }
    public DateTime StartAt { get; set; }
    public DateTime EndAt { get; set; }
    public int Priority { get; set; }
    public bool IsActive { get; set; }
    public DateTime CreatedAt { get; set; }
}

public class MediaContent
{
    public long MediaContentId { get; set; }
    public string MediaType { get; set; } = ""; // VIDEO / INFOGRAPHIC
    public string Title { get; set; } = "";
    public string? Description { get; set; }
    public string MediaUrl { get; set; } = "";
    public string? ThumbnailUrl { get; set; }
    public string? EmbedUrl { get; set; }
    public bool IsPublished { get; set; }
    public int SortOrder { get; set; }
    public long ViewCount { get; set; }
    public DateTime CreatedAt { get; set; }
}

public class ContentViewStat
{
    public long ContentViewStatId { get; set; }
    public string ContentType { get; set; } = "";
    public long ContentId { get; set; }
    public DateTime ViewedAt { get; set; }
    public string? IpHash { get; set; }
}

public class SearchLog
{
    public long SearchLogId { get; set; }
    public string Keyword { get; set; } = "";
    public string? SearchType { get; set; }
    public int ResultCount { get; set; }
    public DateTime CreatedAt { get; set; }
}
