using Microsoft.EntityFrameworkCore;
using WebDangUyDs.Api.Models;

namespace WebDangUyDs.Api.Data;

public class AppDbContext(DbContextOptions<AppDbContext> options) : DbContext(options)
{
    public DbSet<UserAccount> Users => Set<UserAccount>();
    public DbSet<Role> Roles => Set<Role>();
    public DbSet<Permission> Permissions => Set<Permission>();
    public DbSet<Department> Departments => Set<Department>();
    public DbSet<PartyCell> PartyCells => Set<PartyCell>();
    public DbSet<UserRole> UserRoles => Set<UserRole>();
    public DbSet<UserScope> UserScopes => Set<UserScope>();
    public DbSet<NewsCategory> NewsCategories => Set<NewsCategory>();
    public DbSet<Article> Articles => Set<Article>();
    public DbSet<ApprovalLevel> ApprovalLevels => Set<ApprovalLevel>();
    public DbSet<ArticleApproval> ArticleApprovals => Set<ArticleApproval>();
    public DbSet<ApprovalHistory> ApprovalHistories => Set<ApprovalHistory>();
    public DbSet<DocumentCategory> DocumentCategories => Set<DocumentCategory>();
    public DbSet<Document> Documents => Set<Document>();
    public DbSet<DocumentFile> DocumentFiles => Set<DocumentFile>();
    public DbSet<WorkCalendarEvent> WorkCalendarEvents => Set<WorkCalendarEvent>();
    public DbSet<PolicyQuestion> PolicyQuestions => Set<PolicyQuestion>();
    public DbSet<PolicyAnswer> PolicyAnswers => Set<PolicyAnswer>();
    public DbSet<NewsletterSubscriber> NewsletterSubscribers => Set<NewsletterSubscriber>();
    public DbSet<CampaignBanner> CampaignBanners => Set<CampaignBanner>();
    public DbSet<MediaContent> MediaContents => Set<MediaContent>();
    public DbSet<ContentViewStat> ContentViewStats => Set<ContentViewStat>();
    public DbSet<SearchLog> SearchLogs => Set<SearchLog>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        b.Entity<UserAccount>().ToTable("UserAccount", "Auth").HasKey(x => x.UserId);
        b.Entity<Role>().ToTable("Role", "Auth").HasKey(x => x.RoleId);
        b.Entity<Permission>().ToTable("Permission", "Auth").HasKey(x => x.PermissionId);
        b.Entity<UserRole>().ToTable("UserRole", "Auth");
        b.Entity<UserScope>().ToTable("UserScope", "Auth").HasKey(x => x.UserScopeId);
        b.Entity<NewsCategory>().ToTable("NewsCategory", "Master").HasKey(x => x.NewsCategoryId);
        b.Entity<Article>().ToTable("Article", "Content").HasKey(x => x.ArticleId);
        b.Entity<ApprovalLevel>().ToTable("ApprovalLevel", "Workflow").HasKey(x => x.ApprovalLevelId);
        b.Entity<ArticleApproval>().ToTable("ArticleApproval", "Workflow").HasKey(x => x.ArticleApprovalId);
        b.Entity<ApprovalHistory>().ToTable("ApprovalHistory", "Workflow").HasKey(x => x.ApprovalHistoryId);
        b.Entity<DocumentCategory>().ToTable("DocumentCategory", "Library").HasKey(x => x.DocumentCategoryId);
        b.Entity<Document>().ToTable("Document", "Library").HasKey(x => x.DocumentId);
        b.Entity<DocumentFile>().ToTable("DocumentFile", "Library").HasKey(x => x.DocumentFileId);
        b.Entity<WorkCalendarEvent>().ToTable("WorkCalendarEvent", "Calendar").HasKey(x => x.WorkCalendarEventId);
        b.Entity<PolicyQuestion>().ToTable("PolicyQuestion", "Policy").HasKey(x => x.PolicyQuestionId);
        b.Entity<PolicyAnswer>().ToTable("PolicyAnswer", "Policy").HasKey(x => x.PolicyAnswerId);
        b.Entity<NewsletterSubscriber>().ToTable("NewsletterSubscriber", "Newsletter").HasKey(x => x.NewsletterSubscriberId);
        b.Entity<CampaignBanner>().ToTable("CampaignBanner", "Campaign").HasKey(x => x.CampaignBannerId);
        b.Entity<MediaContent>().ToTable("MediaContent", "Media").HasKey(x => x.MediaContentId);
        b.Entity<ContentViewStat>().ToTable("ContentViewStat", "Analytics").HasKey(x => x.ContentViewStatId);
        b.Entity<SearchLog>().ToTable("SearchLog", "Analytics").HasKey(x => x.SearchLogId);
        b.Entity<Department>().ToTable("Department", "Master").HasKey(x => x.DepartmentId);
        b.Entity<PartyCell>().ToTable("PartyCell", "Master").HasKey(x => x.PartyCellId);

        b.Entity<UserRole>().HasKey(x => new { x.UserId, x.RoleId });
        b.Entity<UserRole>().HasOne(x => x.User).WithMany(x => x.UserRoles).HasForeignKey(x => x.UserId);
        b.Entity<UserRole>().HasOne(x => x.Role).WithMany(x => x.UserRoles).HasForeignKey(x => x.RoleId);

        b.Entity<Department>()
            .HasOne<Department>()
            .WithMany()
            .HasForeignKey(x => x.ParentDepartmentId)
            .OnDelete(DeleteBehavior.Restrict)
            .IsRequired(false);

        b.Entity<PartyCell>().HasOne(x => x.Department).WithMany().HasForeignKey(x => x.DepartmentId);
        b.Entity<UserAccount>().HasOne(x => x.Department).WithMany().HasForeignKey(x => x.DepartmentId).OnDelete(DeleteBehavior.Restrict);
        b.Entity<UserAccount>().HasOne(x => x.PartyCell).WithMany().HasForeignKey(x => x.PartyCellId).OnDelete(DeleteBehavior.Restrict);

        b.Entity<UserScope>().HasOne(x => x.User).WithMany().HasForeignKey(x => x.UserId);
        b.Entity<UserScope>().HasOne(x => x.Department).WithMany().HasForeignKey(x => x.DepartmentId).OnDelete(DeleteBehavior.Restrict);
        b.Entity<UserScope>().HasOne(x => x.PartyCell).WithMany().HasForeignKey(x => x.PartyCellId).OnDelete(DeleteBehavior.Restrict);
    }
}
