using Microsoft.EntityFrameworkCore;
using WebDangUyDs.Api.Models;

namespace WebDangUyDs.Api.Data;

public static class DevelopmentSeed
{
    public static async Task RunAsync(AppDbContext db)
    {
        // Development/test accounts. Change passwords before production.
        var roleCodes = new Dictionary<string, string>
        {
            ["ADMIN"] = "Quản trị hệ thống",
            ["DANG_UY"] = "Đảng ủy",
            ["CHI_BO"] = "Chi bộ",
            ["EDITOR"] = "Biên tập viên",
            ["VIEWER"] = "Người xem",
            ["APPROVER_L1"] = "Duyệt cấp 1",
            ["APPROVER_L2"] = "Duyệt cấp 2"
        };

        foreach (var pair in roleCodes)
        {
            if (!await db.Roles.AnyAsync(x => x.RoleCode == pair.Key))
            {
                db.Roles.Add(new Role
                {
                    RoleCode = pair.Key,
                    RoleName = pair.Value,
                    Description = "Vai trò demo của hệ thống",
                    IsActive = true
                });
            }
        }
        await db.SaveChangesAsync();

        var accounts = new[]
        {
            ("admin", "Admin@123", "Quản trị hệ thống", "ADMIN"),
            ("danguy", "DangUy@123", "Tài khoản Đảng ủy", "DANG_UY"),
            ("chibo", "ChiBo@123", "Tài khoản Chi bộ", "CHI_BO"),
            ("editor", "Editor@123", "Biên tập viên", "EDITOR"),
            ("viewer", "Viewer@123", "Người xem", "VIEWER")
        };

        foreach (var item in accounts)
        {
            var user = await db.Users.Include(x => x.UserRoles)
                .SingleOrDefaultAsync(x => x.Username == item.Item1);

            if (user is null)
            {
                user = new UserAccount
                {
                    Username = item.Item1,
                    PasswordHash = BCrypt.Net.BCrypt.HashPassword(item.Item2),
                    FullName = item.Item3,
                    IsActive = true,
                    CreatedAt = DateTime.UtcNow
                };
                db.Users.Add(user);
                await db.SaveChangesAsync();
            }

            var role = await db.Roles.SingleAsync(x => x.RoleCode == item.Item4);
            if (!await db.UserRoles.AnyAsync(x => x.UserId == user.UserId && x.RoleId == role.RoleId))
            {
                db.UserRoles.Add(new UserRole
                {
                    UserId = user.UserId,
                    RoleId = role.RoleId,
                    AssignedAt = DateTime.UtcNow
                });
                await db.SaveChangesAsync();
            }
        }
    }
}
