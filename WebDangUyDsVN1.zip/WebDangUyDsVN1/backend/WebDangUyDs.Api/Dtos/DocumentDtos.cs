namespace WebDangUyDs.Api.Dtos;

public record CreateDocumentRequest(
    int CategoryId,
    string DocumentNumber,
    string Title,
    string? Summary,
    string? Signer,
    DateTime? IssueDate,
    string? IssuingUnit);

public record UpdateDocumentRequest(
    int CategoryId,
    string DocumentNumber,
    string Title,
    string? Summary,
    string? Signer,
    DateTime? IssueDate,
    string? IssuingUnit);
