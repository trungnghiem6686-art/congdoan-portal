namespace WebDangUyDs.Api.Dtos;

public record CreatePolicyQuestionRequest(
    string Question,
    string? QuestionerName,
    string? QuestionerEmail,
    string? CategoryCode);

public record AnswerPolicyQuestionRequest(string Answer, bool Publish);
