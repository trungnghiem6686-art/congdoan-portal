namespace WebDangUyDs.Api.Dtos;

public record SubscribeRequest(string Email, string? FullName);

public record CreateBannerRequest(
    string CampaignName, string Title, string? Subtitle, string ImageUrl,
    string? LinkUrl, DateTime StartAt, DateTime EndAt, int Priority);

public record CreateMediaRequest(
    string MediaType, string Title, string? Description,
    string MediaUrl, string? ThumbnailUrl, string? EmbedUrl,
    bool IsPublished, int SortOrder);

public record SearchRequest(string Keyword, string? Type);
