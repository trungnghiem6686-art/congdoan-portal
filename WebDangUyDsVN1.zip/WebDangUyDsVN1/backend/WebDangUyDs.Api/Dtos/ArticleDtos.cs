namespace WebDangUyDs.Api.Dtos;

public record CreateArticleRequest(
    int CategoryId,
    string Title,
    string? Summary,
    string ContentHtml,
    string? CoverImageUrl,
    int? DepartmentId,
    int? PartyCellId);

public record UpdateArticleRequest(
    int CategoryId,
    string Title,
    string? Summary,
    string ContentHtml,
    string? CoverImageUrl,
    int? DepartmentId,
    int? PartyCellId);

public record SubmitArticleRequest(string? Comment);

public record ApprovalActionRequest(string Action, string? Comment);

public record ArticleSearchRequest(string? Keyword, int? CategoryId, string? StatusCode);
