namespace WebDangUyDs.Api.Dtos;

public record LoginRequest(string Username, string Password);

public record LoginResponse(
    string AccessToken,
    int UserId,
    string Username,
    string FullName,
    string[] Roles,
    int? DepartmentId,
    int? PartyCellId);

public record CreateUserRequest(
    string Username,
    string Password,
    string FullName,
    string? Email,
    string? Phone,
    int? DepartmentId,
    int? PartyCellId);

public record AssignRoleRequest(int RoleId);

public record ScopeRequest(
    int? DepartmentId,
    int? PartyCellId,
    bool CanRead,
    bool CanCreate,
    bool CanEdit,
    bool CanApprove,
    bool CanPublish);
