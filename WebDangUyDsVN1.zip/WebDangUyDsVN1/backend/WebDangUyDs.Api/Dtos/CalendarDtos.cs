namespace WebDangUyDs.Api.Dtos;

public record CreateCalendarEventRequest(
    string Title,
    string? Description,
    DateTime StartAt,
    DateTime EndAt,
    string? Location,
    string? Organizer,
    int? DepartmentId,
    int? PartyCellId);

public record UpdateCalendarEventRequest(
    string Title,
    string? Description,
    DateTime StartAt,
    DateTime EndAt,
    string? Location,
    string? Organizer,
    string StatusCode,
    int? DepartmentId,
    int? PartyCellId);
