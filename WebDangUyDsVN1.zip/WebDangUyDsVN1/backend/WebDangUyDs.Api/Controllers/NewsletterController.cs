using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebDangUyDs.Api.Data;
using WebDangUyDs.Api.Dtos;
using WebDangUyDs.Api.Models;

namespace WebDangUyDs.Api.Controllers;

[ApiController]
[Route("api/newsletter")]
public class NewsletterController(AppDbContext db) : ControllerBase
{
    [HttpPost("subscribe")]
    [AllowAnonymous]
    public async Task<IActionResult> Subscribe(SubscribeRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.Email) || !request.Email.Contains('@'))
            return BadRequest(new { message = "Email không hợp lệ." });

        var email = request.Email.Trim().ToLowerInvariant();
        var item = await db.NewsletterSubscribers.FirstOrDefaultAsync(x => x.Email == email);

        if (item != null)
        {
            item.IsActive = true;
            item.IsConfirmed = true;
            item.UnsubscribedAt = null;
        }
        else
        {
            item = new NewsletterSubscriber
            {
                Email = email,
                FullName = request.FullName,
                IsConfirmed = true,
                IsActive = true,
                UnsubscribeToken = Guid.NewGuid().ToString("N"),
                CreatedAt = DateTime.UtcNow,
                ConfirmedAt = DateTime.UtcNow
            };
            db.NewsletterSubscribers.Add(item);
        }

        await db.SaveChangesAsync();
        return Ok(new { message = "Đăng ký nhận bản tin thành công." });
    }

    [HttpGet("unsubscribe/{token}")]
    [AllowAnonymous]
    public async Task<IActionResult> Unsubscribe(string token)
    {
        var item = await db.NewsletterSubscribers.FirstOrDefaultAsync(x => x.UnsubscribeToken == token);
        if (item == null) return NotFound();

        item.IsActive = false;
        item.UnsubscribedAt = DateTime.UtcNow;
        await db.SaveChangesAsync();

        return Ok(new { message = "Đã hủy đăng ký nhận bản tin." });
    }

    [HttpGet("subscribers")]
    [Authorize(Roles = "ADMIN")]
    public async Task<IActionResult> Subscribers() =>
        Ok(await db.NewsletterSubscribers.OrderByDescending(x => x.CreatedAt).ToListAsync());
}
