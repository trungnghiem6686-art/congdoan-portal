using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebDangUyDs.Api.Data;
using WebDangUyDs.Api.Dtos;
using WebDangUyDs.Api.Models;

namespace WebDangUyDs.Api.Controllers;

[ApiController]
[Route("api/articles")]
[Authorize]
public class ArticlesController(AppDbContext db) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> Search([FromQuery] ArticleSearchRequest request)
    {
        var q = from a in db.Articles
                join c in db.NewsCategories on a.CategoryId equals c.NewsCategoryId
                join u in db.Users on a.AuthorUserId equals u.UserId
                select new
                {
                    a.ArticleId,
                    a.CategoryId,
                    CategoryName = c.CategoryName,
                    a.Title,
                    a.Summary,
                    a.CoverImageUrl,
                    a.AuthorUserId,
                    AuthorName = u.FullName,
                    a.DepartmentId,
                    a.PartyCellId,
                    a.StatusCode,
                    a.PublishedAt,
                    a.ViewCount,
                    a.CreatedAt,
                    a.UpdatedAt
                };

        if (!string.IsNullOrWhiteSpace(request.Keyword))
        {
            var keyword = request.Keyword.Trim();
            q = q.Where(x => x.Title.Contains(keyword) ||
                             (x.Summary != null && x.Summary.Contains(keyword)));
        }

        if (request.CategoryId.HasValue)
            q = q.Where(x => x.CategoryId == request.CategoryId.Value);

        if (!string.IsNullOrWhiteSpace(request.StatusCode))
            q = q.Where(x => x.StatusCode == request.StatusCode);

        return Ok(await q.OrderByDescending(x => x.CreatedAt).ToListAsync());
    }

    [HttpGet("{id:long}")]
    public async Task<IActionResult> Get(long id)
    {
        var article = await db.Articles.FindAsync(id);
        if (article is null) return NotFound();

        var approvals = await (from x in db.ArticleApprovals
                               join l in db.ApprovalLevels on x.ApprovalLevelId equals l.ApprovalLevelId
                               where x.ArticleId == id
                               orderby l.LevelNo
                               select new { x.ArticleApprovalId, l.LevelNo, l.LevelName, l.RoleCode, x.StatusCode, x.Comment, x.ApprovedAt })
                              .ToListAsync();

        return Ok(new { article, approvals });
    }

    [HttpGet("categories")]
    public async Task<IActionResult> Categories() =>
        Ok(await db.NewsCategories.Where(x => x.IsActive).OrderBy(x => x.SortOrder).ToListAsync());

    [HttpPost]
    [Authorize(Roles = "ADMIN,EDITOR")]
    public async Task<IActionResult> Create(CreateArticleRequest request)
    {
        var userId = CurrentUserId();
        var article = new Article
        {
            CategoryId = request.CategoryId,
            Title = request.Title.Trim(),
            Summary = request.Summary,
            ContentHtml = request.ContentHtml,
            CoverImageUrl = request.CoverImageUrl,
            AuthorUserId = userId,
            DepartmentId = request.DepartmentId,
            PartyCellId = request.PartyCellId,
            StatusCode = "DRAFT",
            CreatedAt = DateTime.UtcNow
        };
        db.Articles.Add(article);
        await db.SaveChangesAsync();
        return Ok(article);
    }

    [HttpPut("{id:long}")]
    [Authorize(Roles = "ADMIN,EDITOR")]
    public async Task<IActionResult> Update(long id, UpdateArticleRequest request)
    {
        var article = await db.Articles.FindAsync(id);
        if (article is null) return NotFound();

        if (article.StatusCode is "PENDING_L1" or "PENDING_L2" or "PUBLISHED")
            return Conflict(new { message = "Bài đang trong quy trình duyệt hoặc đã xuất bản, không thể sửa trực tiếp." });

        article.CategoryId = request.CategoryId;
        article.Title = request.Title.Trim();
        article.Summary = request.Summary;
        article.ContentHtml = request.ContentHtml;
        article.CoverImageUrl = request.CoverImageUrl;
        article.DepartmentId = request.DepartmentId;
        article.PartyCellId = request.PartyCellId;
        article.UpdatedAt = DateTime.UtcNow;
        await db.SaveChangesAsync();
        return Ok(article);
    }

    [HttpPost("{id:long}/submit")]
    [Authorize(Roles = "ADMIN,EDITOR")]
    public async Task<IActionResult> Submit(long id, SubmitArticleRequest request)
    {
        var article = await db.Articles.FindAsync(id);
        if (article is null) return NotFound();

        if (article.StatusCode is not ("DRAFT" or "REJECTED"))
            return Conflict(new { message = $"Không thể gửi bài ở trạng thái {article.StatusCode}." });

        var level1 = await db.ApprovalLevels.SingleOrDefaultAsync(x => x.LevelNo == 1 && x.IsActive);
        if (level1 is null) return Conflict(new { message = "Chưa cấu hình cấp duyệt 1." });

        article.StatusCode = "PENDING_L1";
        article.UpdatedAt = DateTime.UtcNow;

        db.ArticleApprovals.Add(new ArticleApproval
        {
            ArticleId = id,
            ApprovalLevelId = level1.ApprovalLevelId,
            StatusCode = "PENDING",
            CreatedAt = DateTime.UtcNow
        });

        db.ApprovalHistories.Add(new ApprovalHistory
        {
            ArticleId = id,
            ApprovalLevelId = level1.ApprovalLevelId,
            UserId = CurrentUserId(),
            ActionCode = "SUBMIT",
            Comment = request.Comment,
            CreatedAt = DateTime.UtcNow
        });

        await db.SaveChangesAsync();
        return Ok(new { message = "Đã gửi bài vào quy trình duyệt cấp 1.", statusCode = article.StatusCode });
    }

    [HttpGet("approval/pending")]
    [Authorize(Roles = "ADMIN,DANG_UY,APPROVER_L1,APPROVER_L2")]
    public async Task<IActionResult> PendingApprovals()
    {
        var roles = User.FindAll(ClaimTypes.Role).Select(x => x.Value).ToHashSet();
        var levelNos = new List<int>();
        if (roles.Contains("ADMIN") || roles.Contains("APPROVER_L1")) levelNos.Add(1);
        if (roles.Contains("ADMIN") || roles.Contains("APPROVER_L2")) levelNos.Add(2);

        var result = await (from a in db.Articles
                            join ap in db.ArticleApprovals on a.ArticleId equals ap.ArticleId
                            join l in db.ApprovalLevels on ap.ApprovalLevelId equals l.ApprovalLevelId
                            where ap.StatusCode == "PENDING" && levelNos.Contains(l.LevelNo)
                            orderby ap.CreatedAt
                            select new
                            {
                                a.ArticleId,
                                a.Title,
                                a.Summary,
                                a.StatusCode,
                                a.CreatedAt,
                                ap.ArticleApprovalId,
                                l.LevelNo,
                                l.LevelName,
                                ApprovalStatusCode = ap.StatusCode
                            }).ToListAsync();

        return Ok(result);
    }

    [HttpPost("{id:long}/approval")]
    [Authorize(Roles = "ADMIN,DANG_UY,APPROVER_L1,APPROVER_L2")]
    public async Task<IActionResult> Approval(long id, ApprovalActionRequest request)
    {
        var article = await db.Articles.FindAsync(id);
        if (article is null) return NotFound();

        var userId = CurrentUserId();
        var roles = User.FindAll(ClaimTypes.Role).Select(x => x.Value).ToHashSet();
        var levelNo = article.StatusCode == "PENDING_L1" ? 1 :
                      article.StatusCode == "PENDING_L2" ? 2 : 0;

        if (levelNo == 0) return Conflict(new { message = "Bài không ở trạng thái chờ duyệt." });

        if (!roles.Contains("ADMIN") && !roles.Contains($"APPROVER_L{levelNo}"))
            return Forbid();

        var level = await db.ApprovalLevels.SingleAsync(x => x.LevelNo == levelNo);
        var approval = await db.ArticleApprovals
            .Where(x => x.ArticleId == id && x.ApprovalLevelId == level.ApprovalLevelId && x.StatusCode == "PENDING")
            .OrderByDescending(x => x.CreatedAt)
            .FirstOrDefaultAsync();

        if (approval is null) return Conflict(new { message = "Không tìm thấy lượt duyệt đang chờ." });

        var action = request.Action.ToUpperInvariant();
        if (action is not ("APPROVE" or "REJECT"))
            return BadRequest(new { message = "Action phải là APPROVE hoặc REJECT." });

        approval.ApproverUserId = userId;
        approval.StatusCode = action == "APPROVE" ? "APPROVED" : "REJECTED";
        approval.Comment = request.Comment;
        approval.ApprovedAt = DateTime.UtcNow;

        db.ApprovalHistories.Add(new ApprovalHistory
        {
            ArticleId = id,
            ApprovalLevelId = level.ApprovalLevelId,
            UserId = userId,
            ActionCode = action,
            Comment = request.Comment,
            CreatedAt = DateTime.UtcNow
        });

        if (action == "REJECT")
        {
            article.StatusCode = "REJECTED";
        }
        else if (levelNo == 1)
        {
            var level2 = await db.ApprovalLevels.SingleOrDefaultAsync(x => x.LevelNo == 2 && x.IsActive);
            if (level2 is null)
            {
                article.StatusCode = "PUBLISHED";
                article.PublishedAt = DateTime.UtcNow;
            }
            else
            {
                article.StatusCode = "PENDING_L2";
                db.ArticleApprovals.Add(new ArticleApproval
                {
                    ArticleId = id,
                    ApprovalLevelId = level2.ApprovalLevelId,
                    StatusCode = "PENDING",
                    CreatedAt = DateTime.UtcNow
                });
            }
        }
        else
        {
            article.StatusCode = "PUBLISHED";
            article.PublishedAt = DateTime.UtcNow;
        }

        article.UpdatedAt = DateTime.UtcNow;
        await db.SaveChangesAsync();

        return Ok(new { message = action == "APPROVE" ? "Đã duyệt bài." : "Đã từ chối bài.", article.StatusCode });
    }

    [HttpPost("{id:long}/view")]
    [AllowAnonymous]
    public async Task<IActionResult> View(long id)
    {
        var article = await db.Articles.FindAsync(id);
        if (article is null || article.StatusCode != "PUBLISHED") return NotFound();

        article.ViewCount++;
        await db.SaveChangesAsync();
        return Ok(new { article.ArticleId, article.ViewCount });
    }

    private int CurrentUserId() =>
        int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
}
