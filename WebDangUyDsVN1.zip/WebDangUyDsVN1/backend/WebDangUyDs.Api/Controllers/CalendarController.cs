using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebDangUyDs.Api.Data;
using WebDangUyDs.Api.Dtos;
using WebDangUyDs.Api.Models;

namespace WebDangUyDs.Api.Controllers;

[ApiController]
[Route("api/calendar")]
public class CalendarController(AppDbContext db) : ControllerBase
{
    [HttpGet]
    [AllowAnonymous]
    public async Task<IActionResult> List(
        [FromQuery] DateTime? from,
        [FromQuery] DateTime? to,
        [FromQuery] string? keyword)
    {
        var q = db.WorkCalendarEvents.Where(x => x.StatusCode == "PUBLISHED");

        if (from.HasValue)
            q = q.Where(x => x.EndAt >= from.Value);

        if (to.HasValue)
            q = q.Where(x => x.StartAt <= to.Value);

        if (!string.IsNullOrWhiteSpace(keyword))
        {
            var k = keyword.Trim();
            q = q.Where(x => x.Title.Contains(k) ||
                             (x.Description != null && x.Description.Contains(k)) ||
                             (x.Location != null && x.Location.Contains(k)));
        }

        return Ok(await q.OrderBy(x => x.StartAt).ToListAsync());
    }

    [HttpGet("admin")]
    [Authorize(Roles = "ADMIN,DANG_UY,EDITOR,CHI_BO")]
    public async Task<IActionResult> AdminList([FromQuery] DateTime? from, [FromQuery] DateTime? to)
    {
        var q = db.WorkCalendarEvents.AsQueryable();

        if (from.HasValue) q = q.Where(x => x.EndAt >= from.Value);
        if (to.HasValue) q = q.Where(x => x.StartAt <= to.Value);

        return Ok(await q.OrderBy(x => x.StartAt).ToListAsync());
    }

    [HttpGet("{id:long}")]
    [AllowAnonymous]
    public async Task<IActionResult> Get(long id)
    {
        var item = await db.WorkCalendarEvents.FindAsync(id);
        if (item is null || item.StatusCode != "PUBLISHED") return NotFound();
        return Ok(item);
    }

    [HttpPost]
    [Authorize(Roles = "ADMIN,DANG_UY,EDITOR,CHI_BO")]
    public async Task<IActionResult> Create(CreateCalendarEventRequest request)
    {
        if (request.EndAt <= request.StartAt)
            return BadRequest(new { message = "Thời gian kết thúc phải sau thời gian bắt đầu." });

        var item = new WorkCalendarEvent
        {
            Title = request.Title.Trim(),
            Description = request.Description,
            StartAt = request.StartAt,
            EndAt = request.EndAt,
            Location = request.Location,
            Organizer = request.Organizer,
            DepartmentId = request.DepartmentId,
            PartyCellId = request.PartyCellId,
            StatusCode = "PUBLISHED",
            CreatedByUserId = CurrentUserId(),
            CreatedAt = DateTime.UtcNow
        };

        db.WorkCalendarEvents.Add(item);
        await db.SaveChangesAsync();
        return Ok(item);
    }

    [HttpPut("{id:long}")]
    [Authorize(Roles = "ADMIN,DANG_UY,EDITOR,CHI_BO")]
    public async Task<IActionResult> Update(long id, UpdateCalendarEventRequest request)
    {
        if (request.EndAt <= request.StartAt)
            return BadRequest(new { message = "Thời gian kết thúc phải sau thời gian bắt đầu." });

        var item = await db.WorkCalendarEvents.FindAsync(id);
        if (item is null) return NotFound();

        item.Title = request.Title.Trim();
        item.Description = request.Description;
        item.StartAt = request.StartAt;
        item.EndAt = request.EndAt;
        item.Location = request.Location;
        item.Organizer = request.Organizer;
        item.StatusCode = request.StatusCode;
        item.DepartmentId = request.DepartmentId;
        item.PartyCellId = request.PartyCellId;
        item.UpdatedAt = DateTime.UtcNow;

        await db.SaveChangesAsync();
        return Ok(item);
    }

    [HttpDelete("{id:long}")]
    [Authorize(Roles = "ADMIN")]
    public async Task<IActionResult> Delete(long id)
    {
        var item = await db.WorkCalendarEvents.FindAsync(id);
        if (item is null) return NotFound();

        db.WorkCalendarEvents.Remove(item);
        await db.SaveChangesAsync();
        return NoContent();
    }

    private int CurrentUserId() =>
        int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
}
