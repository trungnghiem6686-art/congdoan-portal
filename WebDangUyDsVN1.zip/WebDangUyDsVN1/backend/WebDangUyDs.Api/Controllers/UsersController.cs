using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebDangUyDs.Api.Data;
using WebDangUyDs.Api.Dtos;
using WebDangUyDs.Api.Models;

namespace WebDangUyDs.Api.Controllers;

[ApiController]
[Route("api/users")]
[Authorize(Roles = "ADMIN")]
public class UsersController(AppDbContext db) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> GetAll() =>
        Ok(await db.Users.Include(x => x.Department).Include(x => x.PartyCell)
            .Include(x => x.UserRoles).ThenInclude(x => x.Role)
            .Select(x => new {
                x.UserId, x.Username, x.FullName, x.Email, x.Phone,
                x.DepartmentId, DepartmentName = x.Department!.DepartmentName,
                x.PartyCellId, PartyCellName = x.PartyCell!.PartyCellName,
                x.IsActive,
                Roles = x.UserRoles.Select(r => r.Role.RoleCode)
            }).OrderBy(x => x.FullName).ToListAsync());

    [HttpPost]
    public async Task<IActionResult> Create(CreateUserRequest request)
    {
        if (await db.Users.AnyAsync(x => x.Username == request.Username))
            return Conflict(new { message = "Tên đăng nhập đã tồn tại." });

        var user = new UserAccount
        {
            Username = request.Username.Trim(),
            PasswordHash = BCrypt.Net.BCrypt.HashPassword(request.Password),
            FullName = request.FullName.Trim(),
            Email = request.Email,
            Phone = request.Phone,
            DepartmentId = request.DepartmentId,
            PartyCellId = request.PartyCellId,
            IsActive = true,
            CreatedAt = DateTime.UtcNow
        };
        db.Users.Add(user);
        await db.SaveChangesAsync();
        return Ok(new { user.UserId, user.Username, user.FullName });
    }

    [HttpPost("{id:int}/roles")]
    public async Task<IActionResult> AssignRole(int id, AssignRoleRequest request)
    {
        if (!await db.Users.AnyAsync(x => x.UserId == id) || !await db.Roles.AnyAsync(x => x.RoleId == request.RoleId))
            return NotFound();

        if (!await db.UserRoles.AnyAsync(x => x.UserId == id && x.RoleId == request.RoleId))
        {
            db.UserRoles.Add(new UserRole { UserId = id, RoleId = request.RoleId, AssignedAt = DateTime.UtcNow });
            await db.SaveChangesAsync();
        }
        return Ok();
    }

    [HttpPost("{id:int}/scope")]
    public async Task<IActionResult> AssignScope(int id, ScopeRequest request)
    {
        if (!await db.Users.AnyAsync(x => x.UserId == id)) return NotFound();

        var scope = new UserScope
        {
            UserId = id,
            DepartmentId = request.DepartmentId,
            PartyCellId = request.PartyCellId,
            CanRead = request.CanRead,
            CanCreate = request.CanCreate,
            CanEdit = request.CanEdit,
            CanApprove = request.CanApprove,
            CanPublish = request.CanPublish
        };
        db.UserScopes.Add(scope);
        await db.SaveChangesAsync();
        return Ok(scope);
    }
}
