using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebDangUyDs.Api.Data;
using WebDangUyDs.Api.Models;

namespace WebDangUyDs.Api.Controllers;

[ApiController]
[Route("api/departments")]
[Authorize]
public class DepartmentsController(AppDbContext db) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> GetAll() =>
        Ok(await db.Departments.Where(x => x.IsActive).OrderBy(x => x.DepartmentName).ToListAsync());

    [HttpPost]
    [Authorize(Roles = "ADMIN")]
    public async Task<IActionResult> Create(Department model)
    {
        model.DepartmentId = 0;
        model.CreatedAt = DateTime.UtcNow;
        model.IsActive = true;
        db.Departments.Add(model);
        await db.SaveChangesAsync();
        return CreatedAtAction(nameof(GetAll), new { id = model.DepartmentId }, model);
    }

    [HttpPut("{id:int}")]
    [Authorize(Roles = "ADMIN")]
    public async Task<IActionResult> Update(int id, Department input)
    {
        var item = await db.Departments.FindAsync(id);
        if (item is null) return NotFound();
        item.DepartmentCode = input.DepartmentCode;
        item.DepartmentName = input.DepartmentName;
        item.ParentDepartmentId = input.ParentDepartmentId;
        item.IsActive = input.IsActive;
        await db.SaveChangesAsync();
        return Ok(item);
    }
}
