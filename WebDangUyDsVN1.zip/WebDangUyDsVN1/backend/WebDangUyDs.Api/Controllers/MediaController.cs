using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebDangUyDs.Api.Data;
using WebDangUyDs.Api.Dtos;
using WebDangUyDs.Api.Models;

namespace WebDangUyDs.Api.Controllers;

[ApiController]
[Route("api/media")]
public class MediaController(AppDbContext db) : ControllerBase
{
    [HttpGet]
    [AllowAnonymous]
    public async Task<IActionResult> Public([FromQuery] string? type)
    {
        var q = db.MediaContents.Where(x => x.IsPublished);
        if (!string.IsNullOrWhiteSpace(type))
            q = q.Where(x => x.MediaType == type.ToUpper());

        return Ok(await q.OrderBy(x => x.SortOrder).ThenByDescending(x => x.CreatedAt).ToListAsync());
    }

    [HttpGet("admin")]
    [Authorize(Roles = "ADMIN,EDITOR")]
    public async Task<IActionResult> Admin() =>
        Ok(await db.MediaContents.OrderBy(x => x.SortOrder).ThenByDescending(x => x.CreatedAt).ToListAsync());

    [HttpPost]
    [Authorize(Roles = "ADMIN,EDITOR")]
    public async Task<IActionResult> Create(CreateMediaRequest request)
    {
        var type = request.MediaType.ToUpperInvariant();
        if (type is not ("VIDEO" or "INFOGRAPHIC"))
            return BadRequest(new { message = "MediaType chỉ hỗ trợ VIDEO hoặc INFOGRAPHIC." });

        var item = new MediaContent
        {
            MediaType = type,
            Title = request.Title.Trim(),
            Description = request.Description,
            MediaUrl = request.MediaUrl.Trim(),
            ThumbnailUrl = request.ThumbnailUrl,
            EmbedUrl = request.EmbedUrl,
            IsPublished = request.IsPublished,
            SortOrder = request.SortOrder,
            CreatedAt = DateTime.UtcNow
        };

        db.MediaContents.Add(item);
        await db.SaveChangesAsync();
        return Ok(item);
    }

    [HttpPost("{id:long}/view")]
    [AllowAnonymous]
    public async Task<IActionResult> View(long id)
    {
        var item = await db.MediaContents.FindAsync(id);
        if (item == null || !item.IsPublished) return NotFound();

        item.ViewCount++;
        db.ContentViewStats.Add(new ContentViewStat
        {
            ContentType = item.MediaType,
            ContentId = item.MediaContentId,
            ViewedAt = DateTime.UtcNow
        });
        await db.SaveChangesAsync();

        return Ok(new { item.MediaContentId, item.ViewCount });
    }
}
