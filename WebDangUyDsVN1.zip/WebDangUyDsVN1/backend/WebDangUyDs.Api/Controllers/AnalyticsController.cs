using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebDangUyDs.Api.Data;

namespace WebDangUyDs.Api.Controllers;

[ApiController]
[Route("api/analytics")]
[Authorize(Roles = "ADMIN")]
public class AnalyticsController(AppDbContext db) : ControllerBase
{
    [HttpGet("summary")]
    public async Task<IActionResult> Summary()
    {
        var articleViews = await db.Articles.SumAsync(x => (long?)x.ViewCount) ?? 0;
        var documentViews = await db.Documents.SumAsync(x => (long?)x.ViewCount) ?? 0;
        var mediaViews = await db.MediaContents.SumAsync(x => (long?)x.ViewCount) ?? 0;

        return Ok(new
        {
            articleViews,
            documentViews,
            mediaViews,
            totalViews = articleViews + documentViews + mediaViews,
            newsletterSubscribers = await db.NewsletterSubscribers.CountAsync(x => x.IsActive),
            questions = await db.PolicyQuestions.CountAsync(),
            calendarEvents = await db.WorkCalendarEvents.CountAsync()
        });
    }

    [HttpGet("daily")]
    public async Task<IActionResult> Daily([FromQuery] int days = 30)
    {
        days = Math.Clamp(days, 1, 365);
        var from = DateTime.UtcNow.Date.AddDays(-days + 1);

        var result = await db.ContentViewStats
            .Where(x => x.ViewedAt >= from)
            .GroupBy(x => x.ViewedAt.Date)
            .Select(g => new { date = g.Key, views = g.Count() })
            .OrderBy(x => x.date)
            .ToListAsync();

        return Ok(result);
    }
}
