using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebDangUyDs.Api.Data;
using WebDangUyDs.Api.Dtos;
using WebDangUyDs.Api.Models;

namespace WebDangUyDs.Api.Controllers;

[ApiController]
[Route("api/documents")]
[Authorize]
public class DocumentsController(AppDbContext db, IWebHostEnvironment env) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> Search(
        [FromQuery] string? keyword,
        [FromQuery] int? categoryId,
        [FromQuery] string? documentNumber,
        [FromQuery] DateTime? fromDate,
        [FromQuery] DateTime? toDate)
    {
        var q = from d in db.Documents
                join c in db.DocumentCategories on d.CategoryId equals c.DocumentCategoryId
                select new
                {
                    d.DocumentId,
                    d.CategoryId,
                    CategoryName = c.CategoryName,
                    d.DocumentNumber,
                    d.Title,
                    d.Summary,
                    d.Signer,
                    d.IssueDate,
                    d.IssuingUnit,
                    d.StatusCode,
                    d.ViewCount,
                    d.CreatedAt
                };

        if (!string.IsNullOrWhiteSpace(keyword))
        {
            var k = keyword.Trim();
            q = q.Where(x => x.Title.Contains(k) ||
                             x.DocumentNumber.Contains(k) ||
                             (x.Summary != null && x.Summary.Contains(k)) ||
                             (x.Signer != null && x.Signer.Contains(k)));
        }

        if (categoryId.HasValue)
            q = q.Where(x => x.CategoryId == categoryId.Value);

        if (!string.IsNullOrWhiteSpace(documentNumber))
            q = q.Where(x => x.DocumentNumber.Contains(documentNumber.Trim()));

        if (fromDate.HasValue)
            q = q.Where(x => x.IssueDate >= fromDate.Value);

        if (toDate.HasValue)
        {
            var end = toDate.Value.Date.AddDays(1);
            q = q.Where(x => x.IssueDate < end);
        }

        return Ok(await q.OrderByDescending(x => x.IssueDate).ThenByDescending(x => x.CreatedAt).ToListAsync());
    }

    [HttpGet("categories")]
    public async Task<IActionResult> Categories() =>
        Ok(await db.DocumentCategories.Where(x => x.IsActive).OrderBy(x => x.SortOrder).ToListAsync());

    [HttpGet("{id:long}")]
    public async Task<IActionResult> Get(long id)
    {
        var document = await db.Documents.FindAsync(id);
        if (document is null) return NotFound();

        var files = await db.DocumentFiles
            .Where(x => x.DocumentId == id)
            .OrderByDescending(x => x.UploadedAt)
            .ToListAsync();

        return Ok(new { document, files });
    }

    [HttpPost]
    [Authorize(Roles = "ADMIN,EDITOR")]
    public async Task<IActionResult> Create(CreateDocumentRequest request)
    {
        if (await db.Documents.AnyAsync(x => x.DocumentNumber == request.DocumentNumber))
            return Conflict(new { message = "Số hiệu văn bản đã tồn tại." });

        var item = new Document
        {
            CategoryId = request.CategoryId,
            DocumentNumber = request.DocumentNumber.Trim(),
            Title = request.Title.Trim(),
            Summary = request.Summary,
            Signer = request.Signer,
            IssueDate = request.IssueDate,
            IssuingUnit = request.IssuingUnit,
            StatusCode = "PUBLISHED",
            CreatedAt = DateTime.UtcNow
        };

        db.Documents.Add(item);
        await db.SaveChangesAsync();
        return Ok(item);
    }

    [HttpPut("{id:long}")]
    [Authorize(Roles = "ADMIN,EDITOR")]
    public async Task<IActionResult> Update(long id, UpdateDocumentRequest request)
    {
        var item = await db.Documents.FindAsync(id);
        if (item is null) return NotFound();

        if (await db.Documents.AnyAsync(x => x.DocumentId != id && x.DocumentNumber == request.DocumentNumber))
            return Conflict(new { message = "Số hiệu văn bản đã tồn tại." });

        item.CategoryId = request.CategoryId;
        item.DocumentNumber = request.DocumentNumber.Trim();
        item.Title = request.Title.Trim();
        item.Summary = request.Summary;
        item.Signer = request.Signer;
        item.IssueDate = request.IssueDate;
        item.IssuingUnit = request.IssuingUnit;
        item.UpdatedAt = DateTime.UtcNow;

        await db.SaveChangesAsync();
        return Ok(item);
    }

    [HttpPost("{id:long}/view")]
    [AllowAnonymous]
    public async Task<IActionResult> View(long id)
    {
        var item = await db.Documents.FindAsync(id);
        if (item is null || item.StatusCode != "PUBLISHED") return NotFound();

        item.ViewCount++;
        await db.SaveChangesAsync();
        return Ok(new { item.DocumentId, item.ViewCount });
    }

    [HttpPost("{id:long}/files")]
    [Authorize(Roles = "ADMIN,EDITOR")]
    [RequestSizeLimit(50_000_000)]
    public async Task<IActionResult> Upload(long id, IFormFile file)
    {
        var item = await db.Documents.FindAsync(id);
        if (item is null) return NotFound();
        if (file is null || file.Length == 0) return BadRequest(new { message = "Chưa chọn file." });

        var allowed = new[] { ".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".jpg", ".jpeg", ".png", ".zip" };
        var ext = Path.GetExtension(file.FileName).ToLowerInvariant();
        if (!allowed.Contains(ext))
            return BadRequest(new { message = "Định dạng file không được hỗ trợ." });

        var uploadRoot = Path.Combine(env.ContentRootPath, "uploads", "documents");
        Directory.CreateDirectory(uploadRoot);

        var stored = $"{Guid.NewGuid():N}{ext}";
        var physical = Path.Combine(uploadRoot, stored);

        await using (var stream = System.IO.File.Create(physical))
            await file.CopyToAsync(stream);

        var dbFile = new DocumentFile
        {
            DocumentId = id,
            FileName = Path.GetFileName(file.FileName),
            StoredFileName = stored,
            FilePath = $"/uploads/documents/{stored}",
            ContentType = file.ContentType,
            FileSize = file.Length,
            UploadedAt = DateTime.UtcNow
        };

        db.DocumentFiles.Add(dbFile);
        await db.SaveChangesAsync();

        return Ok(dbFile);
    }

    [HttpGet("files/{fileId:long}/download")]
    [AllowAnonymous]
    public async Task<IActionResult> Download(long fileId)
    {
        var file = await db.DocumentFiles.FindAsync(fileId);
        if (file is null) return NotFound();

        var physical = Path.Combine(env.ContentRootPath, file.FilePath.TrimStart('/').Replace('/', Path.DirectorySeparatorChar));
        if (!System.IO.File.Exists(physical)) return NotFound();

        return PhysicalFile(physical, file.ContentType, file.FileName);
    }
}
