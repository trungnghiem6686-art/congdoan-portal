using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebDangUyDs.Api.Data;

namespace WebDangUyDs.Api.Controllers;

[ApiController]
[Route("api/search")]
public class SearchController(AppDbContext db) : ControllerBase
{
    [HttpGet]
    [AllowAnonymous]
    public async Task<IActionResult> Search([FromQuery] string keyword)
    {
        if (string.IsNullOrWhiteSpace(keyword))
            return BadRequest(new { message = "Vui lòng nhập từ khóa." });

        var k = keyword.Trim();

        var articles = await db.Articles
            .Where(x => x.StatusCode == "PUBLISHED" &&
                (x.Title.Contains(k) || (x.Summary != null && x.Summary.Contains(k))))
            .OrderByDescending(x => x.PublishedAt)
            .Take(20)
            .Select(x => new { type = "ARTICLE", id = x.ArticleId, title = x.Title, summary = x.Summary })
            .ToListAsync();

        var documents = await db.Documents
            .Where(x => x.StatusCode == "PUBLISHED" &&
                (x.Title.Contains(k) || x.DocumentNumber.Contains(k) ||
                 (x.Summary != null && x.Summary.Contains(k))))
            .OrderByDescending(x => x.IssueDate)
            .Take(20)
            .Select(x => new { type = "DOCUMENT", id = x.DocumentId, title = x.Title, summary = x.Summary })
            .ToListAsync();

        var total = articles.Count + documents.Count;
        db.SearchLogs.Add(new Models.SearchLog
        {
            Keyword = k,
            SearchType = "ALL",
            ResultCount = total,
            CreatedAt = DateTime.UtcNow
        });
        await db.SaveChangesAsync();

        return Ok(new { keyword = k, total, articles, documents });
    }

    [HttpGet("stats")]
    [Authorize(Roles = "ADMIN")]
    public async Task<IActionResult> Stats()
    {
        var top = await db.SearchLogs
            .GroupBy(x => x.Keyword)
            .Select(g => new { keyword = g.Key, count = g.Count(), results = g.Sum(x => x.ResultCount) })
            .OrderByDescending(x => x.count)
            .Take(20)
            .ToListAsync();

        return Ok(top);
    }
}
