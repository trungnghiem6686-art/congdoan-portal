using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebDangUyDs.Api.Data;
using WebDangUyDs.Api.Models;

namespace WebDangUyDs.Api.Controllers;

[ApiController]
[Route("api/party-cells")]
[Authorize]
public class PartyCellsController(AppDbContext db) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> GetAll(int? departmentId = null)
    {
        var q = db.PartyCells.Include(x => x.Department).Where(x => x.IsActive);
        if (departmentId.HasValue) q = q.Where(x => x.DepartmentId == departmentId.Value);
        return Ok(await q.OrderBy(x => x.PartyCellName).ToListAsync());
    }

    [HttpPost]
    [Authorize(Roles = "ADMIN")]
    public async Task<IActionResult> Create(PartyCell model)
    {
        model.PartyCellId = 0;
        model.CreatedAt = DateTime.UtcNow;
        model.IsActive = true;
        db.PartyCells.Add(model);
        await db.SaveChangesAsync();
        return Ok(model);
    }

    [HttpPut("{id:int}")]
    [Authorize(Roles = "ADMIN")]
    public async Task<IActionResult> Update(int id, PartyCell input)
    {
        var item = await db.PartyCells.FindAsync(id);
        if (item is null) return NotFound();
        item.DepartmentId = input.DepartmentId;
        item.PartyCellCode = input.PartyCellCode;
        item.PartyCellName = input.PartyCellName;
        item.IsActive = input.IsActive;
        await db.SaveChangesAsync();
        return Ok(item);
    }
}
