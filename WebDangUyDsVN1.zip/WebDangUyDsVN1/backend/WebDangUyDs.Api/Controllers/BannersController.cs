using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebDangUyDs.Api.Data;
using WebDangUyDs.Api.Dtos;
using WebDangUyDs.Api.Models;

namespace WebDangUyDs.Api.Controllers;

[ApiController]
[Route("api/banners")]
public class BannersController(AppDbContext db) : ControllerBase
{
    [HttpGet]
    [AllowAnonymous]
    public async Task<IActionResult> Public()
    {
        var now = DateTime.UtcNow;
        return Ok(await db.CampaignBanners
            .Where(x => x.IsActive && x.StartAt <= now && x.EndAt >= now)
            .OrderByDescending(x => x.Priority)
            .ThenByDescending(x => x.CreatedAt)
            .ToListAsync());
    }

    [HttpGet("admin")]
    [Authorize(Roles = "ADMIN,EDITOR")]
    public async Task<IActionResult> Admin() =>
        Ok(await db.CampaignBanners.OrderByDescending(x => x.Priority).ThenByDescending(x => x.CreatedAt).ToListAsync());

    [HttpPost]
    [Authorize(Roles = "ADMIN,EDITOR")]
    public async Task<IActionResult> Create(CreateBannerRequest request)
    {
        if (request.EndAt <= request.StartAt)
            return BadRequest(new { message = "Thời gian kết thúc phải sau thời gian bắt đầu." });

        var item = new CampaignBanner
        {
            CampaignName = request.CampaignName.Trim(),
            Title = request.Title.Trim(),
            Subtitle = request.Subtitle,
            ImageUrl = request.ImageUrl.Trim(),
            LinkUrl = request.LinkUrl,
            StartAt = request.StartAt,
            EndAt = request.EndAt,
            Priority = request.Priority,
            IsActive = true,
            CreatedAt = DateTime.UtcNow
        };

        db.CampaignBanners.Add(item);
        await db.SaveChangesAsync();
        return Ok(item);
    }

    [HttpDelete("{id:long}")]
    [Authorize(Roles = "ADMIN")]
    public async Task<IActionResult> Delete(long id)
    {
        var item = await db.CampaignBanners.FindAsync(id);
        if (item == null) return NotFound();
        db.CampaignBanners.Remove(item);
        await db.SaveChangesAsync();
        return NoContent();
    }
}
