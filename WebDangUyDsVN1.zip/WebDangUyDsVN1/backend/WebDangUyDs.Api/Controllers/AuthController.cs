using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using WebDangUyDs.Api.Data;
using WebDangUyDs.Api.Dtos;
using WebDangUyDs.Api.Services;

namespace WebDangUyDs.Api.Controllers;

[ApiController]
[Route("api/auth")]
public class AuthController(AuthService auth, AppDbContext db) : ControllerBase
{
    [HttpPost("login")]
    [AllowAnonymous]
    public async Task<IActionResult> Login(LoginRequest request)
    {
        var result = await auth.LoginAsync(request);
        return result is null ? Unauthorized(new { message = "Tên đăng nhập hoặc mật khẩu không đúng." }) : Ok(result);
    }

    [HttpGet("me")]
    [Authorize]
    public async Task<IActionResult> Me()
    {
        var id = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
        var user = await db.Users.Include(x => x.UserRoles).ThenInclude(x => x.Role)
            .SingleAsync(x => x.UserId == id);

        return Ok(new
        {
            user.UserId,
            user.Username,
            user.FullName,
            user.Email,
            user.DepartmentId,
            user.PartyCellId,
            Roles = user.UserRoles.Select(x => x.Role.RoleCode)
        });
    }
}
