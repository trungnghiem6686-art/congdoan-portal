using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebDangUyDs.Api.Data;
using WebDangUyDs.Api.Dtos;
using WebDangUyDs.Api.Models;

namespace WebDangUyDs.Api.Controllers;

[ApiController]
[Route("api/policy")]
public class PolicyController(AppDbContext db) : ControllerBase
{
    [HttpGet("questions")]
    [AllowAnonymous]
    public async Task<IActionResult> PublicQuestions()
    {
        var result = await (from q in db.PolicyQuestions
                            join a in db.PolicyAnswers on q.PolicyQuestionId equals a.PolicyQuestionId into answers
                            from a in answers.Where(x => x.IsPublished).DefaultIfEmpty()
                            where q.StatusCode == "ANSWERED" && a != null
                            orderby a.PublishedAt descending
                            select new
                            {
                                q.PolicyQuestionId,
                                q.Question,
                                q.CategoryCode,
                                q.CreatedAt,
                                Answer = a!.Answer,
                                AnsweredAt = a.PublishedAt
                            }).ToListAsync();

        return Ok(result);
    }

    [HttpGet("questions/admin")]
    [Authorize(Roles = "ADMIN,EDITOR,APPROVER_L1,APPROVER_L2")]
    public async Task<IActionResult> AdminQuestions()
    {
        return Ok(await db.PolicyQuestions
            .OrderByDescending(x => x.CreatedAt)
            .ToListAsync());
    }

    [HttpPost("questions")]
    [AllowAnonymous]
    public async Task<IActionResult> Ask(CreatePolicyQuestionRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.Question))
            return BadRequest(new { message = "Nội dung câu hỏi không được để trống." });

        var item = new PolicyQuestion
        {
            Question = request.Question.Trim(),
            QuestionerName = request.QuestionerName,
            QuestionerEmail = request.QuestionerEmail,
            CategoryCode = request.CategoryCode,
            StatusCode = "PENDING",
            CreatedAt = DateTime.UtcNow
        };

        db.PolicyQuestions.Add(item);
        await db.SaveChangesAsync();

        return Ok(new { item.PolicyQuestionId, message = "Đã tiếp nhận câu hỏi. Câu trả lời sẽ được công khai sau khi xử lý." });
    }

    [HttpGet("questions/{id:long}")]
    [Authorize(Roles = "ADMIN,EDITOR,APPROVER_L1,APPROVER_L2")]
    public async Task<IActionResult> Get(long id)
    {
        var q = await db.PolicyQuestions.FindAsync(id);
        if (q is null) return NotFound();

        var answers = await db.PolicyAnswers
            .Where(x => x.PolicyQuestionId == id)
            .OrderByDescending(x => x.CreatedAt)
            .ToListAsync();

        return Ok(new { question = q, answers });
    }

    [HttpPost("questions/{id:long}/answer")]
    [Authorize(Roles = "ADMIN,EDITOR,APPROVER_L1,APPROVER_L2")]
    public async Task<IActionResult> Answer(long id, AnswerPolicyQuestionRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.Answer))
            return BadRequest(new { message = "Nội dung trả lời không được để trống." });

        var q = await db.PolicyQuestions.FindAsync(id);
        if (q is null) return NotFound();

        var userId = int.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);
        var answer = new PolicyAnswer
        {
            PolicyQuestionId = id,
            AnsweredByUserId = userId,
            Answer = request.Answer.Trim(),
            IsPublished = request.Publish,
            CreatedAt = DateTime.UtcNow,
            PublishedAt = request.Publish ? DateTime.UtcNow : null
        };

        q.StatusCode = request.Publish ? "ANSWERED" : "PROCESSING";
        q.UpdatedAt = DateTime.UtcNow;

        db.PolicyAnswers.Add(answer);
        await db.SaveChangesAsync();

        return Ok(answer);
    }
}
