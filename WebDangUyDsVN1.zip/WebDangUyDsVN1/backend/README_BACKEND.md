# Backend WebDangUyDs - Giai đoạn 1B

Backend: ASP.NET Core 8 Web API + Entity Framework Core + SQL Server + JWT.

## Chạy

Yêu cầu:
- .NET 8 SDK
- SQL Server
- Database `WebDangUyDs` đã được tạo bằng thư mục `database` ở root project.

Mở terminal:

```bash
cd backend/WebDangUyDs.Api
dotnet restore
dotnet run
```

Swagger sẽ xuất hiện ở địa chỉ do terminal báo, thường là:
`https://localhost:7xxx/swagger`

## API chính

POST `/api/auth/login`
GET `/api/auth/me`

GET/POST/PUT `/api/departments`

GET/POST/PUT `/api/party-cells`

GET/POST `/api/users`
POST `/api/users/{id}/roles`
POST `/api/users/{id}/scope`

## Tạo tài khoản admin đầu tiên

Chưa seed mật khẩu admin trong SQL để tránh plaintext password.

Có thể tạo user bằng API `/api/users`, nhưng endpoint này yêu cầu ADMIN. Ở bước tiếp theo sẽ bổ sung một cơ chế bootstrap admin an toàn cho môi trường development, sau đó khóa lại.

## Quan trọng

Đổi `Jwt:Key` trong `appsettings.json` trước khi dùng thật.
Không commit secret thật vào Git.
