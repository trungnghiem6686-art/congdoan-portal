# Giai đoạn 4 - Quản trị tin bài và duyệt bài nhiều cấp

Đã bổ sung:

## Backend
- `GET /api/articles`
- `GET /api/articles/{id}`
- `GET /api/articles/categories`
- `POST /api/articles`
- `PUT /api/articles/{id}`
- `POST /api/articles/{id}/submit`
- `GET /api/articles/approval/pending`
- `POST /api/articles/{id}/approval`
- `POST /api/articles/{id}/view`

## Luồng duyệt
DRAFT
→ PENDING_L1
→ PENDING_L2
→ PUBLISHED

Nếu từ chối:
PENDING_L1/PENDING_L2 → REJECTED

Bài REJECTED có thể sửa và gửi duyệt lại.

## Angular
- `/admin/articles`: quản trị tin bài
- `/admin/article-approval`: duyệt bài

## Database
Chạy thêm:
`database/07_ContentIndexesAndWorkflow.sql`

## Quyền
- ADMIN: toàn quyền
- EDITOR: tạo/sửa/gửi bài
- APPROVER_L1: duyệt cấp 1
- APPROVER_L2: duyệt cấp 2

Lưu ý: role phải tồn tại trong `Auth.Role`. Nếu bộ SQL hiện tại chưa có các role trên, bổ sung dữ liệu role trước khi test.
