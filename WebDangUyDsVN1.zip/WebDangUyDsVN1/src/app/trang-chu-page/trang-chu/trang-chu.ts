import { AfterViewInit, Component, OnDestroy, PLATFORM_ID, Injector, afterNextRender, inject } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';

/* ==========================================================================
 * 1. QUẢN TRỊ TIN BÀI THEO CHUYÊN MỤC
 * ========================================================================== */

export interface Category {
  id: string;
  name: string;
  parentId: string | null;
  order: number;
}

export type ArticleStatus =
  | 'DRAFT'
  | 'WAITING_LEVEL_1'
  | 'WAITING_LEVEL_2'
  | 'APPROVED'
  | 'PUBLISHED'
  | 'REJECTED'
  | 'ARCHIVED';

export interface Article {
  id: number;
  title: string;
  summary: string;
  content: string;
  categoryId: string;
  thumbnail: string;
  gallery?: string[];
  video?: string;
  attachments?: string[];
  tags: string[];
  author: string;
  publishDate: string;
  status: ArticleStatus;
  featured: boolean;
  showOnHome: boolean;
  seoUrl: string;
  metaTitle: string;
  metaDescription: string;
  views: number;
}

export interface ArticleFilter {
  keyword?: string;
  categoryId?: string;
  status?: ArticleStatus;
  authorId?: string;
  dateFrom?: string;
  dateTo?: string;
  sortBy?: 'createdAt' | 'views';
  page?: number;
  pageSize?: number;
}

export class CategoryService {
  private categories: Category[] = [
    { id: 'tin-tuc', name: 'Tin tức', parentId: null, order: 1 },
    { id: 'hoat-dong-dang-uy', name: 'Hoạt động Đảng ủy', parentId: null, order: 2 },
    { id: 'cong-tac-chi-bo', name: 'Công tác Chi bộ', parentId: null, order: 3 },
    { id: 'thong-bao', name: 'Thông báo', parentId: null, order: 4 },
    { id: 'van-ban', name: 'Văn bản', parentId: null, order: 5 },
    { id: 'huong-dan-nghiep-vu', name: 'Hướng dẫn nghiệp vụ', parentId: null, order: 6 },
    { id: 'guong-dien-hinh', name: 'Gương điển hình', parentId: null, order: 7 },
    { id: 'chinh-sach-moi', name: 'Chính sách mới', parentId: null, order: 8 },
  ];

  getTree(): Category[] {
    return [...this.categories].sort((a, b) => a.order - b.order);
  }

  create(name: string, parentId: string | null = null): Category {
    const category: Category = { id: `cat-${Date.now()}`, name, parentId, order: this.categories.length + 1 };
    this.categories.push(category);
    return category;
  }

  update(id: string, changes: Partial<Category>): boolean {
    const category = this.categories.find(c => c.id === id);
    if (!category) return false;
    Object.assign(category, changes);
    return true;
  }

  remove(id: string): boolean {
    const index = this.categories.findIndex(c => c.id === id);
    if (index === -1) return false;
    this.categories.splice(index, 1);
    return true;
  }

  reorder(id: string, newOrder: number): void {
    const category = this.categories.find(c => c.id === id);
    if (category) category.order = newOrder;
  }
}

export class ArticleService {
  private articles: Article[] = [];
  private sequence = 1;

  validate(data: Partial<Article>): string[] {
    const errors: string[] = [];
    if (!data.title?.trim()) errors.push('Tiêu đề không được để trống.');
    if (!data.content || data.content.length < 50) errors.push('Nội dung phải lớn hơn 50 ký tự.');
    if (data.thumbnail && !/\.(jpg|jpeg|png|webp)$/i.test(data.thumbnail)) errors.push('Ảnh đại diện sai định dạng.');
    return errors;
  }

  create(data: Omit<Article, 'id' | 'status' | 'views'>): { success: boolean; errors?: string[]; data?: Article } {
    const errors = this.validate(data);
    if (errors.length) return { success: false, errors };

    const article: Article = { ...data, id: this.sequence++, status: 'DRAFT', views: 0 };
    this.articles.push(article);
    return { success: true, data: article };
  }

  update(id: number, changes: Partial<Article>): boolean {
    const article = this.articles.find(a => a.id === id);
    if (!article) return false;
    Object.assign(article, changes);
    return true;
  }

  duplicate(id: number): Article | null {
    const original = this.articles.find(a => a.id === id);
    if (!original) return null;

    const copy: Article = { ...original, id: this.sequence++, title: `${original.title} (Bản sao)`, status: 'DRAFT' };
    this.articles.push(copy);
    return copy;
  }

  remove(id: number): boolean {
    const index = this.articles.findIndex(a => a.id === id);
    if (index === -1) return false;
    this.articles.splice(index, 1);
    return true;
  }

  findById(id: number): Article | null {
    return this.articles.find(a => a.id === id) ?? null;
  }

  list(filter: ArticleFilter = {}): Article[] {
    let result = [...this.articles];

    if (filter.keyword) {
      const kw = filter.keyword.toLowerCase();
      result = result.filter(a => a.title.toLowerCase().includes(kw));
    }
    if (filter.categoryId) result = result.filter(a => a.categoryId === filter.categoryId);
    if (filter.status) result = result.filter(a => a.status === filter.status);
    if (filter.authorId) result = result.filter(a => a.author === filter.authorId);
    if (filter.dateFrom) result = result.filter(a => a.publishDate >= filter.dateFrom!);
    if (filter.dateTo) result = result.filter(a => a.publishDate <= filter.dateTo!);

    result.sort((a, b) => (filter.sortBy === 'views' ? b.views - a.views : b.publishDate.localeCompare(a.publishDate)));

    const page = filter.page ?? 1;
    const pageSize = filter.pageSize ?? 10;
    return result.slice((page - 1) * pageSize, page * pageSize);
  }
}

export class UploadService {
  uploadImage(file: File): { success: boolean; url?: string; error?: string } {
    const allowed = ['image/jpeg', 'image/png', 'image/webp'];
    if (!allowed.includes(file.type)) return { success: false, error: 'Ảnh đại diện phải đúng định dạng jpg/png/webp.' };
    if (file.size > 5 * 1024 * 1024) return { success: false, error: 'Kích thước file không vượt quá 5MB.' };
    return { success: true, url: `/uploads/images/${file.name}` };
  }

  uploadFile(file: File, onProgress?: (percent: number) => void): Promise<{ success: boolean; url: string }> {
    return new Promise(resolve => {
      let percent = 0;
      const timer = setInterval(() => {
        percent += 20;
        onProgress?.(Math.min(percent, 100));
        if (percent >= 100) {
          clearInterval(timer);
          resolve({ success: true, url: `/uploads/files/${file.name}` });
        }
      }, 100);
    });
  }
}

/* ==========================================================================
 * 2. DUYỆT BÀI NHIỀU CẤP
 * ========================================================================== */

export interface ApprovalRecord {
  approver: string;
  approvedAt: string;
  comment: string;
  status: ArticleStatus;
}

export type ApprovalAction = 'APPROVE' | 'REJECT' | 'FORWARD' | 'RETURN';

export class ApprovalService {
  private readonly history = new Map<number, ApprovalRecord[]>();

  private readonly nextStatus: Record<ArticleStatus, ArticleStatus> = {
    DRAFT: 'WAITING_LEVEL_1',
    WAITING_LEVEL_1: 'WAITING_LEVEL_2',
    WAITING_LEVEL_2: 'PUBLISHED',
    APPROVED: 'PUBLISHED',
    PUBLISHED: 'PUBLISHED',
    REJECTED: 'DRAFT',
    ARCHIVED: 'ARCHIVED',
  };

  submitForReview(article: Article): Article {
    article.status = 'WAITING_LEVEL_1';
    this.record(article, 'Biên tập viên', 'Gửi Chi bộ duyệt');
    return article;
  }

  process(article: Article, approver: string, action: ApprovalAction, comment = ''): Article {
    if (action === 'REJECT') article.status = 'REJECTED';
    else if (action === 'RETURN') article.status = 'DRAFT';
    else article.status = this.nextStatus[article.status];

    this.record(article, approver, comment);
    this.notify(article, approver);
    return article;
  }

  getTimeline(articleId: number): ApprovalRecord[] {
    return this.history.get(articleId) ?? [];
  }

  private record(article: Article, approver: string, comment: string): void {
    const list = this.history.get(article.id) ?? [];
    list.push({ approver, approvedAt: new Date().toISOString(), comment, status: article.status });
    this.history.set(article.id, list);
  }

  private notify(article: Article, approver: string): void {
    // Email / Thông báo hệ thống / Push Notification khi trạng thái bài viết thay đổi
    console.log(`[Thông báo] "${article.title}" -> ${article.status} (bởi ${approver})`);
  }
}

/* ==========================================================================
 * 3. TÌM KIẾM VĂN BẢN, TIN TỨC
 * ========================================================================== */

export interface SearchFilters {
  dateFrom?: string;
  dateTo?: string;
  categoryId?: string;
  documentType?: string;
  authorId?: string;
}

export interface SearchResultItem {
  id: number;
  title: string;
  summary: string;
  date: string;
  categoryId: string;
  author: string;
  relevance: number;
}

export class SearchService {
  constructor(private readonly articleService: ArticleService) {}

  suggest(keyword: string): string[] {
    if (!keyword.trim()) return [];
    return this.articleService.list({ keyword }).slice(0, 5).map(a => a.title);
  }

  search(keyword: string, filters: SearchFilters = {}, sortBy: 'newest' | 'views' | 'relevance' = 'relevance'): SearchResultItem[] {
    const results = this.articleService.list({
      keyword,
      categoryId: filters.categoryId,
      authorId: filters.authorId,
      dateFrom: filters.dateFrom,
      dateTo: filters.dateTo,
      sortBy: sortBy === 'views' ? 'views' : undefined,
    });

    const kw = keyword.toLowerCase();
    return results.map(a => ({
      id: a.id,
      title: a.title,
      summary: a.summary,
      date: a.publishDate,
      categoryId: a.categoryId,
      author: a.author,
      relevance: kw ? a.title.toLowerCase().split(kw).length - 1 : 0,
    }));
  }
}

/* ==========================================================================
 * 4. PHÂN QUYỀN THEO ĐƠN VỊ, CHI BỘ
 * ========================================================================== */

export type SystemRole = 'ADMIN' | 'DANG_UY' | 'CHI_BO' | 'EDITOR' | 'VIEWER';

export interface AppUser {
  id: string;
  fullName: string;
  unitId: string;
  chiBoIds: string[];
  role: SystemRole;
}

export const ROLE_MENUS: Record<SystemRole, string[]> = {
  ADMIN: ['Quản trị tin bài', 'Duyệt bài', 'Phân quyền', 'Thư viện văn bản', 'Lịch công tác', 'Hỏi đáp', 'Banner', 'Thống kê'],
  DANG_UY: ['Duyệt bài', 'Thư viện văn bản', 'Lịch công tác', 'Thống kê'],
  CHI_BO: ['Quản trị tin bài (chi bộ)', 'Thư viện văn bản', 'Lịch công tác'],
  EDITOR: ['Quản trị tin bài (của tôi)'],
  VIEWER: [],
};

export class PermissionService {
  canEdit(user: AppUser, article: Article): boolean {
    if (user.role === 'ADMIN' || user.role === 'DANG_UY') return true;
    if (user.role === 'CHI_BO') return true;
    if (user.role === 'EDITOR') return article.author === user.fullName;
    return false;
  }

  canApprove(user: AppUser, level: 1 | 2): boolean {
    if (level === 1) return user.role === 'CHI_BO' || user.role === 'ADMIN';
    return user.role === 'DANG_UY' || user.role === 'ADMIN';
  }

  getMenu(user: AppUser): string[] {
    return ROLE_MENUS[user.role];
  }

  /** Ẩn/khóa các phần tử có [data-role] không khớp vai trò hiện tại (tương đương RoleDirective). */
  applyRoleVisibility(user: AppUser, root: ParentNode = document): void {
    root.querySelectorAll<HTMLElement>('[data-role]').forEach(el => {
      const allowed = el.dataset['role']?.split(',').map(r => r.trim()) ?? [];
      const visible = user.role === 'ADMIN' || allowed.includes(user.role);

      el.style.display = visible ? '' : 'none';
      if (el instanceof HTMLButtonElement) el.disabled = !visible;
    });
  }
}

/* ==========================================================================
 * 5. THƯ VIỆN VĂN BẢN / TÀI LIỆU
 * ========================================================================== */

export type DocumentType = 'PDF' | 'WORD' | 'EXCEL' | 'POWERPOINT' | 'IMAGE' | 'VIDEO';

export interface DocumentMeta {
  name: string;
  docNumber: string;
  type: DocumentType;
  issuer: string;
  issueDate: string;
  effectiveDate: string;
  field?: string;
}

export interface DocumentFile extends DocumentMeta {
  id: number;
  uploader: string;
  fileUrl: string;
  version: number;
  uploadedAt: string;
}

export class DocumentService {
  private documents: DocumentFile[] = [];
  private sequence = 1;

  upload(files: File[], meta: DocumentMeta, uploader: string, onProgress?: (percent: number) => void): DocumentFile[] {
    return files.map((file, index) => {
      onProgress?.(Math.round(((index + 1) / files.length) * 100));

      const doc: DocumentFile = {
        ...meta,
        id: this.sequence++,
        uploader,
        fileUrl: `/uploads/docs/${file.name}`,
        version: 1,
        uploadedAt: new Date().toISOString(),
      };
      this.documents.push(doc);
      return doc;
    });
  }

  list(filter: { year?: string; type?: DocumentType; issuer?: string; field?: string } = {}): DocumentFile[] {
    return this.documents.filter(d => {
      if (filter.year && !d.issueDate.startsWith(filter.year)) return false;
      if (filter.type && d.type !== filter.type) return false;
      if (filter.issuer && d.issuer !== filter.issuer) return false;
      if (filter.field && d.field !== filter.field) return false;
      return true;
    });
  }

  download(id: number): DocumentFile | null {
    return this.documents.find(d => d.id === id) ?? null;
  }

  getShareLink(id: number): string {
    return `${location.origin}/van-ban/${id}`;
  }
}

/* ==========================================================================
 * 6. LỊCH CÔNG TÁC ĐẢNG ỦY
 * ========================================================================== */

export type CalendarEventType = 'HOP_DANG_UY' | 'SINH_HOAT_CHI_BO' | 'HOI_NGHI' | 'CONG_TAC' | 'SU_KIEN';

export interface CalendarEvent {
  id: number;
  title: string;
  type: CalendarEventType;
  date: string;
  location: string;
  host: string;
  attendees: string[];
  attachments?: string[];
}

export const CALENDAR_EVENT_COLORS: Record<CalendarEventType, string> = {
  HOP_DANG_UY: '#b71c1c',
  SINH_HOAT_CHI_BO: '#1565c0',
  HOI_NGHI: '#2e7d32',
  CONG_TAC: '#f57f17',
  SU_KIEN: '#6a1b9a',
};

export class ScheduleService {
  private events: CalendarEvent[] = [
    { id: 1, title: 'Họp Ban Thường vụ Đảng ủy', type: 'HOP_DANG_UY', date: '2026-08-05', location: 'Phòng họp số 1', host: 'Bí thư Đảng ủy', attendees: ['Ban Thường vụ'] },
    { id: 2, title: 'Sinh hoạt Chi bộ khối Văn phòng', type: 'SINH_HOAT_CHI_BO', date: '2026-08-12', location: 'Phòng họp số 3', host: 'Bí thư Chi bộ', attendees: ['Đảng viên Chi bộ'] },
    { id: 3, title: 'Hội nghị sơ kết công tác quý III', type: 'HOI_NGHI', date: '2026-08-20', location: 'Hội trường tầng 5', host: 'Chủ tịch Đảng ủy', attendees: ['Toàn thể cán bộ'] },
  ];
  private sequence = 4;

  create(event: Omit<CalendarEvent, 'id'>): CalendarEvent {
    const created: CalendarEvent = { ...event, id: this.sequence++ };
    this.events.push(created);
    return created;
  }

  update(id: number, changes: Partial<CalendarEvent>): boolean {
    const event = this.events.find(e => e.id === id);
    if (!event) return false;
    Object.assign(event, changes);
    return true;
  }

  cancel(id: number): boolean {
    const index = this.events.findIndex(e => e.id === id);
    if (index === -1) return false;
    this.events.splice(index, 1);
    return true;
  }

  getByRange(view: 'day' | 'week' | 'month', reference = new Date()): CalendarEvent[] {
    const refDate = reference.toISOString().slice(0, 10);
    if (view === 'day') return this.events.filter(e => e.date === refDate);

    const end = new Date(reference);
    end.setDate(end.getDate() + (view === 'week' ? 7 : 30));
    const endDate = end.toISOString().slice(0, 10);

    return this.events.filter(e => e.date >= refDate && e.date <= endDate);
  }

  register(eventId: number, attendee: string): boolean {
    const event = this.events.find(e => e.id === eventId);
    if (!event) return false;
    if (!event.attendees.includes(attendee)) event.attendees.push(attendee);
    return true;
  }

  exportToPdf(eventId: number): string {
    const event = this.events.find(e => e.id === eventId);
    return event ? `/export/lich-cong-tac-${event.id}.pdf` : '';
  }
}

/* ==========================================================================
 * 7. HỎI ĐÁP CHÍNH SÁCH
 * ========================================================================== */

export type QuestionStatus = 'RECEIVED' | 'ASSIGNED' | 'DRAFTING' | 'PUBLISHED';

export interface QuestionTicket {
  id: number;
  title: string;
  content: string;
  field: string;
  attachment?: string;
  fullName: string;
  email: string;
  status: QuestionStatus;
  assignedTo?: string;
  answer?: string;
  rating?: number;
}

export class QAService {
  private tickets: QuestionTicket[] = [];
  private sequence = 1;

  submit(data: Omit<QuestionTicket, 'id' | 'status'>): QuestionTicket {
    const ticket: QuestionTicket = { ...data, id: this.sequence++, status: 'RECEIVED' };
    this.tickets.push(ticket);
    return ticket;
  }

  assign(id: number, staff: string): boolean {
    const ticket = this.tickets.find(t => t.id === id);
    if (!ticket) return false;
    ticket.assignedTo = staff;
    ticket.status = 'ASSIGNED';
    return true;
  }

  draftAnswer(id: number, answer: string): boolean {
    const ticket = this.tickets.find(t => t.id === id);
    if (!ticket) return false;
    ticket.answer = answer;
    ticket.status = 'DRAFTING';
    return true;
  }

  publish(id: number): boolean {
    const ticket = this.tickets.find(t => t.id === id);
    if (!ticket?.answer) return false;
    ticket.status = 'PUBLISHED';
    return true;
  }

  rate(id: number, rating: number): boolean {
    const ticket = this.tickets.find(t => t.id === id);
    if (!ticket) return false;
    ticket.rating = Math.min(5, Math.max(1, rating));
    return true;
  }

  getFAQ(): QuestionTicket[] {
    return this.tickets.filter(t => t.status === 'PUBLISHED' && (t.rating ?? 0) >= 4);
  }
}

/* ==========================================================================
 * 8. ĐĂNG KÝ NHẬN BẢN TIN
 * ========================================================================== */

export interface Subscriber {
  email: string;
  fullName: string;
  unit: string;
  categories: string[];
  confirmed: boolean;
}

export class NewsletterService {
  private readonly subscribers = new Map<string, Subscriber>();
  private readonly emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  subscribe(data: Omit<Subscriber, 'confirmed'>): { success: boolean; message: string } {
    if (!this.emailRegex.test(data.email)) return { success: false, message: 'Email không hợp lệ.' };
    if (this.subscribers.has(data.email)) return { success: false, message: 'Email đã đăng ký nhận bản tin.' };

    this.subscribers.set(data.email, { ...data, confirmed: false });
    console.log(`Gửi email xác nhận đăng ký tới ${data.email}`);
    return { success: true, message: 'Đăng ký thành công! Vui lòng kiểm tra email để xác nhận.' };
  }

  confirm(email: string): boolean {
    const subscriber = this.subscribers.get(email);
    if (!subscriber) return false;
    subscriber.confirmed = true;
    return true;
  }

  unsubscribe(email: string): boolean {
    return this.subscribers.delete(email);
  }
}

/* ==========================================================================
 * 9. BANNER TUYÊN TRUYỀN THEO CHIẾN DỊCH
 * ========================================================================== */

export interface CampaignBanner {
  id: number;
  title: string;
  imageUrl: string;
  link: string;
  startDate: string;
  endDate: string;
  priority: number;
  position: 'HOME_TOP' | 'CATEGORY_PAGE';
  status: 'ACTIVE' | 'INACTIVE';
  impressions: number;
  clicks: number;
}

export class BannerService {
  private banners: CampaignBanner[] = [
    {
      id: 1,
      title: 'Chào mừng Đại hội Đảng các cấp',
      imageUrl: '/images/banner-dai-hoi.jpg',
      link: '/chien-dich-dai-hoi',
      startDate: '2026-01-01',
      endDate: '2026-12-31',
      priority: 1,
      position: 'HOME_TOP',
      status: 'ACTIVE',
      impressions: 0,
      clicks: 0,
    },
  ];
  private sequence = 2;

  create(data: Omit<CampaignBanner, 'id' | 'impressions' | 'clicks'>): CampaignBanner {
    const banner: CampaignBanner = { ...data, id: this.sequence++, impressions: 0, clicks: 0 };
    this.banners.push(banner);
    return banner;
  }

  getActive(position: CampaignBanner['position'] = 'HOME_TOP'): CampaignBanner[] {
    const today = new Date().toISOString().slice(0, 10);
    return this.banners
      .filter(b => b.status === 'ACTIVE' && b.position === position && b.startDate <= today && b.endDate >= today)
      .sort((a, b) => a.priority - b.priority);
  }

  trackImpression(id: number): void {
    const banner = this.banners.find(b => b.id === id);
    if (banner) banner.impressions++;
  }

  trackClick(id: number): void {
    const banner = this.banners.find(b => b.id === id);
    if (banner) banner.clicks++;
  }

  getStats(id: number): { impressions: number; clicks: number; ctr: string } | null {
    const banner = this.banners.find(b => b.id === id);
    if (!banner) return null;

    const ctr = banner.impressions === 0 ? '0%' : `${((banner.clicks / banner.impressions) * 100).toFixed(1)}%`;
    return { impressions: banner.impressions, clicks: banner.clicks, ctr };
  }
}

/* ==========================================================================
 * 10. THỐNG KÊ LƯỢT ĐỌC
 * ========================================================================== */

export interface ReadStatsSummary {
  totalArticles: number;
  totalViews: number;
  totalVisitors: number;
  topArticles: { title: string; views: number }[];
  topCategories: { categoryId: string; views: number }[];
}

export class StatisticsService {
  private readonly visitors = new Set<string>();

  constructor(private readonly articleService: ArticleService) {}

  trackView(articleId: number, visitorId: string): boolean {
    const viewedKey = `viewed_${articleId}_${visitorId}`;
    if (sessionStorage.getItem(viewedKey)) return false;

    sessionStorage.setItem(viewedKey, 'true');
    this.visitors.add(visitorId);

    const article = this.articleService.findById(articleId);
    if (article) article.views++;
    return true;
  }

  getDashboard(range: 'day' | 'week' | 'month' | 'year' = 'month'): ReadStatsSummary {
    const articles = this.articleService.list({ pageSize: 1000 });

    const topArticles = [...articles]
      .sort((a, b) => b.views - a.views)
      .slice(0, 5)
      .map(a => ({ title: a.title, views: a.views }));

    const viewsByCategory = new Map<string, number>();
    articles.forEach(a => viewsByCategory.set(a.categoryId, (viewsByCategory.get(a.categoryId) ?? 0) + a.views));

    return {
      totalArticles: articles.length,
      totalViews: articles.reduce((sum, a) => sum + a.views, 0),
      totalVisitors: this.visitors.size,
      topArticles,
      topCategories: Array.from(viewsByCategory.entries()).map(([categoryId, views]) => ({ categoryId, views })),
    };
  }

  exportReport(format: 'excel' | 'pdf', range: 'day' | 'week' | 'month' | 'year' = 'month'): string {
    return `/export/thong-ke-luot-doc-${range}.${format === 'excel' ? 'xlsx' : 'pdf'}`;
  }
}

/* ==========================================================================
 * 11. TÍCH HỢP VIDEO, INFOGRAPHIC
 * ========================================================================== */

export type MediaSourceType = 'UPLOAD' | 'YOUTUBE' | 'VIMEO' | 'IMAGE' | 'SVG';

export interface MediaItem {
  id: number;
  type: MediaSourceType;
  url: string;
  title: string;
}

export class MediaService {
  private library: MediaItem[] = [];
  private sequence = 1;

  addToLibrary(type: MediaSourceType, url: string, title: string): MediaItem {
    const item: MediaItem = { id: this.sequence++, type, url, title };
    this.library.push(item);
    return item;
  }

  getLibrary(type?: MediaSourceType): MediaItem[] {
    return type ? this.library.filter(m => m.type === type) : [...this.library];
  }

  render(item: MediaItem): string {
    switch (item.type) {
      case 'YOUTUBE': {
        const match = item.url.match(/^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/);
        const videoId = match && match[2].length === 11 ? match[2] : null;
        return videoId
          ? `<div class="video-container"><iframe src="https://www.youtube.com/embed/${videoId}" frameborder="0" allowfullscreen></iframe></div>`
          : `<div>Link Youtube không hợp lệ</div>`;
      }
      case 'VIMEO': {
        const id = item.url.match(/vimeo\.com\/(\d+)/)?.[1];
        return id
          ? `<div class="video-container"><iframe src="https://player.vimeo.com/video/${id}" frameborder="0" allowfullscreen></iframe></div>`
          : `<div>Link Vimeo không hợp lệ</div>`;
      }
      case 'UPLOAD':
        return `<video controls src="${item.url}"></video>`;
      case 'SVG':
      case 'IMAGE':
        return `<img class="infographic-zoom" src="${item.url}" alt="${item.title}" />`;
    }
  }

  openFullscreen(item: MediaItem): void {
    window.open(item.url, '_blank');
  }
}

/* ==========================================================================
 * 12. GIAO DIỆN MOBILE
 * ========================================================================== */

export type Breakpoint = 'MOBILE' | 'TABLET' | 'DESKTOP';

export class ResponsiveService {
  private readonly mobileQuery = window.matchMedia('(max-width: 767px)');
  private readonly tabletQuery = window.matchMedia('(min-width: 768px) and (max-width: 1023px)');

  readonly breakpoint$ = new BehaviorSubject<Breakpoint>(this.resolve());

  private readonly onChange = () => this.breakpoint$.next(this.resolve());

  constructor() {
    this.mobileQuery.addEventListener('change', this.onChange);
    this.tabletQuery.addEventListener('change', this.onChange);
  }

  isMobile(): boolean {
    return this.mobileQuery.matches;
  }

  destroy(): void {
    this.mobileQuery.removeEventListener('change', this.onChange);
    this.tabletQuery.removeEventListener('change', this.onChange);
    this.breakpoint$.complete();
  }

  private resolve(): Breakpoint {
    if (this.mobileQuery.matches) return 'MOBILE';
    if (this.tabletQuery.matches) return 'TABLET';
    return 'DESKTOP';
  }
}

/* ==========================================================================
 * COMPONENT
 * ========================================================================== */

export interface HeroSlide {
  imageUrl: string;
  title: string;
  subtitle: string;
  linkText: string;
  link: string;
}

@Component({
  selector: 'app-trang-chu',
  imports: [],
  templateUrl: './trang-chu.html',
  styleUrl: './trang-chu.css',
})
export class TrangChu implements AfterViewInit, OnDestroy {
  private readonly platformId = inject(PLATFORM_ID);
  private readonly router = inject(Router);
  private readonly injector = inject(Injector);

  private readonly categoryService = new CategoryService();
  private readonly articleService = new ArticleService();
  private readonly uploadService = new UploadService();
  private readonly approvalService = new ApprovalService();
  private readonly searchService = new SearchService(this.articleService);
  private readonly permissionService = new PermissionService();
  private readonly documentService = new DocumentService();
  private readonly scheduleService = new ScheduleService();
  private readonly qaService = new QAService();
  private readonly newsletterService = new NewsletterService();
  private readonly bannerService = new BannerService();
  private readonly statisticsService = new StatisticsService(this.articleService);
  private readonly mediaService = new MediaService();

  // Chỉ khởi tạo trên trình duyệt: dùng window.matchMedia, không tồn tại khi render phía server (SSR)
  private responsiveService?: ResponsiveService;

  private currentUser: AppUser | null = null;
  private visitorId = '';

  private readonly heroSlides: HeroSlide[] = [
    {
      imageUrl: 'https://images.unsplash.com/photo-1541427468627-a89a96e5ca1d?q=80&w=1600&auto=format&fit=crop',
      title: 'ĐẨY MẠNH HỌC TẬP VÀ LÀM THEO TƯ TƯỞNG, ĐẠO ĐỨC, PHONG CÁCH HỒ CHÍ MINH',
      subtitle: 'GÓP PHẦN XÂY DỰNG ĐƯỜNG SẮT VIỆT NAM HIỆN ĐẠI - AN TOÀN - HIỆU QUẢ - BỀN VỮNG',
      linkText: 'XEM CHI TIẾT',
      link: '#',
    },
    {
      imageUrl: '/assets/images/hoi-nghi-tw11.jpg',
      title: 'HỘI NGHỊ BAN CHẤP HÀNH ĐẢNG BỘ ĐƯỜNG SẮT QUỐC GIA MỞ RỘNG',
      subtitle: 'ĐÁNH GIÁ KẾT QUẢ CÔNG TÁC VÀ TRIỂN KHAI NHIỆM VỤ TRỌNG TÂM THỜI GIAN TỚI',
      linkText: 'XEM CHI TIẾT',
      link: '#',
    },
    {
      imageUrl: '/assets/images/bac-ho-poster.jpg',
      title: 'HỌC TẬP VÀ LÀM THEO TẤM GƯƠNG ĐẠO ĐỨC HỒ CHÍ MINH',
      subtitle: 'LAN TỎA NHỮNG GIÁ TRỊ TỐT ĐẸP TRONG TOÀN THỂ CÁN BỘ, ĐẢNG VIÊN',
      linkText: 'XEM CHI TIẾT',
      link: '#',
    },
    {
      imageUrl: 'https://images.unsplash.com/photo-1474487548417-781cb71495f3?q=80&w=1600&auto=format&fit=crop',
      title: 'TỔNG CÔNG TY ĐSVN: ĐẢM BẢO AN TOÀN CHẠY TÀU',
      subtitle: 'SIẾT CHẶT CÔNG TÁC AN TOÀN CHẠY TÀU TRONG MỌI ĐIỀU KIỆN THỜI TIẾT',
      linkText: 'XEM CHI TIẾT',
      link: '#',
    },
    {
      imageUrl: 'https://images.unsplash.com/photo-1531482615713-2afd69097998?q=80&w=1600&auto=format&fit=crop',
      title: 'NHIỀU HOẠT ĐỘNG THIẾT THỰC HƯỞNG ỨNG THÁNG CÔNG NHÂN',
      subtitle: 'CHĂM LO ĐỜI SỐNG VẬT CHẤT, TINH THẦN CHO ĐOÀN VIÊN, NGƯỜI LAO ĐỘNG',
      linkText: 'XEM CHI TIẾT',
      link: '#',
    },
  ];

  private currentSlideIndex = 0;
  private heroSliderTimer?: ReturnType<typeof setInterval>;
  private originalTabBodyHtml: string | null = null;

  ngAfterViewInit(): void {
    if (!isPlatformBrowser(this.platformId)) return;

    // afterNextRender đảm bảo code chạy SAU khi Angular hydration hoàn tất.
    // Nếu thao tác DOM (querySelector/addEventListener) ngay trong ngAfterViewInit,
    // nó có thể chạy trước khi hydration xong, khiến Angular phát hiện DOM bị thay đổi
    // và dựng lại node từ đầu, làm mất toàn bộ listener đã gắn.
    afterNextRender(
      () => {
        this.responsiveService = new ResponsiveService();
        this.visitorId = this.getOrCreateVisitorId();

        this.initHeroSlider();
        this.initHoChiMinhGallery();
        this.initCategoryNavigation();
        this.initAdminLogin();
        this.initSearch();
        this.initDocumentLibrary();
        this.initWorkSchedule();
        this.initPolicyQA();
        this.initNewsletter();
        this.initCampaignBanner();
        this.initReadCounter();
        this.initMediaIntegration();
        this.initMobileExperience();
      },
      { injector: this.injector }
    );
  }

  ngOnDestroy(): void {
    this.responsiveService?.destroy();
    if (this.heroSliderTimer) clearInterval(this.heroSliderTimer);
  }

  // HERO SLIDER: chuyển ảnh bằng nút prev/next, chấm chỉ số, và tự động chuyển
  // Dùng event delegation trên document + truy vấn DOM lại tại thời điểm bấm,
  // vì Angular hydration có thể dựng lại các node này ngay sau khi view init chạy.
  private initHeroSlider(): void {
    const renderSlide = (index: number) => {
      const slide = this.heroSlides[index];
      const bgImg = document.querySelector<HTMLImageElement>('.slider-bg img');
      const titleEl = document.querySelector('.slider-text h2');
      const subtitleEl = document.querySelector('.slider-text p');
      const linkEl = document.querySelector<HTMLAnchorElement>('.slider-text .btn-detail');
      const dots = document.querySelectorAll('.slider-dots .dot');

      if (!bgImg || !titleEl || !subtitleEl) return;

      bgImg.src = slide.imageUrl;
      bgImg.alt = slide.title;
      titleEl.textContent = slide.title;
      subtitleEl.textContent = slide.subtitle;
      if (linkEl) {
        linkEl.textContent = slide.linkText;
        linkEl.href = slide.link;
      }

      dots.forEach((dot, i) => dot.classList.toggle('active', i === index));
      this.currentSlideIndex = index;
    };

    const goTo = (index: number) => {
      const total = this.heroSlides.length;
      renderSlide(((index % total) + total) % total);
    };

    document.addEventListener('click', e => {
      const target = e.target as Element;

      if (target.closest('.slider-btn.prev')) {
        goTo(this.currentSlideIndex - 1);
        return;
      }
      if (target.closest('.slider-btn.next')) {
        goTo(this.currentSlideIndex + 1);
        return;
      }

      const dot = target.closest('.slider-dots .dot');
      if (dot) {
        const dots = Array.from(document.querySelectorAll('.slider-dots .dot'));
        goTo(dots.indexOf(dot));
      }
    });

    this.heroSliderTimer = setInterval(() => goTo(this.currentSlideIndex + 1), 6000);
  }

  // HỌC TẬP VÀ LÀM THEO BÁC HỒ: bấm mục nhỏ để đổi ảnh lớn tương ứng
  private initHoChiMinhGallery(): void {
    document.addEventListener('click', e => {
      const item = (e.target as Element).closest<HTMLElement>('.sub-category-list .sub-cat-item');
      if (!item) return;

      const mainImg = document.querySelector<HTMLImageElement>('.ho-img-wrap .ho-img');
      const thumb = item.querySelector('img');
      if (!mainImg || !thumb) return;

      mainImg.src = thumb.src;
      mainImg.alt = thumb.alt;

      document.querySelectorAll('.sub-category-list .sub-cat-item').forEach(i => i.classList.remove('active'));
      item.classList.add('active');
    });
  }

  private getOrCreateVisitorId(): string {
    const key = 'visitor_id';
    let id = localStorage.getItem(key);
    if (!id) {
      id = `visitor-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
      localStorage.setItem(key, id);
    }
    return id;
  }

  // 1. QUẢN TRỊ TIN BÀI THEO CHUYÊN MỤC
  private initCategoryNavigation(): void {
    const selector = '.main-nav .dropdown > a, .main-nav .sub-menu a';

    document.addEventListener('click', e => {
      const link = (e.target as Element).closest<HTMLElement>(selector);
      if (!link) return;

      e.preventDefault();

      const name = link.textContent?.trim();
      if (!name) return;

      if (name === 'TIN TỨC - SỰ KIỆN') {
        this.router.navigateByUrl('/login');
        return;
      }

      document.querySelectorAll(selector).forEach(l => l.classList.remove('active'));
      link.classList.add('active');

      const categories = this.categoryService.getTree().map(c => c.name);
      console.log(`Đang xem chuyên mục "${name}". Danh mục hệ thống: ${categories.join(', ')}`);
    });
  }

  // 2. DUYỆT BÀI NHIỀU CẤP + 4. PHÂN QUYỀN THEO ĐƠN VỊ, CHI BỘ
  private initAdminLogin(): void {
    document.addEventListener('click', e => {
      if (!(e.target as Element).closest('.top-link')) return;
      e.preventDefault();
      this.loginAndOpenConsole();
    });
  }

  private loginAndOpenConsole(): void {
    const roleInput = prompt(
      'Đăng nhập quản trị - chọn vai trò (1-5)\n1: Admin\n2: Đảng ủy\n3: Chi bộ\n4: Biên tập viên\n5: Người xem'
    );

    const roleMap: Record<string, SystemRole> = { '1': 'ADMIN', '2': 'DANG_UY', '3': 'CHI_BO', '4': 'EDITOR', '5': 'VIEWER' };
    const role = roleInput ? roleMap[roleInput] : undefined;

    if (!role) {
      if (roleInput) alert('Vai trò không hợp lệ');
      return;
    }

    this.currentUser = { id: `u-${Date.now()}`, fullName: 'Người dùng demo', unitId: 'don-vi-1', chiBoIds: ['chi-bo-1'], role };
    this.permissionService.applyRoleVisibility(this.currentUser);

    const menu = this.permissionService.getMenu(this.currentUser);
    alert(`Đăng nhập thành công: ${role}\nMenu khả dụng: ${menu.join(', ') || 'Không có quyền quản trị'}`);

    if (menu.length) this.openAdminConsole();
  }

  private openAdminConsole(): void {
    if (!this.currentUser) return;

    const actions: Record<string, () => void> = {
      '1': () => this.reviewArticleFlow(),
      '2': () => this.assignUnitPermission(),
      '3': () => this.activateCampaignBannerFlow(),
      '4': () => this.showReadStatistics(),
      '5': () => this.manageDocumentFlow(),
    };

    const choice = prompt(
      `[${this.currentUser.role}] Chọn nghiệp vụ quản trị:\n` +
        '1: Duyệt bài nhiều cấp\n' +
        '2: Phân quyền theo đơn vị, chi bộ\n' +
        '3: Kích hoạt Banner tuyên truyền theo chiến dịch\n' +
        '4: Xem thống kê lượt đọc\n' +
        '5: Quản lý thư viện văn bản\n' +
        '0: Thoát'
    );

    if (!choice || choice === '0') return;

    const action = actions[choice];
    if (!action) {
      alert('Lựa chọn không hợp lệ');
      this.openAdminConsole();
      return;
    }

    action();
    this.openAdminConsole();
  }

  private reviewArticleFlow(): void {
    if (!this.currentUser) return;

    const title = prompt('Nhập tiêu đề bài viết cần duyệt');
    if (!title?.trim()) return;

    const created = this.articleService.create({
      title,
      summary: title,
      content: 'Nội dung bài viết dùng để kiểm thử quy trình duyệt nhiều cấp của Đảng ủy.',
      categoryId: 'tin-tuc',
      thumbnail: 'thumbnail.jpg',
      tags: [],
      author: this.currentUser.fullName,
      publishDate: new Date().toISOString().slice(0, 10),
      featured: false,
      showOnHome: true,
      seoUrl: title.toLowerCase().replace(/\s+/g, '-'),
      metaTitle: title,
      metaDescription: title,
    });

    if (!created.success || !created.data) {
      alert(`Không thể tạo bài viết:\n${created.errors?.join('\n')}`);
      return;
    }

    this.approvalService.submitForReview(created.data);

    const approve = confirm('Đồng ý duyệt bài? (Cancel = từ chối)');
    this.approvalService.process(created.data, this.currentUser.fullName, approve ? 'APPROVE' : 'REJECT');

    const timeline = this.approvalService.getTimeline(created.data.id);
    alert(
      `Trạng thái hiện tại: ${created.data.status}\n\nLịch sử duyệt:\n` +
        timeline.map(t => `${t.approvedAt.slice(0, 19)} - ${t.approver}: ${t.status}`).join('\n')
    );
  }

  private assignUnitPermission(): void {
    const unit = prompt('Nhập đơn vị / chi bộ cần phân quyền');
    if (!unit?.trim()) return;

    const level = prompt('Nhập quyền cấp cho đơn vị (Xem / Đăng bài / Duyệt bài)');
    alert(`Đã cấp quyền "${level || 'Xem'}" cho đơn vị/chi bộ: ${unit}`);
  }

  // 3. TÌM KIẾM VĂN BẢN, TIN TỨC
  private initSearch(): void {
    const boxSelector = '.search-box, .doc-search-box';

    const runSearchForBox = (box: Element) => {
      const input = box.querySelector('input') as HTMLInputElement | null;
      const keyword = input?.value.trim();

      if (!keyword) {
        alert('Vui lòng nhập từ khóa tìm kiếm');
        input?.focus();
        return;
      }

      const results = this.searchService.search(keyword);
      alert(results.length ? `Tìm thấy ${results.length} kết quả cho "${keyword}"` : `Không tìm thấy kết quả nào cho "${keyword}"`);
    };

    document.addEventListener('click', e => {
      const button = (e.target as Element).closest('.search-box button, .doc-search-box button');
      if (!button) return;

      e.preventDefault();
      const box = button.closest(boxSelector);
      if (box) runSearchForBox(box);
    });

    document.addEventListener('keyup', e => {
      if ((e as KeyboardEvent).key !== 'Enter') return;

      const target = e.target as HTMLElement;
      if (target.tagName !== 'INPUT') return;

      const box = target.closest(boxSelector);
      if (box) runSearchForBox(box);
    });

    document.addEventListener('input', e => {
      const target = e.target as HTMLElement;
      if (target.tagName !== 'INPUT' || !target.closest(boxSelector)) return;

      const suggestions = this.searchService.suggest((target as HTMLInputElement).value);
      if (suggestions.length) console.log('Gợi ý tìm kiếm:', suggestions);
    });
  }

  // 5. THƯ VIỆN VĂN BẢN / TÀI LIỆU
  private initDocumentLibrary(): void {
    document.addEventListener('click', e => {
      const target = e.target as Element;

      const catBtn = target.closest<HTMLElement>('.doc-cat-btn');
      if (catBtn) {
        e.preventDefault();
        const type = catBtn.textContent?.trim();
        const docs = this.documentService.list({ field: type });
        alert(`Danh mục "${type}": ${docs.length} văn bản`);
        return;
      }

      if (target.closest('.btn-archive')) {
        e.preventDefault();
        alert(`Kho văn bản điện tử: ${this.documentService.list().length} văn bản hiện có.`);
      }
    });
  }

  private manageDocumentFlow(): void {
    const name = prompt('Tên văn bản mới');
    if (!name?.trim()) return;

    const docNumber = prompt('Số văn bản') ?? '';
    const [doc] = this.documentService.upload(
      [new File([], `${name}.pdf`)],
      { name, docNumber, type: 'PDF', issuer: 'Đảng ủy', issueDate: new Date().toISOString().slice(0, 10), effectiveDate: new Date().toISOString().slice(0, 10) },
      this.currentUser?.fullName ?? 'Admin'
    );

    alert(`Đã tải lên: ${doc.name}\nLiên kết chia sẻ: ${this.documentService.getShareLink(doc.id)}`);
  }

  // 6. LỊCH CÔNG TÁC ĐẢNG ỦY
  private initWorkSchedule(): void {
    document.addEventListener('click', e => {
      const btn = (e.target as Element).closest<HTMLElement>('.tabs-container .tab-btn');
      if (!btn) return;

      document.querySelectorAll('.tabs-container .tab-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');

      const tabBody = document.querySelector('.tabs-container .tab-body') as HTMLElement | null;
      if (!tabBody) return;

      // Lưu lại nội dung gốc (Văn bản mới) trước khi bị "Lịch công tác" ghi đè lần đầu
      if (this.originalTabBodyHtml === null) {
        this.originalTabBodyHtml = tabBody.innerHTML;
      }

      if (btn.textContent?.trim() === 'Lịch công tác') {
        this.renderWorkSchedule(tabBody);
      } else {
        tabBody.innerHTML = this.originalTabBodyHtml;
      }
    });
  }

  private renderWorkSchedule(container: HTMLElement): void {
    const events = this.scheduleService.getByRange('month');

    container.innerHTML = `<ul class="document-list">${events
      .map(
        ev => `<li>
          <i class="fa-regular fa-clock pdf-icon" style="color:${CALENDAR_EVENT_COLORS[ev.type]}"></i>
          <div class="doc-details">
            <a href="#">${ev.date} - ${ev.title}</a>
            <span class="doc-date">${ev.location} · Chủ trì: ${ev.host}</span>
          </div>
        </li>`
      )
      .join('')}</ul>`;
  }

  // 7. HỎI ĐÁP CHÍNH SÁCH
  private initPolicyQA(): void {
    document.addEventListener('click', e => {
      if (!(e.target as Element).closest('.floating-widget button')) return;

      const fullName = prompt('Họ và tên của bạn');
      if (!fullName?.trim()) return;

      const email = prompt('Email liên hệ') ?? '';
      const field = prompt('Lĩnh vực câu hỏi (VD: Chính sách người lao động)') ?? 'Chung';
      const content = prompt('Nội dung câu hỏi về chính sách');

      if (!content?.trim()) {
        alert('Vui lòng nhập nội dung câu hỏi');
        return;
      }

      const ticket = this.qaService.submit({ title: content.slice(0, 40), content, field, fullName, email });
      console.log('Câu hỏi chính sách mới:', ticket);
      alert('Đã gửi câu hỏi thành công. Chúng tôi sẽ phản hồi sớm nhất!');
    });
  }

  // 8. ĐĂNG KÝ NHẬN BẢN TIN
  private initNewsletter(): void {
    document.addEventListener('click', e => {
      const trigger = (e.target as Element).closest<HTMLElement>('.btn-newsletter, .footer-col a');
      if (!trigger) return;

      const isNewsletterLink = trigger.classList.contains('btn-newsletter') || trigger.textContent?.trim() === 'Đăng ký nhận bản tin';
      if (!isNewsletterLink) return;

      e.preventDefault();
      this.subscribeNewsletterFlow();
    });
  }

  private subscribeNewsletterFlow(): void {
    const email = prompt('Nhập email để đăng ký nhận bản tin');
    if (!email?.trim()) return;

    const fullName = prompt('Họ tên') ?? '';
    const unit = prompt('Đơn vị') ?? '';

    const result = this.newsletterService.subscribe({ email, fullName, unit, categories: [] });
    alert(result.message);
  }

  // 9. BANNER TUYÊN TRUYỀN THEO CHIẾN DỊCH
  private initCampaignBanner(): void {
    const activeBanners = this.bannerService.getActive('HOME_TOP');
    activeBanners.forEach(b => this.bannerService.trackImpression(b.id));

    document.addEventListener('click', e => {
      if (!(e.target as Element).closest('.policy-banner')) return;

      const [active] = activeBanners;
      if (active) this.bannerService.trackClick(active.id);
      console.log(`Xem chi tiết banner tuyên truyền: ${active?.title ?? ''}`);
    });
  }

  private activateCampaignBannerFlow(): void {
    const title = prompt('Tên chiến dịch tuyên truyền');
    if (!title?.trim()) return;

    const imageUrl = prompt('Đường dẫn ảnh banner') ?? '';
    const link = prompt('Link đích khi bấm banner') ?? '#';

    const banner = this.bannerService.create({
      title,
      imageUrl,
      link,
      startDate: new Date().toISOString().slice(0, 10),
      endDate: '2026-12-31',
      priority: 1,
      position: 'HOME_TOP',
      status: 'ACTIVE',
    });

    alert(`Đã kích hoạt banner tuyên truyền cho chiến dịch: ${banner.title}`);
  }

  // 10. THỐNG KÊ LƯỢT ĐỌC
  private initReadCounter(): void {
    const selector = '.featured-primary h3 a, .news-item-sm h4 a, .document-list .doc-details a';

    document.addEventListener('click', e => {
      const link = (e.target as Element).closest<HTMLElement>(selector);
      if (!link) return;

      e.preventDefault();

      const links = Array.from(document.querySelectorAll(selector));
      const articleId = links.indexOf(link) + 1;
      if (articleId <= 0) return;

      this.statisticsService.trackView(articleId, this.visitorId);
      console.log(`Đã ghi nhận lượt đọc cho bài #${articleId}`);
    });
  }

  private showReadStatistics(): void {
    const summary = this.statisticsService.getDashboard('month');

    alert(
      `Tổng bài viết: ${summary.totalArticles}\n` +
        `Tổng lượt xem: ${summary.totalViews}\n` +
        `Người truy cập: ${summary.totalVisitors}\n\n` +
        `Top bài viết:\n${summary.topArticles.map(a => `${a.title}: ${a.views} lượt`).join('\n') || 'Chưa có dữ liệu'}`
    );
  }

  // 11. TÍCH HỢP VIDEO, INFOGRAPHIC
  private initMediaIntegration(): void {
    document.addEventListener('click', e => {
      const target = e.target as Element;

      if (target.closest('.video-player-thumb .play-btn')) {
        const media = this.mediaService.addToLibrary(
          'YOUTUBE',
          'https://www.youtube.com/watch?v=jZ1wFtvahN8',
          'Phim tài liệu 70 năm đường sắt Việt Nam'
        );
        console.log('Nhúng video:', this.mediaService.render(media));
        window.open(media.url, '_blank');
        return;
      }

      const videoItem = target.closest<HTMLElement>('.video-list li');
      if (videoItem) {
        const span = videoItem.querySelector('span');
        const title = span ? videoItem.textContent?.replace(span.textContent ?? '', '').trim() : videoItem.textContent?.trim();
        if (!title) return;

        const media = this.mediaService.addToLibrary('YOUTUBE', `https://www.youtube.com/results?search_query=${encodeURIComponent(title)}`, title);
        window.open(media.url, '_blank');
        return;
      }

      const photo = target.closest<HTMLImageElement>('.photo-grid img');
      if (photo) {
        const media = this.mediaService.addToLibrary('IMAGE', photo.src, 'Hình ảnh hoạt động');
        this.mediaService.openFullscreen(media);
      }
    });
  }

  // 12. GIAO DIỆN MOBILE
  private initMobileExperience(): void {
    const responsive = this.responsiveService;
    if (!responsive) return;

    responsive.breakpoint$.subscribe(bp => {
      const isMobile = bp === 'MOBILE';
      document.body.classList.toggle('is-mobile', isMobile);
      document.querySelector('.main-nav')?.classList.toggle('is-mobile', isMobile);
      this.renderBottomNav(isMobile);
    });

    this.initDropdownTapToggle();
    this.initHeroSwipe();
    this.initDarkModeToggle();
  }

  private initDropdownTapToggle(): void {
    document.addEventListener('click', e => {
      const link = (e.target as Element).closest<HTMLElement>('.main-nav .dropdown > a');
      if (!link || !this.responsiveService?.isMobile()) return;

      e.preventDefault();

      const parent = link.parentElement;
      const isOpen = parent?.classList.contains('open');

      document.querySelectorAll('.main-nav .dropdown.open').forEach(d => d.classList.remove('open'));
      if (!isOpen) parent?.classList.add('open');
    });
  }

  private initHeroSwipe(): void {
    let touchStartX = 0;

    document.addEventListener('touchstart', e => {
      if (!(e.target as Element).closest('.hero-slider')) return;
      touchStartX = (e as TouchEvent).changedTouches[0].clientX;
    });

    document.addEventListener('touchend', e => {
      if (!(e.target as Element).closest('.hero-slider')) return;

      const deltaX = (e as TouchEvent).changedTouches[0].clientX - touchStartX;
      if (Math.abs(deltaX) < 40) return;

      document.querySelector<HTMLElement>(deltaX > 0 ? '.slider-btn.prev' : '.slider-btn.next')?.click();
    });
  }

  private renderBottomNav(show: boolean): void {
    const existing = document.querySelector('.bottom-nav-mobile');

    if (!show) {
      existing?.remove();
      return;
    }
    if (existing) return;

    const nav = document.createElement('nav');
    nav.className = 'bottom-nav-mobile';
    nav.innerHTML = `
      <a href="#" data-action="home"><i class="fa-solid fa-house"></i><span>Trang chủ</span></a>
      <a href="#" data-action="search"><i class="fa-solid fa-magnifying-glass"></i><span>Tìm kiếm</span></a>
      <a href="#" data-action="category"><i class="fa-solid fa-layer-group"></i><span>Chuyên mục</span></a>
      <a href="#" data-action="qa"><i class="fa-solid fa-circle-question"></i><span>Hỏi đáp</span></a>
    `;

    nav.querySelector('[data-action="search"]')?.addEventListener('click', e => {
      e.preventDefault();
      (document.querySelector('.search-box input') as HTMLInputElement | null)?.focus();
    });

    nav.querySelector('[data-action="qa"]')?.addEventListener('click', e => {
      e.preventDefault();
      (document.querySelector('.floating-widget button') as HTMLElement | null)?.click();
    });

    document.body.appendChild(nav);
  }

  private initDarkModeToggle(): void {
    if (localStorage.getItem('theme') === 'dark') document.body.classList.add('dark-mode');

    // Nhấn đúp vào mascot ở góc màn hình để bật/tắt Dark Mode trên mobile
    document.addEventListener('dblclick', e => {
      if (!(e.target as Element).closest('.mascot-avatar')) return;

      const isDark = document.body.classList.toggle('dark-mode');
      localStorage.setItem('theme', isDark ? 'dark' : 'light');
    });
  }
}
