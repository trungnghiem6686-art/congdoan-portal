import { Routes } from '@angular/router';
import { TrangChu } from './trang-chu-page/trang-chu/trang-chu';
import { LoginComponent } from './login/login.component';
import { PublicFeaturesComponent } from './portal/public-features.component';

export const routes: Routes = [
  { path: '', component: TrangChu },
  { path: 'login', component: LoginComponent },
  { path: 'portal', component: PublicFeaturesComponent },
  {
    path: 'admin',
    loadChildren: () => import('./admin/admin.routes').then(m => m.ADMIN_ROUTES)
  },
  { path: '**', redirectTo: '' }
];
