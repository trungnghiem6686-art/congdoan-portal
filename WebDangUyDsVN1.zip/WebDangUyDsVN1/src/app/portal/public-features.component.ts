import { Component, inject, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { ApiService } from '../core/services/api.service';

@Component({
  selector: 'app-public-features',
  standalone: true,
  imports: [FormsModule, DatePipe],
  templateUrl: './public-features.component.html',
  styleUrl: './public-features.component.css'
})
export class PublicFeaturesComponent implements OnInit {
  private readonly api = inject(ApiService);

  banners: any[] = [];
  media: any[] = [];
  calendar: any[] = [];
  questions: any[] = [];
  searchResults: any = null;

  email = '';
  fullName = '';
  question = '';
  questionerName = '';
  questionerEmail = '';
  searchKeyword = '';
  message = '';

  ngOnInit() {
    this.api.get<any[]>('/banners').subscribe(x => this.banners = x);
    this.api.get<any[]>('/media').subscribe(x => this.media = x);
    this.api.get<any[]>('/calendar').subscribe(x => this.calendar = x);
    this.api.get<any[]>('/policy/questions').subscribe(x => this.questions = x);
  }

  subscribe() {
    this.api.post('/newsletter/subscribe', { email: this.email, fullName: this.fullName }).subscribe({
      next: () => this.message = 'Đăng ký nhận bản tin thành công.',
      error: e => this.message = e.error?.message || 'Không thể đăng ký.'
    });
  }

  ask() {
    this.api.post('/policy/questions', {
      question: this.question,
      questionerName: this.questionerName,
      questionerEmail: this.questionerEmail
    }).subscribe({
      next: () => {
        this.message = 'Đã gửi câu hỏi thành công.';
        this.question = '';
      },
      error: e => this.message = e.error?.message || 'Không thể gửi câu hỏi.'
    });
  }

  search() {
    if (!this.searchKeyword.trim()) return;
    this.api.get<any>(`/search?keyword=${encodeURIComponent(this.searchKeyword)}`).subscribe({
      next: x => this.searchResults = x,
      error: e => this.message = e.error?.message || 'Tìm kiếm thất bại.'
    });
  }

  mediaView(id: number) {
    this.api.post(`/media/${id}/view`, {}).subscribe();
  }
}
