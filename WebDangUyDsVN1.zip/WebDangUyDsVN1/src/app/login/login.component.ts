import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../core/services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  private readonly auth = inject(AuthService);
  private readonly router = inject(Router);

  username = '';
  password = '';
  loading = false;
  error = '';

  demoAccounts = [
    { username: 'admin', password: 'Admin@123', role: 'ADMIN - Quản trị toàn hệ thống' },
    { username: 'danguy', password: 'DangUy@123', role: 'DANG_UY - Đảng ủy' },
    { username: 'chibo', password: 'ChiBo@123', role: 'CHI_BO - Chi bộ' },
    { username: 'editor', password: 'Editor@123', role: 'EDITOR - Biên tập viên' },
    { username: 'viewer', password: 'Viewer@123', role: 'VIEWER - Người xem' }
  ];

  login(): void {
    this.error = '';
    if (!this.username.trim() || !this.password) {
      this.error = 'Vui lòng nhập tên đăng nhập và mật khẩu.';
      return;
    }

    this.loading = true;
    this.auth.login({ username: this.username.trim(), password: this.password }).subscribe({
      next: () => {
        this.loading = false;
        this.router.navigateByUrl('/admin');
      },
      error: (e: { error?: { message?: string }; status?: number }) => {
        this.loading = false;
        this.error = e.error?.message || (e.status === 401
          ? 'Tên đăng nhập hoặc mật khẩu không đúng.'
          : 'Không thể kết nối máy chủ. Hãy kiểm tra Backend API.');
      }
    });
  }

  useDemo(account: { username: string; password: string }): void {
    this.username = account.username;
    this.password = account.password;
    this.error = '';
  }
}
