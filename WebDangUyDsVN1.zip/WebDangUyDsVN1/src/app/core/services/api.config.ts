export const API_BASE_URL = 'https://localhost:7001/api';
