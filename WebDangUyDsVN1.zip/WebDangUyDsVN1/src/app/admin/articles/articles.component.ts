import { Component, inject, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/services/api.service';

interface Category { newsCategoryId: number; categoryName: string; }
interface Article {
  articleId: number;
  categoryId: number;
  categoryName: string;
  title: string;
  summary?: string;
  statusCode: string;
  authorName: string;
  viewCount: number;
  createdAt: string;
}

@Component({
  selector: 'app-admin-articles',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './articles.component.html'
})
export class ArticlesComponent implements OnInit {
  private readonly api = inject(ApiService);

  items: Article[] = [];
  categories: Category[] = [];
  keyword = '';
  categoryId: number | null = null;
  statusCode = '';
  showForm = false;
  message = '';

  form = {
    categoryId: null as number | null,
    title: '',
    summary: '',
    contentHtml: '',
    coverImageUrl: '',
    departmentId: null as number | null,
    partyCellId: null as number | null
  };

  ngOnInit() {
    this.api.get<Category[]>('/articles/categories').subscribe(x => this.categories = x);
    this.load();
  }

  load() {
    const params = new URLSearchParams();
    if (this.keyword) params.set('Keyword', this.keyword);
    if (this.categoryId) params.set('CategoryId', String(this.categoryId));
    if (this.statusCode) params.set('StatusCode', this.statusCode);

    this.api.get<Article[]>(`/articles?${params.toString()}`).subscribe({
      next: x => this.items = x,
      error: e => this.message = e.error?.message || 'Không tải được tin bài.'
    });
  }

  create() {
    if (!this.form.categoryId || !this.form.title || !this.form.contentHtml) {
      this.message = 'Vui lòng chọn chuyên mục và nhập nội dung bài.';
      return;
    }

    this.api.post('/articles', this.form).subscribe({
      next: () => {
        this.message = 'Tạo tin bài thành công.';
        this.showForm = false;
        this.form = {
          categoryId: null, title: '', summary: '', contentHtml: '',
          coverImageUrl: '', departmentId: null, partyCellId: null
        };
        this.load();
      },
      error: e => this.message = e.error?.message || 'Không thể tạo tin bài.'
    });
  }

  submit(id: number) {
    this.api.post(`/articles/${id}/submit`, { comment: 'Gửi duyệt' }).subscribe({
      next: () => this.load(),
      error: e => this.message = e.error?.message || 'Không thể gửi duyệt.'
    });
  }

  statusLabel(status: string) {
    return ({
      DRAFT: 'Bản nháp',
      PENDING_L1: 'Chờ duyệt cấp 1',
      PENDING_L2: 'Chờ duyệt cấp 2',
      PUBLISHED: 'Đã xuất bản',
      REJECTED: 'Từ chối'
    } as Record<string, string>)[status] || status;
  }
}
