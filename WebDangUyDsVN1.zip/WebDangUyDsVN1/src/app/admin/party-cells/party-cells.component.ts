import { Component, inject, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/services/api.service';

interface Department { departmentId: number; departmentName: string; }
interface PartyCell { partyCellId: number; partyCellCode: string; partyCellName: string; departmentId: number; }

@Component({
  selector: 'app-admin-party-cells',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './party-cells.component.html'
})
export class PartyCellsComponent implements OnInit {
  private readonly api = inject(ApiService);
  items: PartyCell[] = [];
  departments: Department[] = [];
  showForm = false;
  message = '';
  filterDepartmentId: number | null = null;
  form = { departmentId: null as number | null, partyCellCode: '', partyCellName: '' };

  ngOnInit() {
    this.api.get<Department[]>('/departments').subscribe(x => this.departments = x);
    this.load();
  }

  load() {
    const query = this.filterDepartmentId ? `?departmentId=${this.filterDepartmentId}` : '';
    this.api.get<PartyCell[]>(`/party-cells${query}`).subscribe({
      next: x => this.items = x,
      error: e => this.message = e.error?.message || 'Không tải được chi bộ.'
    });
  }

  create() {
    if (!this.form.departmentId || !this.form.partyCellCode || !this.form.partyCellName) {
      this.message = 'Vui lòng nhập đủ thông tin.';
      return;
    }
    this.api.post('/party-cells', this.form).subscribe({
      next: () => {
        this.message = 'Tạo chi bộ thành công.';
        this.form = { departmentId: null, partyCellCode: '', partyCellName: '' };
        this.showForm = false;
        this.load();
      },
      error: e => this.message = e.error?.message || 'Không thể tạo chi bộ.'
    });
  }
}
