import { Component, inject, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/services/api.service';

interface Department {
  departmentId: number;
  departmentCode: string;
  departmentName: string;
  parentDepartmentId?: number;
  isActive: boolean;
}

@Component({
  selector: 'app-admin-departments',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './departments.component.html'
})
export class DepartmentsComponent implements OnInit {
  private readonly api = inject(ApiService);

  items: Department[] = [];
  showForm = false;
  message = '';
  form = { departmentCode: '', departmentName: '', parentDepartmentId: null as number | null };

  ngOnInit() { this.load(); }

  load() {
    this.api.get<Department[]>('/departments').subscribe({
      next: x => this.items = x,
      error: e => this.message = e.error?.message || 'Không tải được đơn vị.'
    });
  }

  create() {
    if (!this.form.departmentCode || !this.form.departmentName) {
      this.message = 'Vui lòng nhập mã và tên đơn vị.';
      return;
    }
    this.api.post('/departments', this.form).subscribe({
      next: () => {
        this.message = 'Tạo đơn vị thành công.';
        this.form = { departmentCode: '', departmentName: '', parentDepartmentId: null };
        this.showForm = false;
        this.load();
      },
      error: e => this.message = e.error?.message || 'Không thể tạo đơn vị.'
    });
  }
}
