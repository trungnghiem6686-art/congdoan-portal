import { Component, inject, OnInit } from '@angular/core';
import { ApiService } from '../../core/services/api.service';

@Component({selector:'app-admin-analytics',standalone:true,templateUrl:'./analytics.component.html'})
export class AnalyticsComponent implements OnInit {
 private api=inject(ApiService); summary:any={}; daily:any[]=[];
 ngOnInit(){this.api.get<any>('/analytics/summary').subscribe(x=>this.summary=x);this.api.get<any[]>('/analytics/daily?days=30').subscribe(x=>this.daily=x);}
}
