import { Component, inject, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { ApiService } from '../../core/services/api.service';

interface CalendarItem {
  workCalendarEventId: number;
  title: string;
  description?: string;
  startAt: string;
  endAt: string;
  location?: string;
  organizer?: string;
  statusCode: string;
}

@Component({
  selector: 'app-admin-calendar',
  standalone: true,
  imports: [FormsModule, DatePipe],
  templateUrl: './calendar.component.html'
})
export class CalendarComponent implements OnInit {
  private readonly api = inject(ApiService);
  items: CalendarItem[] = [];
  message = '';
  showForm = false;

  form = {
    title: '',
    description: '',
    startAt: '',
    endAt: '',
    location: '',
    organizer: '',
    departmentId: null as number | null,
    partyCellId: null as number | null
  };

  ngOnInit() { this.load(); }

  load() {
    this.api.get<CalendarItem[]>('/calendar/admin').subscribe({
      next: x => this.items = x,
      error: e => this.message = e.error?.message || 'Không tải được lịch công tác.'
    });
  }

  create() {
    if (!this.form.title || !this.form.startAt || !this.form.endAt) {
      this.message = 'Vui lòng nhập tên cuộc họp và thời gian.';
      return;
    }

    this.api.post('/calendar', this.form).subscribe({
      next: () => {
        this.message = 'Đã thêm lịch công tác.';
        this.showForm = false;
        this.load();
      },
      error: e => this.message = e.error?.message || 'Không thể thêm lịch.'
    });
  }
}
