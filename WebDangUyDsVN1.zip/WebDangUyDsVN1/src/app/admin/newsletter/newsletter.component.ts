import { Component, inject, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { ApiService } from '../../core/services/api.service';

interface Subscriber {
  newsletterSubscriberId: number;
  email: string;
  fullName?: string;
  isConfirmed: boolean;
  isActive: boolean;
  createdAt: string;
}

@Component({
  selector: 'app-admin-newsletter',
  standalone: true,
  imports: [FormsModule, DatePipe],
  templateUrl: './newsletter.component.html'
})
export class NewsletterComponent implements OnInit {
  private readonly api = inject(ApiService);
  items: Subscriber[] = [];
  email = '';
  fullName = '';
  message = '';

  ngOnInit(): void { this.load(); }

  load(): void {
    this.api.get<Subscriber[]>('/newsletter/subscribers').subscribe({
      next: x => this.items = x,
      error: e => this.message = e.status === 403
        ? 'Chỉ quản trị viên được xem danh sách đăng ký.'
        : (e.error?.message || 'Không tải được danh sách.')
    });
  }

  add(): void {
    if (!this.email.trim()) return;
    this.api.post('/newsletter/subscribe', { email: this.email, fullName: this.fullName }).subscribe({
      next: () => {
        this.message = 'Đã đăng ký email.';
        this.email = ''; this.fullName = ''; this.load();
      },
      error: e => this.message = e.error?.message || 'Không thể đăng ký email.'
    });
  }
}
