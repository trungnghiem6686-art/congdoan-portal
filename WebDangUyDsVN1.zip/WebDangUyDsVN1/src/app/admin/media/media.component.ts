import { Component, inject, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/services/api.service';

@Component({selector:'app-admin-media',standalone:true,imports:[FormsModule],templateUrl:'./media.component.html'})
export class MediaComponent implements OnInit {
 private api=inject(ApiService); items:any[]=[]; message='';
 form:any={mediaType:'VIDEO',title:'',description:'',mediaUrl:'',thumbnailUrl:'',embedUrl:'',isPublished:true,sortOrder:0};
 ngOnInit(){this.load();}
 load(){this.api.get<any[]>('/media/admin').subscribe(x=>this.items=x);}
 create(){this.api.post('/media',this.form).subscribe({next:()=>{this.message='Đã thêm media.';this.load();},error:e=>this.message=e.error?.message||'Lỗi.'});}
}
