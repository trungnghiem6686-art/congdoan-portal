import { Component, inject, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/services/api.service';

interface UserItem {
  userId: number;
  username: string;
  fullName: string;
  email?: string;
  departmentName?: string;
  partyCellName?: string;
  roles: string[];
  isActive: boolean;
}

interface Department {
  departmentId: number;
  departmentName: string;
}

interface PartyCell {
  partyCellId: number;
  partyCellName: string;
  departmentId: number;
}

@Component({
  selector: 'app-admin-users',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './users.component.html'
})
export class UsersComponent implements OnInit {
  private readonly api = inject(ApiService);

  users: UserItem[] = [];
  departments: Department[] = [];
  partyCells: PartyCell[] = [];

  showForm = false;
  message = '';

  form = {
    username: '',
    password: '',
    fullName: '',
    email: '',
    phone: '',
    departmentId: null as number | null,
    partyCellId: null as number | null
  };

  ngOnInit() {
    this.load();
    this.api.get<Department[]>('/departments').subscribe(x => this.departments = x);
  }

  load() {
    this.api.get<UserItem[]>('/users').subscribe({
      next: x => this.users = x,
      error: e => this.message = e.error?.message || 'Không tải được người dùng.'
    });
  }

  departmentChanged() {
    this.form.partyCellId = null;
    if (!this.form.departmentId) {
      this.partyCells = [];
      return;
    }
    this.api.get<PartyCell[]>(`/party-cells?departmentId=${this.form.departmentId}`)
      .subscribe(x => this.partyCells = x);
  }

  create() {
    this.message = '';
    if (!this.form.username || !this.form.password || !this.form.fullName) {
      this.message = 'Vui lòng nhập tài khoản, mật khẩu và họ tên.';
      return;
    }

    this.api.post('/users', this.form).subscribe({
      next: () => {
        this.message = 'Tạo người dùng thành công.';
        this.showForm = false;
        this.form = {
          username: '', password: '', fullName: '', email: '', phone: '',
          departmentId: null, partyCellId: null
        };
        this.load();
      },
      error: e => this.message = e.error?.message || 'Không thể tạo người dùng.'
    });
  }
}
