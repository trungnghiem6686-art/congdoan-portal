import { Component, inject, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/services/api.service';

@Component({
 selector:'app-admin-banners', standalone:true, imports:[FormsModule],
 templateUrl:'./banners.component.html'
})
export class BannersComponent implements OnInit {
 private api=inject(ApiService); items:any[]=[]; message='';
 form:any={campaignName:'',title:'',subtitle:'',imageUrl:'',linkUrl:'',startAt:'',endAt:'',priority:0};
 ngOnInit(){this.load();}
 load(){this.api.get<any[]>('/banners/admin').subscribe(x=>this.items=x);}
 create(){this.api.post('/banners',this.form).subscribe({next:()=>{this.message='Đã tạo banner.';this.load();},error:e=>this.message=e.error?.message||'Lỗi.'});}
 delete(id:number){if(confirm('Xóa banner?'))this.api.delete(`/banners/${id}`).subscribe(()=>this.load());}
}
