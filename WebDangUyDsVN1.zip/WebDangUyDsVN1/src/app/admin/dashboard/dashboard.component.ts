import { Component, inject } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './dashboard.component.html'
})
export class DashboardComponent {
  readonly auth = inject(AuthService);
  readonly router = inject(Router);
  readonly user = this.auth.getCurrentUser();

  logout(): void {
    this.auth.logout();
    this.router.navigateByUrl('/login');
  }
}
