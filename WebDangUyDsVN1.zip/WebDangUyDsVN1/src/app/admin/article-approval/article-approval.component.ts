import { Component, inject, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/services/api.service';

interface PendingArticle {
  articleId: number;
  title: string;
  summary?: string;
  levelNo: number;
  levelName: string;
  statusCode: string;
  articleApprovalId: number;
}

@Component({
  selector: 'app-admin-article-approval',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './article-approval.component.html'
})
export class ArticleApprovalComponent implements OnInit {
  private readonly api = inject(ApiService);
  items: PendingArticle[] = [];
  comment = '';
  message = '';

  ngOnInit() { this.load(); }

  load() {
    this.api.get<PendingArticle[]>('/articles/approval/pending').subscribe({
      next: x => this.items = x,
      error: e => this.message = e.status === 403
        ? 'Tài khoản không có quyền duyệt bài.'
        : (e.error?.message || 'Không tải được danh sách chờ duyệt.')
    });
  }

  action(id: number, action: 'APPROVE' | 'REJECT') {
    this.api.post(`/articles/${id}/approval`, {
      action,
      comment: this.comment
    }).subscribe({
      next: () => {
        this.comment = '';
        this.message = action === 'APPROVE' ? 'Đã duyệt bài.' : 'Đã từ chối bài.';
        this.load();
      },
      error: e => this.message = e.error?.message || 'Thao tác duyệt thất bại.'
    });
  }
}
