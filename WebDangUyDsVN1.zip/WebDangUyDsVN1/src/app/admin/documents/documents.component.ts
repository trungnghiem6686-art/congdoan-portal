import { Component, inject, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { ApiService } from '../../core/services/api.service';

interface Category { documentCategoryId: number; categoryName: string; }
interface DocumentItem {
  documentId: number;
  categoryId: number;
  categoryName: string;
  documentNumber: string;
  title: string;
  summary?: string;
  signer?: string;
  issueDate?: string;
  issuingUnit?: string;
  viewCount: number;
}

@Component({
  selector: 'app-admin-documents',
  standalone: true,
  imports: [FormsModule, DatePipe],
  templateUrl: './documents.component.html'
})
export class DocumentsComponent implements OnInit {
  private readonly api = inject(ApiService);
  items: DocumentItem[] = [];
  categories: Category[] = [];
  message = '';
  showForm = false;
  keyword = '';
  categoryId: number | null = null;
  documentNumber = '';

  form = {
    categoryId: null as number | null,
    documentNumber: '',
    title: '',
    summary: '',
    signer: '',
    issueDate: '',
    issuingUnit: ''
  };

  ngOnInit() {
    this.api.get<Category[]>('/documents/categories').subscribe(x => this.categories = x);
    this.load();
  }

  load() {
    const p = new URLSearchParams();
    if (this.keyword) p.set('keyword', this.keyword);
    if (this.categoryId) p.set('categoryId', String(this.categoryId));
    if (this.documentNumber) p.set('documentNumber', this.documentNumber);

    this.api.get<DocumentItem[]>(`/documents?${p.toString()}`).subscribe({
      next: x => this.items = x,
      error: e => this.message = e.error?.message || 'Không tải được văn bản.'
    });
  }

  create() {
    if (!this.form.categoryId || !this.form.documentNumber || !this.form.title) {
      this.message = 'Vui lòng nhập đủ chuyên mục, số hiệu và tiêu đề.';
      return;
    }

    this.api.post('/documents', this.form).subscribe({
      next: () => {
        this.message = 'Đã thêm văn bản.';
        this.showForm = false;
        this.load();
      },
      error: e => this.message = e.error?.message || 'Không thể thêm văn bản.'
    });
  }
}
