import { Component, inject, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/services/api.service';

interface Question {
  policyQuestionId: number;
  question: string;
  questionerName?: string;
  questionerEmail?: string;
  categoryCode?: string;
  statusCode: string;
  createdAt: string;
}

@Component({
  selector: 'app-admin-policy',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './policy.component.html'
})
export class PolicyComponent implements OnInit {
  private readonly api = inject(ApiService);
  items: Question[] = [];
  message = '';
  selected: Question | null = null;
  answer = '';
  publish = true;

  ngOnInit() { this.load(); }

  load() {
    this.api.get<Question[]>('/policy/questions/admin').subscribe({
      next: x => this.items = x,
      error: e => this.message = e.error?.message || 'Không tải được câu hỏi.'
    });
  }

  choose(q: Question) {
    this.selected = q;
    this.answer = '';
  }

  sendAnswer() {
    if (!this.selected || !this.answer.trim()) return;

    this.api.post(`/policy/questions/${this.selected.policyQuestionId}/answer`, {
      answer: this.answer,
      publish: this.publish
    }).subscribe({
      next: () => {
        this.message = this.publish ? 'Đã trả lời và công khai.' : 'Đã lưu câu trả lời.';
        this.answer = '';
        this.selected = null;
        this.load();
      },
      error: e => this.message = e.error?.message || 'Không thể trả lời.'
    });
  }
}
