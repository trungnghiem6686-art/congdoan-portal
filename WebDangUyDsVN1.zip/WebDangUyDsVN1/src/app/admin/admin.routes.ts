import { Routes } from '@angular/router';
import { adminGuard } from '../core/guards/admin.guard';

export const ADMIN_ROUTES: Routes = [
  { path: '', canActivate: [adminGuard], loadComponent: () => import('./dashboard/dashboard.component').then(m => m.DashboardComponent) },
  { path: 'users', canActivate: [adminGuard], loadComponent: () => import('./users/users.component').then(m => m.UsersComponent) },
  { path: 'departments', canActivate: [adminGuard], loadComponent: () => import('./departments/departments.component').then(m => m.DepartmentsComponent) },
  { path: 'party-cells', canActivate: [adminGuard], loadComponent: () => import('./party-cells/party-cells.component').then(m => m.PartyCellsComponent) },
  { path: 'articles', canActivate: [adminGuard], loadComponent: () => import('./articles/articles.component').then(m => m.ArticlesComponent) },
  { path: 'article-approval', canActivate: [adminGuard], loadComponent: () => import('./article-approval/article-approval.component').then(m => m.ArticleApprovalComponent) },
  { path: 'documents', canActivate: [adminGuard], loadComponent: () => import('./documents/documents.component').then(m => m.DocumentsComponent) },
  { path: 'calendar', canActivate: [adminGuard], loadComponent: () => import('./calendar/calendar.component').then(m => m.CalendarComponent) },
  { path: 'policy', canActivate: [adminGuard], loadComponent: () => import('./policy/policy.component').then(m => m.PolicyComponent) },
  { path: 'newsletter', canActivate: [adminGuard], loadComponent: () => import('./newsletter/newsletter.component').then(m => m.NewsletterComponent) },
  { path: 'banners', canActivate: [adminGuard], loadComponent: () => import('./banners/banners.component').then(m => m.BannersComponent) },
  { path: 'media', canActivate: [adminGuard], loadComponent: () => import('./media/media.component').then(m => m.MediaComponent) },
  { path: 'analytics', canActivate: [adminGuard], loadComponent: () => import('./analytics/analytics.component').then(m => m.AnalyticsComponent) }
];
