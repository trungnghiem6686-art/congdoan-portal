/**
 * CỔNG THÔNG TIN ĐIỆN TỬ ĐẢNG ỦY ĐƯỜNG SẮT QUỐC GIA
 * Script tương tác JavaScript hoàn chỉnh cho toàn bộ hệ thống
 */

document.addEventListener('DOMContentLoaded', function () {
    
    // ===================================================
    // 1. TƯƠNG TÁC MENU MOBILE (Responsive Mobile Menu)
    // ===================================================
    const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
    const mainNav = document.getElementById('mainNav');

    if (mobileMenuBtn && mainNav) {
        mobileMenuBtn.addEventListener('click', function () {
            mainNav.classList.toggle('mobile-show');
            const icon = mobileMenuBtn.querySelector('i');
            if (icon) {
                icon.classList.toggle('fa-bars');
                icon.classList.toggle('fa-xmark');
            }
        });
    }

    // ===================================================
    // 2. TAB TIN ĐỌC NHIỀU (Thống kê lượt đọc Ngày/Tuần/Tháng)
    // ===================================================
    const tabButtons = document.querySelectorAll('.time-tabs .tab-btn');
    
    tabButtons.forEach(button => {
        button.addEventListener('click', function () {
            tabButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');

            const tabName = this.textContent.trim();
            console.log(`[Thống kê] Đang hiển thị tin đọc nhiều theo: ${tabName}`);
        });
    });

    // ===================================================
    // 3. TƯƠNG TÁC HỎI ĐÁP CHÍNH SÁCH (FAQ Accordion)
    // ===================================================
    const faqQuestions = document.querySelectorAll('.faq-question');

    faqQuestions.forEach(question => {
        question.addEventListener('click', function () {
            const faqItem = this.parentElement;
            const answer = faqItem.querySelector('.faq-answer');
            const icon = this.querySelector('.fa-chevron-down, .fa-chevron-up');

            if (answer) {
                const isHidden = getComputedStyle(answer).display === 'none';
                answer.style.display = isHidden ? 'block' : 'none';
                
                if (icon) {
                    icon.classList.toggle('fa-chevron-down', !isHidden);
                    icon.classList.toggle('fa-chevron-up', isHidden);
                }
            }
        });
    });

    // ===================================================
    // 4. GỬI CÂU HỎI MỚI (Hỏi đáp chính sách)
    // ===================================================
    const btnAsk = document.querySelector('.btn-ask');
    if (btnAsk) {
        btnAsk.addEventListener('click', function () {
            const userQuestion = prompt('Nhập câu hỏi của bạn gửi tới Ban Bồi dưỡng Policy/Đảng ủy:');
            if (userQuestion && userQuestion.trim() !== '') {
                alert(' Cảm ơn đồng chí! Câu hỏi đã được chuyển đến Ban Tuyên giáo Đảng ủy để giải đáp.');
            }
        });
    }

    // ===================================================
    // 5. ĐĂNG KÝ NHẬN BẢN TIN (Newsletter Subscription)
    // ===================================================
    const btnSubscribe = document.querySelector('.btn-subscribe');
    const newsletterInput = document.querySelector('.newsletter-input');

    if (btnSubscribe && newsletterInput) {
        btnSubscribe.addEventListener('click', function () {
            const email = newsletterInput.value.trim();
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

            if (!email) {
                alert('Vui lòng nhập địa chỉ Email!');
                newsletterInput.focus();
            } else if (!emailRegex.test(email)) {
                alert('Địa chỉ Email không hợp lệ. Vui lòng kiểm tra lại!');
                newsletterInput.focus();
            } else {
                alert(` Đăng ký thành công! Đã thêm email [${email}] vào danh sách nhận bản tin chỉ đạo.`);
                newsletterInput.value = '';
            }
        });
    }

    // ===================================================
    // 6. TÌM KIẾM VĂN BẢN VÀ TIN TỨC NÂNG CAO
    // ===================================================
    const searchBoxes = document.querySelectorAll('.search-box-top, .sidebar-search');

    searchBoxes.forEach(box => {
        const input = box.querySelector('input');
        const button = box.querySelector('button');

        const performSearch = () => {
            const query = input.value.trim();
            if (query) {
                alert(`[Tra cứu] Đang tìm kiếm bài viết / văn bản với từ khóa: "${query}"...`);
            } else {
                alert('Vui lòng nhập từ khóa tìm kiếm!');
                input.focus();
            }
        };

        if (button) button.addEventListener('click', performSearch);
        if (input) {
            input.addEventListener('keypress', function (e) {
                if (e.key === 'Enter') performSearch();
            });
        }
    });

    // ===================================================
    // 7. TÍCH HỢP XEM VIDEO & INFOGRAPHIC (Media Player Popup)
    // ===================================================
    const mediaCards = document.querySelectorAll('.media-card');
    mediaCards.forEach(card => {
        card.addEventListener('click', function () {
            const title = this.querySelector('.media-title')?.innerText || 'Nội dung Media';
            alert(`Đang mở trình phát đa phương tiện: \n"${title}"`);
        });
    });

    // ===================================================
    // 8. GIẢ LẬP QUẢN TRỊ DUYỆT BÀI NHIỀU CẤP & PHÂN QUYỀN
    // ===================================================
    const adminLoginBtn = document.querySelector('.btn-login');
    if (adminLoginBtn) {
        adminLoginBtn.addEventListener('click', function (e) {
            e.preventDefault();
            const role = prompt(
                "HỆ THỐNG QUẢN TRỊ NỘI BỘ\n" +
                "Nhập vai trò kiểm thử của bạn:\n" +
                "1. Biêu tập viên (Tạo bài)\n" +
                "2. Bí thư Chi bộ (Duyệt cấp 1)\n" +
                "3. Ban Tuyên giáo Đảng ủy (Duyệt cấp 2/Xuất bản)\n" +
                "Nhập số (1-3):"
            );

            switch (role) {
                case '1':
                    alert('Chế độ: Biên tập viên Chi bộ.\nBạn có quyền Soạn bài & Gửi duyệt.');
                    break;
                case '2':
                    alert('Chế độ: Bí thư Chi bộ cơ sở.\nBạn có quyền Duyệt bài cấp 1.');
                    break;
                case '3':
                    alert('Chế độ: Admin Đảng ủy Quốc gia.\nBạn có toàn quyền Quản trị, Phân quyền & Xuất bản.');
                    break;
                default:
                    if (role) alert('Lựa chọn không hợp lệ!');
                    break;
            }
        });
    }

    // ===================================================
    // 9. TẢI VĂN BẢN VÀ THỐNG KÊ LƯỢT TẢI
    // ===================================================
    const downloadBtns = document.querySelectorAll('.btn-download');
    downloadBtns.forEach(btn => {
        btn.addEventListener('click', function (e) {
            e.preventDefault();
            const row = this.closest('tr');
            const docCode = row ? row.querySelector('td:first-child').innerText : 'Tài liệu';
            alert(`Đang khởi tạo tải xuống văn bản: [${docCode}]`);
        });
    });

});