# WebDangUyDs - 12 chức năng + Backend + SQL Server

Đây là bản hợp nhất: giữ nguyên Backend ASP.NET Core + Database SQL Server của bản HoanThien_TatCaChucNang và nối Frontend Angular vào cùng một route tree.

## 12 chức năng

1. Quản trị tin bài theo chuyên mục
2. Duyệt bài nhiều cấp
3. Tìm kiếm văn bản, tin tức
4. Phân quyền theo đơn vị, chi bộ
5. Thư viện văn bản/tài liệu
6. Lịch công tác Đảng ủy
7. Hỏi đáp chính sách
8. Đăng ký nhận bản tin
9. Banner tuyên truyền theo chiến dịch
10. Thống kê lượt đọc
11. Video, infographic
12. Mobile responsive

## Chạy SQL

Database đã nằm trong `database/`. Chạy các file theo thứ tự được ghi trong README của database.
Connection mặc định của API:

`Server=localhost;Database=WebDangUyDs;Trusted_Connection=True;TrustServerCertificate=True;MultipleActiveResultSets=True`

Nếu SQL Server của bạn dùng instance khác, sửa `backend/WebDangUyDs.Api/appsettings.json`.

## Chạy Backend

```powershell
cd backend/WebDangUyDs.Api
dotnet restore
dotnet run
```

API mặc định dùng HTTPS `https://localhost:7001` theo `src/app/core/services/api.config.ts`.

Khi backend khởi động, `DevelopmentSeed` tự tạo các tài khoản demo nếu chưa có:

| Username | Password | Role |
|---|---|---|
| admin | Admin@123 | ADMIN |
| danguy | DangUy@123 | DANG_UY |
| chibo | ChiBo@123 | CHI_BO |
| editor | Editor@123 | EDITOR |
| viewer | Viewer@123 | VIEWER |

Đây chỉ là tài khoản development. Đổi mật khẩu trước khi triển khai thật.

## Chạy Angular

Mở terminal khác tại thư mục có `package.json`:

```powershell
npm install
npm start
```

Mở `http://localhost:4200`.

- `/` = trang chủ
- `/login` = đăng nhập thật qua Backend/JWT
- `/portal` = tìm kiếm, banner, lịch, hỏi đáp, newsletter, media
- `/admin` = khu quản trị

## Kiểm tra

1. Chạy SQL.
2. Chạy backend trước.
3. Chạy Angular.
4. Đăng nhập `admin / Admin@123`.
5. Thử tạo tin → gửi duyệt → duyệt cấp 1/cấp 2.
6. Thử văn bản, lịch, hỏi đáp, banner, media, newsletter, analytics.
7. Đăng nhập các tài khoản khác để kiểm tra phạm vi quyền.

Không còn cơ chế `prompt()` chọn vai trò 1-5.
