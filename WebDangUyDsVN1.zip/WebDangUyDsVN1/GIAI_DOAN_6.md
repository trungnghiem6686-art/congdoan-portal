# Giai đoạn 6 - Lịch công tác + Hỏi đáp chính sách

## Database
Chạy:
`database/09_Calendar_Policy.sql`

Tạo:
- Calendar.WorkCalendarEvent
- Policy.PolicyQuestion
- Policy.PolicyAnswer

## Lịch công tác
Public:
- GET `/api/calendar`
- GET `/api/calendar/{id}`

Admin:
- GET `/api/calendar/admin`
- POST `/api/calendar`
- PUT `/api/calendar/{id}`
- DELETE `/api/calendar/{id}`

Angular:
`/admin/calendar`

## Hỏi đáp chính sách
Public:
- GET `/api/policy/questions`
- POST `/api/policy/questions`

Admin:
- GET `/api/policy/questions/admin`
- GET `/api/policy/questions/{id}`
- POST `/api/policy/questions/{id}/answer`

Angular:
`/admin/policy`

Luồng hỏi đáp:
Người dân/cán bộ gửi câu hỏi
→ PENDING
→ cán bộ xử lý
→ PROCESSING
→ trả lời
→ ANSWERED
→ công khai trên website nếu `publish=true`.
