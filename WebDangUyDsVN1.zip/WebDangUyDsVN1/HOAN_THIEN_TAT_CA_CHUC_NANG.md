# Web Đảng ủy DS - Hoàn thiện toàn bộ chức năng

## Đã triển khai

1. Quản trị tin bài theo chuyên mục
2. Duyệt bài nhiều cấp
3. Tìm kiếm văn bản, tin tức
4. Phân quyền theo đơn vị/chi bộ (khung dữ liệu + role hiện có)
5. Thư viện văn bản/tài liệu
6. Lịch công tác Đảng ủy
7. Hỏi đáp chính sách
8. Đăng ký nhận bản tin
9. Banner tuyên truyền theo chiến dịch
10. Thống kê lượt đọc
11. Video + Infographic
12. Responsive mobile

## SQL chạy theo thứ tự

01 -> 02 -> ... -> 09 -> 10

File mới nhất:
`database/10_Portal_Complete.sql`

## API mới

Newsletter:
- POST /api/newsletter/subscribe
- GET /api/newsletter/unsubscribe/{token}
- GET /api/newsletter/subscribers

Banner:
- GET /api/banners
- GET /api/banners/admin
- POST /api/banners
- DELETE /api/banners/{id}

Media:
- GET /api/media
- GET /api/media/admin
- POST /api/media
- POST /api/media/{id}/view

Search:
- GET /api/search?keyword=...
- GET /api/search/stats

Analytics:
- GET /api/analytics/summary
- GET /api/analytics/daily?days=30

## Admin routes

- /admin/articles
- /admin/article-approval
- /admin/documents
- /admin/calendar
- /admin/policy
- /admin/banners
- /admin/media
- /admin/analytics

## Lưu ý production

- Cấu hình CORS/domain thật.
- Đưa file upload sang storage riêng.
- Quét virus file upload.
- SMTP/email service để gửi bản tin.
- Bổ sung xác thực email/OTP nếu yêu cầu.
- Hash IP nếu cần thống kê chống đếm trùng.
- Thiết lập backup SQL Server.
- Cấu hình HTTPS.
- Kiểm tra lại mapping bảng User/Department/PartyCell theo database thực tế.
