# Giai đoạn 5 - Thư viện văn bản / tài liệu

Đã bổ sung:

## Database
- `Library.DocumentCategory`
- `Library.Document`
- `Library.DocumentFile`
- Dữ liệu mẫu 9 nhóm văn bản
- Index tìm kiếm

Chạy:
`database/08_Library.sql`

## Backend
- `GET /api/documents`
- `GET /api/documents/categories`
- `GET /api/documents/{id}`
- `POST /api/documents`
- `PUT /api/documents/{id}`
- `POST /api/documents/{id}/files`
- `GET /api/documents/files/{fileId}/download`
- `POST /api/documents/{id}/view`

Upload:
- PDF
- Word
- Excel
- PowerPoint
- JPG/JPEG/PNG
- ZIP
- Giới hạn 50 MB/file

## Angular
`/admin/documents`

Có:
- Tìm kiếm văn bản
- Lọc loại văn bản
- Tìm theo số hiệu
- Thêm văn bản
- Số hiệu
- Trích yếu
- Người ký
- Ngày ban hành
- Đơn vị ban hành
- Lượt đọc

Ghi chú:
File vật lý được lưu ở `backend/WebDangUyDs.Api/uploads/documents`.
Trong môi trường production nên chuyển sang storage riêng (NAS/S3/Azure Blob...) và bổ sung antivirus/quét file.
