# WebDangUyDs - Giai đoạn 1

Mục tiêu giai đoạn này:
1. Tạo database WebDangUyDs.
2. Tạo cấu trúc Đơn vị -> Chi bộ.
3. Tạo User / Role / Permission / UserScope.
4. Tạo Tin bài và Văn bản.
5. Tạo workflow duyệt bài 2 cấp.
6. Tạo AuditLog và các index cơ bản.

## Cách chạy

Trong SQL Server Management Studio hoặc SQL Server extension của VS Code:

1. Mở `01_CreateDatabase.sql` và chạy.
2. Mở `02_CreateMaster.sql` và chạy.
3. Mở `03_CreateSecurity.sql` và chạy.
4. Mở `04_CreateContentAndWorkflow.sql` và chạy.
5. Mở `05_CreateSystem.sql` và chạy.

Các script đều có kiểm tra `IF OBJECT_ID(...) IS NULL`, nên có thể chạy lại mà không cố tạo lại bảng đã tồn tại.

## Lưu ý bảo mật

Không tạo user quản trị với mật khẩu plaintext trong SQL.
Backend ASP.NET Core ở bước tiếp theo sẽ dùng password hashing và JWT.
